#ifndef LISTE_CP_H
#define LISTE_CP_H

#include "maillon_cp.h"

class liste_cp
{
private :
    maillon_cp * tete; // Pointeur sur le premier maillon.
    int nb_maillons;   // Nombre de maillons de la liste.

public :
    liste_cp();
    int get_nb_maillons();
// Ajout d'un maillon au d�but de la liste
    void add_beginning(int x, int y, liste l);
// Suppression de maillons
    void remove_beginning();    // Supprime le premier maillon
    void empty();               // Vide la liste enti�rement
// Consultation et r�cup�ration des donn�es de la liste.
    bool consult(int position, int &x, int &y, liste &l);
// Test d'appartenance de la case (x,y). <=> coup l�gal ?
// La liste Lis est la liste des cases � retourner si les coord appartiennent � la liste. Lis vaut NULL sinon.
    bool appartient(int x, int y, liste &Lis);
};
#endif // LISTE_CP_H
