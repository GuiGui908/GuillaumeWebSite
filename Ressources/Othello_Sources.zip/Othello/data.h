#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED

typedef struct
{
    int reponse;                // 0=quitter, 1=partie 2joueurs, 2=partie vs pc, 3=charger
    int difficulte;             // de 1 � 4. Correspond a la profondeur de recherche alpha-beta
    std::string nomB, nomN, chemin;
} DATA;

#endif // DATA_H_INCLUDED
