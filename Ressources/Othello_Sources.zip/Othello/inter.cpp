#include "inter.h"

inter::inter(int choix) :
// Liste d'initialisation
    interdialog(),
    vboite(interdialog.get_vbox()),
    box_frames(false),

    box_bouton_g(Gtk::BUTTONBOX_END, 15),
    box_bouton_d(Gtk::BUTTONBOX_END, 15),
    create_g("Creer"),
    create_d("Creer"),
    suppr_g("Supprimer"),
    suppr_d("Supprimer"),

    noir(camp, "Noir"),
    blanc(camp, "Blanc"),
    r(difficulte, "Recruit"),
    R(difficulte, "Regular"),
    H(difficulte, "Hardened"),
    V(difficulte, "Veteran"),
    lbl_camp("Quelle couleur prenez-vous ?"),
    lbl_difficulte("Votre niveau de difficute ?"),
    valide(false)
{
// Initialisation des attributs de la boite de dialogue et des donn�es
    interdialog.set_icon_from_file("img/Icone.png");
    interdialog.set_position(Gtk::WIN_POS_CENTER);
    interdialog.set_border_width(5);
    interdialog.signal_delete_event().connect(sigc::mem_fun(*this, &inter::on_quit));

    donnees.nomB = "";
    donnees.nomN = "";
    donnees.chemin = "";
    donnees.reponse = choix;

// Affichage des noms de joueurs en fonction du fichier 'scores.sav'
    std::ifstream fichier("scores.sav", std::ios::in);
    if(!fichier && choix!=0)
    // Erreur d'ouverture du fichier ET on n'a pas quitt� dans la premi�re fen�tre => erreur
    {
        Gtk::MessageDialog dialogue("Fichier introuvable ou corrompu :(", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_CLOSE);
        dialogue.set_title("Erreur fatale");
        dialogue.set_secondary_text("   Le fichier <b>'scores.sav'</b> n'a pas pu etre ouvert ! "\
                                    "Les statistiques du jeu ne seront pas chargees. Reinstallez "\
                                    "le programme pour corriger le probleme :-S", true);
        dialogue.run();
    }
    else
    // Remplissage de la boite de diaogue en fonction de 'choix'
    // Choix : =1 pr une partie a 2 joueurs ; =2 contre l'ordi ; =3 pr charger une ancienne partie
    {
        box_frame_d.pack_start(lbl_camp, Gtk::PACK_SHRINK, 10);
        box_frame_d.pack_start(blanc, Gtk::PACK_SHRINK, 0);
        box_frame_d.pack_start(noir, Gtk::PACK_SHRINK, 0);
        box_frame_d.pack_start(lbl_difficulte, Gtk::PACK_SHRINK, 10);
        box_frame_d.pack_start(r, Gtk::PACK_SHRINK, 0);
        box_frame_d.pack_start(R, Gtk::PACK_SHRINK, 0);
        box_frame_d.pack_start(H, Gtk::PACK_SHRINK, 0);
        box_frame_d.pack_start(V, Gtk::PACK_SHRINK, 0);
        if(choix==1)
        {
            lbl_camp.set_no_show_all();
            noir.set_no_show_all();
            blanc.set_no_show_all();
            lbl_difficulte.set_no_show_all();
            r.set_no_show_all();
            R.set_no_show_all();
            H.set_no_show_all();
            V.set_no_show_all();
        }
        else
        {
            blanc.set_active();
            R.set_active();
        }
        // Cr�e les boutons radio
        for(int i=0; i<10; i++)
        {
            names_b[i].set_group(nom_joueur_b);
            names_b[i].set_no_show_all();
            box_frame_g.pack_start(names_b[i], Gtk::PACK_SHRINK, 0);
            names_n[i].set_group(nom_joueur_n);
            names_n[i].set_no_show_all();
            box_frame_d.pack_start(names_n[i], Gtk::PACK_SHRINK, 0);
        }
        // lecture du fichier pour initialisation des noms de joueur
        if(choix == 1 || choix == 2)
        {
            bool arret = false;
            char car = 'a';
            // cherche le premier nom
            while(car != '$' && arret == false)
            {
                if(fichier.ignore(1000, '\n') == false) arret = true;
                fichier.get(car);
            }

            for(int i=0; i<10 && arret==false && car == '$'; i++)
            {
                std::string nom, nombis;
                fichier >> nom;         // Stocke la string contenant le nom dans 'nom'
                fichier.get(car);
                // ajoute les mots suivants dans le cas o� il y a des espaces dans le nom
                while(car == ' ')
                {
                    nom.append(" ");
                    fichier >> nombis;
                    nom.append(nombis);
                    fichier.get(car);
                }
                fichier.get(car);
                // cherche le nom suivant (placement du curseur)
                while(car != '$' && arret == false)
                {
                    if(fichier.ignore(1000, '\n') == false) arret = true;
                    fichier.get(car);
                }
                names_b[i].set_label(nom);
                names_b[i].show();
                names_n[i].set_label(nom);
                if(choix==1) names_n[i].show();
                // Initialise le cochage des boutons radio
                if(i==0)
                {
                    names_b[i].set_active();
                    if(choix == 1) names_n[i].set_active();
                }
                else if(i==1 && choix==1) names_n[i].set_active();
            }
            donnees.nomN = "IA_ordi";
            if(choix==1) interdialog.set_title("Parametres de la partie a 2 joueurs");
            else interdialog.set_title("Parametres de la partie contre l'ordinateur");
            vboite->pack_start(box_frames, Gtk::PACK_SHRINK, 5);
            interdialog.add_button("Annuler", 0);
            interdialog.add_button("Jouer", 1);

            box_frames.pack_start(gauche, Gtk::PACK_SHRINK, 10);
            if(choix==1) gauche.set_label("Joueur Blanc");
            else gauche.set_label("Joueur");
            gauche.add(box_frame_g);
            box_frame_g.pack_start(box_bouton_g, Gtk::PACK_SHRINK, 10);
            box_bouton_g.pack_start(create_g);
            if(choix==1) create_g.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::creation), 'b'));
            else create_g.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::creation), 'o'));
            box_bouton_g.pack_start(suppr_g);
            if(choix==1) suppr_g.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::suppression), 'b'));
            else suppr_g.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::suppression), 'o'));

            if(choix==1)
            {
                box_frames.pack_start(droite, Gtk::PACK_SHRINK, 10);
                droite.set_label("Joueur Noir");
                droite.add(box_frame_d);
            }
            else box_frames.pack_start(box_frame_d, Gtk::PACK_SHRINK, 10);
            box_frame_d.pack_start(box_bouton_d, Gtk::PACK_SHRINK, 10);
            if(choix==2) box_bouton_d.set_no_show_all();
            box_bouton_d.pack_start(create_d);
            create_d.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::creation), 'n'));
            box_bouton_d.pack_start(suppr_d);
            suppr_d.signal_clicked().connect(sigc::bind<char>(sigc::mem_fun(*this, &inter::suppression), 'n'));

            vboite->show_all();

            bool fin = false;       // permet de rester dans la boucle si les noms sont mal saisis
            while(!fin && interdialog.run() != 0)
            {
                int i;
                for(i=0; i<10 && !names_b[i].get_active(); i++);        // cherche le bouton actif pr initialiser la donn�e
                donnees.nomB = names_b[i].get_label();
                if(choix==1)
                {
                    for(i=0; i<10 && !names_n[i].get_active(); i++);
                    donnees.nomN = names_n[i].get_label();
                }
                if(donnees.nomB == "" || donnees.nomN == "")
                // Si un des noms n'est pas initialis�
                {
                    Gtk::MessageDialog incomplet("<big><b>Joueur manquant.</b></big>", true);
                    incomplet.set_position(Gtk::WIN_POS_CENTER);
                    incomplet.set_secondary_text("Ajoutez un nouveau joueur avec le bouton 'Creer'.");
                    incomplet.set_title("Informations incompl�tes");
                    incomplet.run();
                }
                else if(donnees.nomB == donnees.nomN)
                // Si les deux joueurs ont le meme nom...
                {
                    Gtk::MessageDialog incomplet("<big>Les <b>joueurs</b> selectionnes"\
                                                 " sont <b>identiques</b>.</big>", true);
                    incomplet.set_secondary_text("Impossible de jouer contre soi-meme XD");
                    incomplet.set_title("Informations invalides");
                    incomplet.run();
                }
                else    // pas de probleme, on peut lancer la fenetre principale
                {
                    if(choix==2)
                    {
                        if(noir.get_active())       // �change le nom noir et blanc si l'user a choisi les noirs contre l'ordi
                        {
                            donnees.nomN = donnees.nomB;
                            donnees.nomB = "IA_ordi";
                        }
                        if(r.get_active()) donnees.difficulte = 1;
                        else if(R.get_active()) donnees.difficulte = 2;
                        else if(H.get_active()) donnees.difficulte = 3;
                        else if(V.get_active()) donnees.difficulte = 4;
                    }
                    fin = true;
                    valide = true;
                }
            }
        }
        if(choix == 3)          // cas o� on charge une partie
        {
            Gtk::FileChooserDialog dialog("Charger un fichier de sauvegarde...");

            dialog.set_position(Gtk::WIN_POS_CENTER);
            dialog.set_icon(Gdk::Pixbuf::create_from_file("img/Icone.png"));
            dialog.set_create_folders();
            dialog.signal_file_activated().connect(sigc::bind<int>(sigc::mem_fun(dialog, &Gtk::Dialog::response), 1));
            dialog.set_current_folder("Sauvegardes");
            dialog.add_button("Annuler", 0);
            dialog.add_button("Ouvrir", 1);
            dialog.show_all();
            if(dialog.run()==1)
            {
                donnees.chemin = dialog.get_filename();
                valide = true;
            }
        }
    }
    if(choix == 0) valide = true;
    fichier.close();
}

bool inter::on_quit(GdkEventAny* event)
{
    interdialog.response(0);
    return true;
}

DATA inter::get_donnees()
{
    return donnees;
}

bool inter::get_valide()
{
    return valide;
}

void inter::creation(char coul)
{
    Gtk::Dialog cree("Nouveau joueur");
    Gtk::Entry nom;
    Gtk::Label labl("Nom :");
    Gtk::Box *Vboite(cree.get_vbox());
    Gtk::HBox nom_entry(false);

    cree.set_position(Gtk::WIN_POS_CENTER);
    cree.set_border_width(5);
    cree.set_icon(Gdk::Pixbuf::create_from_file("img/Icone.png"));

    Vboite->pack_start(nom_entry, Gtk::PACK_SHRINK, 10);
    nom_entry.pack_start(labl, Gtk::PACK_SHRINK, 5);
    nom.set_max_length(25);
    nom.signal_activate().connect(sigc::bind<int>(sigc::mem_fun(cree, &Gtk::Dialog::response), 1));
    nom_entry.pack_start(nom, Gtk::PACK_SHRINK, 0);

    cree.add_button("Annuler", 0);
    cree.add_button("Creer", 1);

    std::ifstream fichier("scores.sav", std::ios::in);
    if(fichier)
    {
        int nb_nom = 0;
        char car;
        std::string nv, namex, nombis;
        // On compte le nombre de noms enregistres. (le nombre de $)
        fichier.ignore(10000, '$');
        while(fichier.ignore(10000, '$')) nb_nom++;
        nb_nom --;      // Contrer le dernier ++ : � la derniere iteration il ne trouve pas de $ mais arrive �
        // la fin du fichier. ignore ne renvoie pas false. il incremente donc 1 fois de trop
        if(nb_nom <10)      // On cr�e si le nombre de noms dans le fichier est de 9 ou moins !!!
        {
            cree.show_all();
            if(cree.run() == 1)             // clic sur  creer
            {
                nv = nom.get_text();
                std::ifstream existant("scores.sav", std::ios::in);
                existant.get(car);
                namex = nv;
                namex.append("+++");    // Pour que nv et namex soient tjrs differents et que la boucle soit lanc�e
                while(existant.ignore(10000, '$') && namex != nv)   // Recherche si le nom existe deja
                {
                    existant >> namex;
                    existant.get(car);
                    while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces
                    {
                        namex.append(" ");
                        existant >> nombis;
                        namex.append(nombis);
                        existant.get(car);
                    }
                }
                existant.close();
                if(namex == nv)
                {
                    Gtk::MessageDialog dialogue(cree, "Ce joueur existe deja !!", false, Gtk::MESSAGE_WARNING, Gtk::BUTTONS_CLOSE);
                    dialogue.set_title("Attention");
                    dialogue.set_secondary_text("Il ne sera pas cree. Saisissez un autre nom la prochaine fois.");
                    dialogue.run();
                }
                else if(nv == "")                      // dans le cas o� rien n'a ete saisi dans la sone de texte
                {
                    Gtk::MessageDialog dialogue(cree, "Aucun joueur ne sera cree avec un nom vide !!", false, Gtk::MESSAGE_WARNING, Gtk::BUTTONS_CLOSE);
                    dialogue.set_title("Attention");
                    dialogue.set_secondary_text("Saisissez quelquechose la prochaine fois.");
                    dialogue.run();
                }
                else                           // Ecriture du nom dans le fihier
                {
                    std::ofstream fic("scores.sav", std::ios::out | std::ios::app);
                    if(fic)
                    {
                        fic << "$" << nv << "\n";          // Ecriture du nom "nv"
                        int i;
                        for(i=0; i<10 && names_b[i].get_label() != ""; i++);    // Cherche le premier nom vide
                        names_b[i].set_label(nv);
                        names_b[i].show();
                        if(coul != 'o')
                        {
                            names_n[i].set_label(nv);
                            names_n[i].show();
                        }
                        if(coul == 'n') names_n[i].set_active();
                        else names_b[i].set_active();
                    }
                    else std::cerr << "Echec de l'ouverture de 'score.sav' en ecritre alors que la lecture"\
                                       " a marche !!! Bizarre";
                    fic.close();
                }
            }
        }
        else        // Il y a deja 10 noms dans le fichier
        {
            Gtk::MessageDialog dialogue(cree, "Le nombre de joueurs est limite a 10 !!", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_CLOSE);
            dialogue.set_position(Gtk::WIN_POS_CENTER);
            dialogue.set_title("Erreur - Surnombre");
            dialogue.set_secondary_text("Supprimez ceux dont vous ne vous servez pas.");
            dialogue.run();
        }
    }
    else        // Fichier non ouvert (fichier == false)
    {
        Gtk::MessageDialog dialogue("Fichier introuvable ou corrompu :(", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_CLOSE);
        dialogue.set_position(Gtk::WIN_POS_CENTER);
        dialogue.set_title("Erreur fatale");
        dialogue.set_secondary_text("   Le fichier <b>'scores.sav'</b> n'a pas pu etre ouvert ! Les statistiques du jeu ne "\
                                    "seront pas chargees. Reinstallez le programme pour corriger le probleme :-S", true);
        dialogue.run();
    }
    fichier.close();
}

void inter::suppression(char coul)
{
    if(names_b[0].get_label() == "")        // Il n'y a aucun nom a suppr
    {
        Gtk::MessageDialog dialogue("Aucun profil a supprimer", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_OK);
        dialogue.set_position(Gtk::WIN_POS_CENTER);
        dialogue.set_title("Erreur");
        dialogue.set_secondary_text("La liste des joueurs est <b>vide !</b>", true);
        dialogue.run();
    }
    else
    {
        std::string title = "Supprimer le joueur ", name;
        int in=0, ib;     // in[ib] est le numero du radiobouton noir[blanc] actif
        for(ib=0; ib<10 && !names_b[ib].get_active(); ib++);    // Cherche ib
        if(coul != 'o') for(in=0; in<10 && !names_n[in].get_active(); in++);    // Cherche in si c'est pas le bouton de partie contre l'ordi

        name = names_b[ib].get_label();
        if(coul == 'n') name = names_n[in].get_label();
        title.append(name);

        Gtk::MessageDialog confirmation("", true, Gtk::MESSAGE_QUESTION, Gtk::BUTTONS_YES_NO);
        confirmation.set_position(Gtk::WIN_POS_CENTER);
        confirmation.set_border_width(10);
        confirmation.set_title(title);
        title = "La suppression de ''";
        title.append(name);
        title.append("'' effacera aussi ses scores.\n\nVoulez-vous vraiment supprimer definitivement ce joueur ?");
        confirmation.set_message(title);
        if(confirmation.run() == Gtk::RESPONSE_YES)     // OK => suppression du joueur dans le fichier + M�J des boutons radio
        {
            std::string suppr, contenu_tot = "$IA_ordi\n", temp, temp2;
            char car = 'a';
            if(coul == 'n') suppr = names_n[in].get_label();
            else suppr = names_b[ib].get_label();

            std::ifstream fichier("scores.sav", std::ios::in);
            if(fichier)
            {
                fichier.ignore(10, '\n');       // passe la premiere ligne
                fichier.get(car);
                while(car != '$')               // sauvegarde les parties de l'ordi jusqu'� un $
                {
                    temp = car;
                    contenu_tot.append(temp);
                    getline(fichier, temp);
                    contenu_tot.append(temp);
                    contenu_tot.append("\n");
                    fichier.get(car);
                }    //Le curseur est apres le $ devant le nom du joueur
                while(car == '$')               // On regarde si le nom est celui � supprimer....
                {
                    fichier >> temp;
                    fichier.get(car);
                    while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces
                    {
                        temp.append(" ");
                        fichier >> temp2;
                        temp.append(temp2);
                        fichier.get(car);
                    }
                    if(temp != suppr)   // Si c'est PAS ce nom-l�, Sauvegarde des lignes suivantes dans contenu_tot
                    {
                        contenu_tot.append("$");
                        contenu_tot.append(temp);
                        contenu_tot.append("\n");
                        fichier.get(car);
                        while(car != '$')               // sauvegarde les parties jusqu'au joueur suivant
                        {
                            temp = car;
                            contenu_tot.append(temp);
                            getline(fichier, temp);
                            contenu_tot.append(temp);
                            contenu_tot.append("\n");
                            fichier.get(car);
                        }    //Le curseur est apres le $ devant le nom du joueur
                    }
                    else fichier.ignore(10000, '$');             // le curseur est apres le $ suivant
                }
                if(!fichier.eof()) contenu_tot.append("$");
                while(getline(fichier, temp))       // Sauvegarde de la fin du fichier
                {
                    contenu_tot.append(temp);
                    contenu_tot.append("\n");
                }
            }
            else
            {
                Gtk::MessageDialog dialogue("Fichier introuvable ou corrompu :(", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_CLOSE);
                dialogue.set_title("Erreur fatale");
                dialogue.set_secondary_text("   Le fichier <b>'scores.sav'</b> n'a pas pu etre ouvert ! Le joueur n'a pas pu �tre supprime car"\
                                            " les sauvegardes sont perdues. Reinstallez le programme pour corriger le probleme :-S", true);
                dialogue.run();
            }
            fichier.close();
            std::ofstream fic("scores.sav", std::ios::out | std::ios::trunc);   // R��crit le contenu dans le fichier
            if(fic) fic << contenu_tot;
            fic.close();
            // Remise en place des radiobutton de l'interface
            if(coul == 'o')
            {
                for(int j=ib; j<10; j++)
                {
                    if(j==9)    // Si on est arriv� � la fin de la liste
                    {
                        names_b[j].set_label("");
                        names_b[j].hide();
                        // Si on suppr le dernier bouton de la liste, on met actif le bouton pr�c�dent
                        if(names_b[j].get_active()) names_b[8].get_active();
                    }
                    else if(names_b[j+1].get_label() == "")     // Sinon si on est positionn� sur le dernier joueur
                    {
                        names_b[j].set_label("");
                        names_b[j].hide();
                        // Si on supprime le premier �l�ment (on desactive ts les boutons)
                        if(j == 0) names_b[0].set_active(false);
                        // Sinon si le dernier bouton de la liste est actif, on met actif le bouton pr�c�dent
                        else if(names_b[j].get_active()) names_b[j-1].set_active();
                    }
                    else names_b[j].set_label(names_b[j+1].get_label());
                }
            }
            else
            {
                if(coul == 'n')     // Permute ib et in
                {
                    int temp = ib;
                    ib = in;
                    in = temp;
                }
                for(int j=ib; j<10; j++)
                {
                    if(j==9 || names_b[j+1].get_label() == "")     // Si on est positionn� sur le dernier joueur
                    {
                        names_b[j].set_label("");
                        names_n[j].set_label("");
                        names_b[j].hide();
                        names_n[j].hide();
                        // Si on supprime le premier �l�ment (on desactive tous les boutons)
                        if(j == 0)
                        {
                            names_b[0].set_active(false);
                            names_n[0].set_active(false);
                        }
                        // Sinon si on suppr le dernier bouton de la liste, on met actif le bouton pr�c�dent
                        else
                        {
                            if(names_b[j].get_active()) names_b[j-1].set_active();
                            if(names_n[j].get_active()) names_n[j-1].set_active();
                        }
                    }
                    else
                    {
                        names_b[j].set_label(names_b[j+1].get_label());
                        if(names_b[j+1].get_active()) names_b[j].set_active();
                        names_n[j].set_label(names_n[j+1].get_label());
                        if(names_n[j+1].get_active()) names_n[j].set_active();
                    }
                }
            }
        }
    }
}
