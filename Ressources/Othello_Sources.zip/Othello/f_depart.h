#ifndef F_DEPART_H
#define F_DEPART_H

#include "inter.h"

// Affichage de la 1�re fen�tre pour le choix de l'action de d�part.
class f_depart : public Gtk::Window
{
private:
    DATA donnees;
    Gtk::VBox boxppale;
    Gtk::HBox box, nouvbox;
    Gtk::EventBox evbox_around_box;
    Gtk::Button nv1, nv2, charger, quit;
    Gtk::Label fra_lbl_nouv, infos;
    Gtk::Frame fra;
    Gtk::Image img1, img2, img3, img4;

// Callback pour la r�initialisation du label lorsqu'on quitte la zone des boutons.
// Le Callback pour ce signal a des param�tres diff�rents !
    bool init_labl(GdkEventCrossing* event);
// Callback pour la mise a jour du label lors du survol des boutons
    void set_lab(std::string str);
// Callback lors du clic sur 'ptite croix'
    bool on_quit(GdkEventAny* event);

public:
    f_depart();
    DATA get_donnees();
// Callback qui cr�e une fen�tre interm�diaire de type 'choix' (chargement fichier etc...)
    void fen_inter(int choix);
};
#endif // F_DEPART_H
