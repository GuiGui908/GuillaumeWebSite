#ifndef FENETRE_PPALE_HPP_INCLUDED
#define FENETRE_PPALE_HPP_INCLUDED

#include <gtkmm/stock.h>    // Pour les variables, cf : "developer.gnome.org/gtkmm/2.20/namespaceGtk_1_1Stock.html"
#include <sstream>
#include "Othellier.h"
#include "f_depart.h"

// Affichage de la fen�tre principale du jeu (avec l'othellier).
class Fenetre : public Gtk::Window
{
private :
    Gtk::VBox boite;            // Contient la barre de menu, la HBox, la barre d'�tat
    Gtk::HBox boiteh;           // Contient les widgets centraux de la fen�tre
    Gtk::VBox boitevdroite;     // Contient tous les widgets � droite du tableau
// Contient les noms des joueurs et les scores
    Gtk::HBox boitetop, boitenom, scores, scoreG0, scoreG9, scoreD0, scoreD9;

    Gtk::MenuBar barremenu;     // Barre de menu horizontale
    Gtk::Menu menufic;          // Boites de menu verticale
    Gtk::Menu menuaprop;

    Gtk::MenuItem itemfic;      // Items de la barre de menu horizontale
    Gtk::MenuItem itemaprop;

    Gtk::ImageMenuItem itemnv_2pl;  // Items de la boite de menu verticale
    Gtk::ImageMenuItem itemnv_ordi;
    Gtk::ImageMenuItem itemop;
    Gtk::ImageMenuItem itemsav;
    Gtk::ImageMenuItem itemsavss;
    Gtk::MenuItem itemscore;
    Gtk::SeparatorMenuItem separateur;
    Gtk::ImageMenuItem itemquit;

    Gtk::ImageMenuItem itemregle;
    Gtk::ImageMenuItem itemapro;

    Gtk::Statusbar barreEtat;   // Barre d'�tat du bas

    Gtk::Table tableau;         // Table contant les eventbox "box" contant les images "cell"
    Gtk::Image cell[8][8];
    Gtk::EventBox box[8][8];

// Widgets � droite de la table
    Gtk::Image flecheG, flecheD, tiret, vide, chiffre[4][10];
    Gtk::Label nomG, nomD, N, B;
    Gtk::Frame frameinfos;
    Gtk::ScrolledWindow bardefil;
    Gtk::TextView infos;
    Glib::RefPtr<Gtk::TextBuffer> buffer;
    Gtk::Button retour;

    DATA donn_fen;
    liste Lis;          // Objet pour la liste des images � changer dans "Fenetre::survol"
    liste lijoue;       // Objet pour la liste des images � changer dans "Fenetre::joue"
    liste_cp listcoup;  // Objet pour la liste des coups l�gaux (coordonnees + liste des images a changer)
    Othellier Oth;      // Objet pour l'othellier en m�moire (pour les calculs)
    f_depart outil;     // Objet contenant les boites de dialogues nouveau, charger... dans la fonction 'callback'

public :
    Fenetre(DATA donnees);
    DATA get_donnee();
// Callback pour l'affichage des images en relief et des "pions gris"
    bool survol(GdkEventCrossing* event, int x, int y, bool entre);
// Callback definir le fond d'ecran de la fenetre
    bool bg(GdkEventExpose* event);
// Cache et montre les images du score et d'a qui le tour
    void majscores();
// Callback (click) pour jouer : placer le pion ici
    bool joue(GdkEventButton* event, int x, int y);
// Callback (click) pour jouer : placer le pion ici puis faire jouer l'ordi
    bool joue_ordi(GdkEventButton* event, int x, int y);
// Jeu de l'ordi gr�ce � l'algo alpha-beta
    void choix_coup();
// Callback pour ajouter le message msg a la barre d'�tat (supprime ts les msg pcdts)
    void set_barre(std::string msg);
// Ajoute � la suite de la zone d'infos le msg pr�c�d� d'un '\n'
    void set_information(std::string msg);
// Callback qui cr�ee la boite de dialogue a propos
    void a_propos();
// Callback qui cr�ee la boite de dialogue des r�gles
    void regles();
// Callback pour la fenetre de nouvelle partie - 2 joueurs
    void nv_2pl();
// Callback pour la fenetre de nouvelle partie - vs pc (alpha beta)
    void nv_ordi();
// Callback pour la fenetre de selection de fichier
    void charge();
// Boite de dialogue de fin de partie.
// etat vaut : 0=Oth complet  1=Les blancs non plus peuvent pas jouer  2=les noirs non plus...
    void gameover(int etat);
// Callback pour la fenetre d'affichage des scores
    void aff_score();
// Suppression des statistiques des parties d'1 ou ts les joueurs
    void init_stats(std::string name);
};
#endif // FENETRE_PPALE_HPP_INCLUDED
