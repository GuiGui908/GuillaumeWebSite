// Voir le site : https://cours.etsmtl.ca/SEG/FHenri/inf145/Suppl%C3%A9ments/Listes%20cha%C3%AEn%C3%A9es.htm
#ifndef LISTE_H_INCLUDED
#define LISTE_H_INCLUDED

#include "maillon.h"

// Liste conteant les images a modifier lors du survol de la souris sur l'othellier
class liste
{
private :
    maillon * tete;    // Pointeur sur le premier maillon.
    int nb_maillons;   // Nombre de maillons de la liste.

public :
    liste();
    int get_nb_maillons();
// Ajout d'un maillon au d�but de la liste
    void add_beginning(int x, int y, char coul_init, char coul_a_mettre);
// Suppression de maillons
    void remove_beginning();    // Supprime le premier maillon
    void empty();               // Vide la liste enti�rement
// Consultation et r�cup�ration des donn�es de la liste.
    bool consult(int position, int &x, int &y, char &c_i, char &c_m);
// Test de vacuit�
    bool vide();
};
#endif // LISTE_H_INCLUDED
