#include "Othellier.h"


Othellier::Othellier(int diffi)      // CONSTRUCTEUR
{
    scoreB = 2;
    scoreN = 2;
    joueur = 'n';
    difficulte = diffi;
    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
            t[i][j]='v';

    t[3][3]='n';
    t[4][4]='n';
    t[3][4]='b';
    t[4][3]='b';
}

char Othellier::get_joueur()    // ACCESSEUR
{
    return joueur;
}

void Othellier::get_score(int &noirDiz, int &noirUni, int &blancDiz, int &blancUni)
{
    noirUni = scoreN%10;
    noirDiz = (scoreN-noirUni)/10;
    blancUni = scoreB%10;
    blancDiz = (scoreB-blancUni)/10;
}

char Othellier::opp()
{
    if(joueur == 'n') return 'b';
    else return 'n';
}

void Othellier::switch_camp()
{
    if(joueur == 'n') joueur = 'b';
    else joueur = 'n';
    std::cout << "<SWITCH> scores N,B : " << scoreN << "," << scoreB << ".  " << joueur << " va jouer :" << std::endl;
}

bool Othellier::complet()
{
    return (scoreB+scoreN == 64);
}

void Othellier::joue(int x, int y, liste &retourne)
{
    int X=x, Y=y;
    if(y<6)         // haut
    {
        for(y++; y<7 && t[x][y] == opp(); y++); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y+1)
        {
            for(y--; t[x][y]!='v'; y--)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        y = Y;
    }
    if(y>1)         // bas
    {
        for(y--; y>0 && t[x][y] == opp(); y--); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y-1)
        {
            for(y++; t[x][y]!='v'; y++)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        y = Y;
    }
    if(x<6)         // Droite
    {
        for(x++; x<7 && t[x][y] == opp(); x++); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && x!=X+1)
        {
            for(x--; t[x][y]!='v'; x--)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        x = X;
    }
    if(x>1)         // Gauche
    {
        for(x--; x>0 && t[x][y] == opp(); x--); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && x!=X-1)
        {
            for(x++ ; t[x][y]!='v'; x++)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        x = X;
    }
    if(y<6 && x<6)         // Haut-Droite
    {
        for(x++, y++; x<7 && y<7 && t[x][y] == opp(); x++, y++); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y+1)
        {
            for(x--, y--; t[x][y]!='v'; x--, y--)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        x = X;
        y = Y;
    }
    if(y<6 && x>1)         // Haut-Gauche
    {
        for(y++, x--; y<7 && x>0 && t[x][y] == opp(); x--, y++); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y+1)
        {
            for(x++, y--; t[x][y]!='v'; x++, y--)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        x = X;
        y = Y;
    }
    if(y>1 && x<6)         // Bas-Droite
    {
        for(y--, x++; y>0 && x<7 && t[x][y] == opp(); x++, y--); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y-1)
        {
            for(x--, y++; t[x][y]!='v'; x--, y++)
            {
                retourne.add_beginning(x,y, opp(), opp());
                t[x][y]=joueur;
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }
        x = X;
        y = Y;
    }
    if(y>1 && x>1)         // Bas-Gauche
    {
        for(y--, x--; y>0 && x>0 && t[x][y] == opp(); x--, y--); // va a la fin de la s�rie de pions de couleur opposee.
        if(t[x][y]==joueur && y!=Y-1)
        {
            for(x++, y++; t[x][y]!='v'; x++, y++)
            {
                t[x][y]=joueur;
                retourne.add_beginning(x,y, opp(), opp());
                if(joueur == 'n')
                {
                    scoreN++;
                    scoreB--;
                }
                else
                {
                    scoreB++;
                    scoreN--;
                }
            }
        }

    }
    t[X][Y]=joueur;
    retourne.add_beginning(X, Y, 'v', joueur);
    if(joueur == 'n') scoreN++;
    else scoreB++;
}

void Othellier::remet(liste retournes)
{
    int x, y, plafond = retournes.get_nb_maillons();
    char c1, c2;
//    std::cout<< "RePLACE :" << std::endl;
    for(int i=1; i<=plafond; i++)    // Parcourre la liste des pions retourn�s
    {
        retournes.consult(i, x, y, c1, c2);
        std::cout<<std::endl<< "remet, dans (" << x<< ", "<< y<< ") il y avait un " << c1 << c2 ;
        t[x][y] = c1;
        if(c1 == 'b')       // A l'origine il y avait un 'b' dans (x,y) � la place d'un 'n'
        {
            scoreN--;
            scoreB++;
        }
        else if(c1 == 'n')
        {
            scoreN++;
            scoreB--;
        }
        else    // c1 == 'v' : A l'origine il y avait un 'v' dans (x,y) � la place d'un 'b' ou 'n'
        {
            if(c2 == 'b') scoreB--;
            else scoreN--;
        }
    }
}

void Othellier::remplir_l(liste &Lis, int x, int y)
// Lis contient la liste des pions a retourner lors du survol des cases
{
    int X=x, Y=y;       // Sauvegardes de x et y.

    char relief;
    if(joueur=='n') relief = 'N';
    else relief = 'B';

    if(t[x][y]=='n') Lis.add_beginning(x, y, 'n', 'N');         // Pion noir
    else if(t[x][y]=='b') Lis.add_beginning(x, y, 'b', 'B');    // Pion blanc
    else     // Pion vide
    {
        if(y<6)         // Haut
        {
            for(y++; y<7 && t[x][y] == opp(); y++); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y+1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(y--; y!=Y; y--) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        y = Y;
        if(y>1)         // Bas
        {
            for(y--; y>0 && t[x][y] == opp(); y--); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y-1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(y++; y!=Y; y++) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        y = Y;
        if(x<6)         // Droite
        {
            for(x++; x<7 && t[x][y] == opp(); x++); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && x!=X+1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(x--; x!=X; x--) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        x = X;
        if(x>1)         // Gauche
        {
            for(x--; x>0 && t[x][y] == opp(); x--); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && x!=X-1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(x++; x!=X; x++) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        x = X;
        if(y<6 && x<6)         // Haut-Droite
        {
            for(x++, y++; x<7 && y<7 && t[x][y] == opp(); x++, y++); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y+1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(x--, y--; x!=X && y!=Y; x--, y--) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        x = X;
        y = Y;
        if(y<6 && x>1)         // Haut-Gauche
        {
            for(y++, x--; y<7 && x>0 && t[x][y] == opp(); x--, y++); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y+1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(y--, x++; x!=X && y!=Y; y--, x++) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        x = X;
        y = Y;
        if(y>1 && x<6)         // Bas-Droite
        {
            for(y--, x++; y>0 && x<7 && t[x][y] == opp(); x++, y--); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y-1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(y++, x--; x!=X && y!=Y; y++, x--) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        x = X;
        y = Y;
        if(y>1 && x>1)         // Bas-Gauche
        {
            for(y--, x--; y>0 && x>0 && t[x][y] == opp(); x--, y--); // va a la fin de la s�rie de pions de joueur opposee.
            if(t[x][y]==joueur && y!=Y-1)
            {
                Lis.add_beginning(x, y, joueur, relief);
                for(y++, x++; x!=X && y!=Y; y++, x++) Lis.add_beginning(x, y, opp(), 'G');
                Lis.add_beginning(x, y, 'v', relief);
            }
        }
        if(Lis.vide()) Lis.add_beginning(X, Y, 'v', 'V');
    }
}

void Othellier::joue_ordi(liste &lij)
// Renvoie la liste des pions a retourner graphiquement.
// appelS de alpha beta !!
{
    liste_cp lcp;
    gen_coup_legal(lcp);
    int numero_max=1, x, y, res, max=-200, plafond = lcp.get_nb_maillons();
    liste retourne;
    joueur_init = joueur;
    if(plafond == 1)        // Si il y a 1 coup legal. c'est ce coup qu'on joue (numero_max) et on saute le for.
    {
        numero_max = 1;
        plafond = 0;
        std::cout<< "un seul coup possible. "<<joueur<<" le joue immediatement !!";
    }
    for(int i=1; i<=plafond; i++)           // Parcourre la liste des coups
    {
        lcp.consult(i, x, y, lij);
        retourne.empty();
        joue(x, y, retourne);
        std::cout << std::endl << std::endl << "vient d'appeler joue sur " <<x << y<<  " au camp "<< joueur<< ". Il y  a " << scoreN << ","<<scoreB<< std::endl;
        switch_camp();
        if(joueur_init == 'n')   // ici 'res' est l'oppos� de la valeur retourn�e par l'alpha-beta car c'est le joueur noir (humain) qui joue
            res = -alpha_beta(1, -200, 200);
        else
            res = alpha_beta(1, -200, 200);
        std::cout<< i << ": " << joueur << " place en " << x << y << " => eval = " << res << "  Il y a tjrs "<<scoreN<<","<<scoreB<< "???  ";
        remet(retourne);
        std::cout<< "REPLACE. A NV " << scoreN<<","<<scoreB<<std::endl;
        if(res > max)			 // Cherche la + grande valeur retourn�e par l'algo parmi tous les coups
        {
            max = res;
            numero_max = i;
        }
        joueur = joueur_init;
    }
    lcp.consult(numero_max, x, y, lij); // pour initialiser lij car il est "retourn�"
    joue(x, y, retourne);
    lcp.empty();
    std::cout << std::endl << "Conclusion : Meilleur coup choisi = " << x << y << std::endl;
}

void Othellier::gen_coup_legal(liste_cp &Lcoup)
{
    for(int x=0; x<8; x++)
    {
        for(int y=0; y<8; y++)
        {
            liste Leg;
            remplir_l(Leg, x, y);
            if(Leg.get_nb_maillons() > 1) Lcoup.add_beginning(x, y, Leg);
        }
    }
}

int Othellier::alpha_beta(int profondeur, int a, int b)
// AMI = ORDINATEUR = joueur_init
{
    if(profondeur == difficulte)
    {
        std::cout<<"eval"<<scoreB<<"-"<<scoreN<<".";    // Si on a atteint la profondeur max
        return scoreB-scoreN;
    }
    bool coupea, coupeb;
    liste_cp lcoup;
    liste retourne;
    gen_coup_legal(lcoup);
    if(lcoup.get_nb_maillons() == 0)                    // Si la liste de coups est vide
    {
        if(joueur == joueur_init)
        {
            std::cout<<"Fin de partie (pronostic la victoire de "<< opp() <<") ds a_b"<<std::endl;
            return -200;
        }
        else
        {
            std::cout<<"Fin de partie (pronostic la victoire de "<< joueur <<") ds a_b"<<std::endl;
            return 200;
        }
    }
    std::cout<< joueur <<" fait 1 a_b pr jouer... joueur init est le "<< joueur_init << std::endl;
    if(joueur == joueur_init)       // Calcul des coups AMI (maximise)
    {
        int plafond = lcoup.get_nb_maillons();
        coupeb = false;
        for(int i=1; !coupeb && i<=plafond; i++)    // Parcourre la liste des coups
        {
            int temp, x ,y;
            liste lij;
            lcoup.consult(i, x, y, lij);
            retourne.empty();
            joue(x, y, retourne);
            std::cout<< "joueur " << joueur << " place en " << x<<y<<"  -> ";
            if(profondeur != difficulte-1) switch_camp();
            temp = alpha_beta(profondeur+1, a, b);
            if(temp > a) a = temp;
            if(b<=a) coupeb = true;
            remet(retourne);
            std::cout<< "Remet le '"<<x<<y<<"' pr un score de "<<scoreN<<","<<scoreB<<"   [if]"<<std::endl<<std::endl;
        }
        if(coupeb) return b;
        else return a;
    }
    else           // Calcul des coups ENNEMI (minimise)
    {
        int plafond = lcoup.get_nb_maillons();
        coupea = false;
        for(int i=1; !coupea && i<=plafond; i++)    // Parcourre la liste des coups
        {
            int temp, x ,y;
            liste lij;
            lcoup.consult(i, x, y, lij);
            retourne.empty();
            joue(x, y, retourne);
            std::cout<< "joueur " << joueur << " place en " << x<<y<<"  -> ";
            if(profondeur != difficulte-1) switch_camp();
            temp = alpha_beta(profondeur+1, a, b);
            if(temp < b) b = temp;
            if(b<=a) coupea = true;
            remet(retourne);
            std::cout<< "   Remet le '"<<x<<y<<"' pr un score de "<<scoreN<<","<<scoreB<<"   [else]"<<std::endl<<std::endl;
        }
        if(coupea) return a;
        else return b;
    }
}
