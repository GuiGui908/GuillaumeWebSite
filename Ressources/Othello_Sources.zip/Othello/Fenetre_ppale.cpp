#include "Fenetre_ppale.h"

// ACCESSEUR
DATA Fenetre::get_donnee()
{
    return donn_fen;
}

// CONSTRUCTEUR
Fenetre::Fenetre(DATA donnees) :
// Liste d'initialisation : initialisation des widgets d�clar�s en attibuts de la classe.
    boite(false, 20),
    boiteh(false),
    boitevdroite(false),
    boitetop(false),
    boitenom(false),
    scores(false),
    scoreG0(false),
    scoreG9(false),
    scoreD0(false),
    scoreD9(false),
    itemfic("_Fichier", true),
    itemaprop("_Aide", true),
    itemnv_2pl("_Nouvelle partie contre une personnne", true),
    itemnv_ordi("Nouvelle partie contre l'ordinateur"),
    itemop(Gtk::Stock::OPEN),
    itemsav(Gtk::Stock::SAVE),
    itemsavss(Gtk::Stock::SAVE_AS),
    itemscore("Scores"),
    itemquit(Gtk::Stock::QUIT),
    itemregle("Regles"),
    itemapro(Gtk::Stock::ABOUT),
    tableau(8, 8),
    cell(),
    flecheG("img/Droite/flecheg.png"),
    flecheD("img/Droite/fleched.png"),
    tiret("img/Droite/tiret.png"),
    vide("img/Droite/vide.png"),
    chiffre(),
    buffer(infos.get_buffer()),
    retour("Annuler le dernier coup joue par l'utilisateur"),
    donn_fen(donnees),
    Oth(donnees.difficulte)
{
    /* Load background image
        Glib::RefPtr<Gdk::Pixmap> pixmap;
        Glib::RefPtr<Gdk::Bitmap> mask;
        pixbuf = Gdk::Pixbuf::create_from_file("img/Background.jpg");
        pixbuf->render_pixmap_and_mask(pixmap, mask, 0);*/

    donn_fen.reponse = 0;       // quitte le while du main si la fen�tre est d�truite sans changer reponse.

// Propri�t�s de la fen�tre
//    signal_expose_event().connect(sigc::mem_fun(*this, &Fenetre::bg), false);
    set_title("Othello");
    set_icon_from_file("img/Icone.png");
    set_position(Gtk::WIN_POS_CENTER);
    add(boite);

// Barre d'�tat
    boite.pack_end(barreEtat, Gtk::PACK_SHRINK);
    barreEtat.push("Bienvenue :)");


// Barre de menu
    boite.pack_start(barremenu, Gtk::PACK_SHRINK);
    barremenu.append(itemfic);
    itemfic.signal_deselect().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), ""));
    itemfic.set_submenu(menufic);
    menufic.append(itemnv_2pl);
    itemnv_2pl.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::nv_2pl));
    itemnv_2pl.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Demarre une nouvelle partie contre un deuxieme joueur"));

    menufic.append(itemnv_ordi);
    itemnv_ordi.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::nv_ordi));
    itemnv_ordi.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Demarre une nouvelle partie contre l'ordinateur (Alpha-Beta)"));

    menufic.append(itemop);
    itemop.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::charge));
    itemop.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Charge une ancienne partie depuis une sauvegarde"));

    menufic.append(itemsav);
    itemsav.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Enregistre la partie en cours"));

    menufic.append(itemsavss);
    itemsavss.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Enregistre la partie en cours sous un nouveau nom"));

    menufic.append(itemscore);
    itemscore.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::aff_score));
    itemscore.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Revoir ses performances precedentes"));
    menufic.append(separateur);    // A l'origine des 2 warnings quand on quitte :((

    menufic.append(itemquit);
    itemquit.signal_activate().connect(sigc::ptr_fun(Gtk::Main::quit));
    itemquit.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Quitte le jeu"));

    barremenu.append(itemaprop);
    itemaprop.set_submenu(menuaprop);
    itemaprop.signal_deselect().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), ""));
    menuaprop.append(itemregle);
    itemregle.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Regles du jeu"));
    itemregle.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::regles));

    menuaprop.append(itemapro);
    itemapro.signal_select().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &Fenetre::set_barre), "Informations sur le jeu, la version..."));
    itemapro.signal_activate().connect(sigc::mem_fun(*this, &Fenetre::a_propos));

// Table de l'othellier (+ signaux)
    boite.pack_start(boiteh);
    boiteh.pack_start(tableau, Gtk::PACK_SHRINK, 20);
    if(donnees.reponse == 1)
    {
        for(int i=0; i<8; i++)
        {
            for(int j=0; j<8; j++)
            {
                cell[i][j].set("img/Othellier/vide.png");
                box[i][j].add(cell[i][j]);
                box[i][j].add_events(Gdk::ENTER_NOTIFY_MASK);
                box[i][j].add_events(Gdk::BUTTON_RELEASE_MASK);
                box[i][j].signal_enter_notify_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::survol), i, j, true));
                box[i][j].signal_leave_notify_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::survol), i, j, false));
                box[i][j].signal_button_release_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::joue), i, j));
                tableau.attach(box[i][j], i, i+1, 7-j, 8-j, Gtk::SHRINK, Gtk::SHRINK);
            }
        }
    }
    else if(donnees.reponse == 2)
    {
        for(int i=0; i<8; i++)
        {
            for(int j=0; j<8; j++)
            {
                cell[i][j].set("img/Othellier/vide.png");
                box[i][j].add(cell[i][j]);
                box[i][j].add_events(Gdk::ENTER_NOTIFY_MASK);
                box[i][j].add_events(Gdk::BUTTON_RELEASE_MASK);
                box[i][j].signal_enter_notify_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::survol), i, j, true));
                box[i][j].signal_leave_notify_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::survol), i, j, false));
                box[i][j].signal_button_release_event().connect(sigc::bind<int, int>(sigc::mem_fun(*this, &Fenetre::joue_ordi), i, j));
                tableau.attach(box[i][j], i, i+1, 7-j, 8-j, Gtk::SHRINK, Gtk::SHRINK);
            }
        }
    }
    else
    {
    }

// Initialisation des 4 pions de d�but
    if(donnees.reponse == 3)         // Si on charge une nouvelle partie
    {
    }
    else
    {
        cell[3][3].set("img/Othellier/noir.png");
        cell[4][4].set("img/Othellier/noir.png");
        cell[3][4].set("img/Othellier/blanc.png");
        cell[4][3].set("img/Othellier/blanc.png");
        if(donnees.nomN == "IA_ordi")
        {
            Oth.gen_coup_legal(listcoup);
            std::cout<< "Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
            choix_coup();
            listcoup.empty();
        }
        Oth.gen_coup_legal(listcoup);
        std::cout<< "Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
    }

// Widgets de droite : scores, Noms (Les Noirs a Droite), a qui le tour, infos sur le joueur qui passe son tour
    boiteh.pack_start(boitevdroite, Gtk::PACK_SHRINK, 20);
    boitevdroite.pack_start(boitetop, Gtk::PACK_SHRINK, 15);
    boitetop.pack_start(B);
    boitetop.pack_start(flecheD);
    boitetop.pack_start(flecheG);
    boitetop.pack_start(N);

    N.set_markup("<span font='18' background='black' foreground='white' underline='low' underline_color='#1160ce'>NOIRS</span>");
    B.set_markup("<span font='18' background='white' underline='low' underline_color='#1160ce'>BLANCS</span>");

    flecheG.set_no_show_all();
    flecheD.set_no_show_all();
    if(donn_fen.nomN == "IA_ordi") flecheG.show();
    else flecheD.show();
    boitevdroite.pack_start(boitenom, Gtk::PACK_SHRINK, 10);
    boitevdroite.pack_start(scores, Gtk::PACK_SHRINK, 10);
    boitevdroite.pack_start(frameinfos, Gtk::PACK_EXPAND_WIDGET, 10);
    boitevdroite.pack_start(retour, Gtk::PACK_SHRINK, 10);

    frameinfos.add(bardefil);
    frameinfos.set_label("Informations");
    bardefil.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
    bardefil.set_border_width(6);
    bardefil.add(infos);
    infos.set_wrap_mode(Gtk::WRAP_WORD);
    infos.set_cursor_visible(false);
    infos.set_editable(false);
    infos.set_left_margin(3);
    infos.set_right_margin(3);
    infos.set_justification(Gtk::JUSTIFY_FILL );
    infos.set_pixels_above_lines(2);
    buffer->set_text("Debut de la partie. Les noirs commencent !");

    std::string name = "<span size='xx-large'><u><b>";              // Initialise les labels avec les noms des joueurs pr l'affichage
    std::string ordi = "<span size='xx-large'><u><b>Ordinateur</b></u>\n";
    switch (donn_fen.difficulte)
    {
    case 1 :
        ordi.append("   (Recruit)</span>");
        break;
    case 2 :
        ordi.append("   (Regular)</span>");
        break;
    case 3 :
        ordi.append(" (Hardened)</span>");
        break;
    case 4 :
        ordi.append("  (Veteran)</span>");
    }
    if(donn_fen.nomB == "IA_ordi")
    {
        nomG.set_markup(ordi);
        name.append(donn_fen.nomN);
        name.append("</b></u></span>");
        nomD.set_markup(name);
    }
    else if(donn_fen.nomN == "IA_ordi")
    {
        nomD.set_markup(ordi);
        name.append(donn_fen.nomB);
        name.append("</b></u></span>");
        nomG.set_markup(name);
    }
    else
    {
        name.append(donn_fen.nomB);
        name.append("</b></u></span>");
        nomG.set_markup(name);
        name = "<span size='xx-large'><u><b>";
        name.append(donn_fen.nomN);
        name.append("</b></u></span>");
        nomD.set_markup(name);
    }

    boitenom.pack_start(nomG, Gtk::PACK_SHRINK);
    boitenom.pack_start(vide);
    boitenom.pack_start(nomD, Gtk::PACK_SHRINK);

    scores.pack_start(scoreG0, Gtk::PACK_SHRINK);
    scores.pack_start(scoreG9, Gtk::PACK_SHRINK);
    scores.pack_start(tiret, Gtk::PACK_EXPAND_WIDGET, 30);
    scores.pack_start(scoreD0, Gtk::PACK_SHRINK);
    scores.pack_start(scoreD9, Gtk::PACK_SHRINK);

    int i;
    for(i=0; i<4; i++) chiffre[i][0].set("img/Droite/Chiffres/zero.png");       // Initialiqation des Gtk::images (4 images par chiffre)
    for(i=0; i<4; i++) chiffre[i][1].set("img/Droite/Chiffres/un.png");
    for(i=0; i<4; i++) chiffre[i][2].set("img/Droite/Chiffres/deux.png");
    for(i=0; i<4; i++) chiffre[i][3].set("img/Droite/Chiffres/trois.png");
    for(i=0; i<4; i++) chiffre[i][4].set("img/Droite/Chiffres/quatre.png");
    for(i=0; i<4; i++) chiffre[i][5].set("img/Droite/Chiffres/cinq.png");
    for(i=0; i<4; i++) chiffre[i][6].set("img/Droite/Chiffres/six.png");
    for(i=0; i<4; i++) chiffre[i][7].set("img/Droite/Chiffres/sept.png");
    for(i=0; i<4; i++) chiffre[i][8].set("img/Droite/Chiffres/huit.png");
    for(i=0; i<4; i++) chiffre[i][9].set("img/Droite/Chiffres/neuf.png");
    for(i=0; i<10; i++)                                 // Ajout des Gtk::images dans les box. chacune des 4 box a 10 images.
    {
        for(int j=0; j<4; j++) chiffre[j][i].set_no_show_all();
        scoreG0.pack_start(chiffre[0][i]);
        scoreG9.pack_start(chiffre[1][i]);
        scoreD0.pack_start(chiffre[2][i]);
        scoreD9.pack_start(chiffre[3][i]);
    }
    chiffre[0][0].show();       // Le chiffre n�0 (les dizaines � gauche) est le 0
    if(donn_fen.nomN == "IA_ordi") chiffre[1][1].show();       // Le chiffre n�1 (les unites � gauche) est le 2 (ou 1) etc..........
    else chiffre[1][2].show();
    chiffre[2][0].show();
    if(donn_fen.nomN == "IA_ordi") chiffre[3][4].show();
    else chiffre[3][2].show();

    boite.show_all();
}

bool Fenetre::survol(GdkEventCrossing* event, int x, int y, bool entre)
// Quand la souris entre (entre==true) ou sort (entre==false) de l'eventbox[x][y], affichage/suppr des images en relief.
// Retourne false pour que le signal soit propag� plus loin.
{
    int a, b;
    char c1, c2;
    if(entre)
    {
        Lis.empty();
        Oth.remplir_l(Lis, x, y);
        int plafond = Lis.get_nb_maillons();
        for(int i=1; i<=plafond; i++)       // Parcourre la liste des changements d'image
        {
            if(Lis.consult(i, a, b, c1, c2))// Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
            {
                switch (c2)                 // Remplace l'image par la nouvelle command�e par le caract�re c2
                {
                case 'v':
                    cell[a][b].set("img/Othellier/vide.png");
                    break;
                case 'V':
                    cell[a][b].set("img/Othellier/vide_rel.png");
                    break;
                case 'n':
                    cell[a][b].set("img/Othellier/noir.png");
                    break;
                case 'N':
                    cell[a][b].set("img/Othellier/noir_rel.png");
                    break;
                case 'b':
                    cell[a][b].set("img/Othellier/blanc.png");
                    break;
                case 'B':
                    cell[a][b].set("img/Othellier/blanc_rel.png");
                    break;
                case 'G':
                    cell[a][b].set("img/Othellier/gris.png");
                    break;
                default :
                    cell[a][b].set("img/Othellier/img_err");
                }
            }
        }
    }
    else        // De m�me si la souris sort (on change l'image par celle command�e par c1)
    {
        int plafond = Lis.get_nb_maillons();
        for(int i=1; i<=plafond; i++)
        {
            if(Lis.consult(i, a, b, c1, c2))
            {
                switch (c1)
                {
                case 'v':
                    cell[a][b].set("img/Othellier/vide.png");
                    break;
                case 'V':
                    cell[a][b].set("img/Othellier/vide_rel.png");
                    break;
                case 'n':
                    cell[a][b].set("img/Othellier/noir.png");
                    break;
                case 'N':
                    cell[a][b].set("img/Othellier/noir_rel.png");
                    break;
                case 'b':
                    cell[a][b].set("img/Othellier/blanc.png");
                    break;
                case 'B':
                    cell[a][b].set("img/Othellier/blanc_rel.png");
                    break;
                case 'G':
                    cell[a][b].set("img/Othellier/gris.png");
                    break;
                default :
                    cell[a][b].set("img/Othellier/img_err");
                }
            }
        }
    }
    return false;
}

bool Fenetre::bg(GdkEventExpose* event)
{

    /*Glib::RefPtr<Gtk::Style> style = this->get_style();
    this->get_window()->draw_pixbuf(style->get_bg_gc(Gtk::STATE_NORMAL), pixbuf, 0, 0, 0, 0, pixbuf->get_width(), pixbuf->get_height(), Gdk::RGB_DITHER_NONE, 0, 0);*/
    return false;
}

void Fenetre::majscores()
{
    if(Oth.get_joueur() == 'n') // fleche vers la droite si les noirs jouent
    {
        flecheD.show();
        flecheG.hide();
    }
    else                  // vers la gauche si c'est les blancs
    {
        flecheG.show();
        flecheD.hide();
    }

    int Ndiz, Nuni, Bdiz, Buni;
    Oth.get_score(Ndiz, Nuni, Bdiz, Buni);
    for(int j=0; j<10; j++)         // Changement des images des chiffres pour le score
    {
        if(chiffre[0][j].get_visible() && j!=Bdiz)          // si ce chiffre a chang�...
        {
            chiffre[0][j].hide();
            chiffre[0][Bdiz].show();
        }
        if(chiffre[1][j].get_visible() && j!=Buni)          // si ce chiffre a chang�...
        {
            chiffre[1][j].hide();
            chiffre[1][Buni].show();
        }
        if(chiffre[2][j].get_visible() && j!=Ndiz)          // si ce chiffre a chang�...
        {
            chiffre[2][j].hide();
            chiffre[2][Ndiz].show();
        }
        if(chiffre[3][j].get_visible() && j!=Nuni)          // si ce chiffre a chang�...
        {
            chiffre[3][j].hide();
            chiffre[3][Nuni].show();
        }
    }
}

bool Fenetre::joue(GdkEventButton* event, int x, int y)
{
    if(!listcoup.appartient(x, y, lijoue))      // Coup l�gal ? et en m�me temps recuperation de lijoue (liste des reournements)
    {
        if(Oth.complet()) set_barre("La partie est terminee !");
        else set_barre("Coup INVALIDE. Impossible de placer le pion ici. Consultez les regles !");
    }
    else
    {
        barreEtat.remove_all_messages();
        liste inutile;
        Oth.joue(x, y, inutile);
        int a, b, plafond = lijoue.get_nb_maillons();
        char c1, c2;
        if(Oth.get_joueur() == 'b')
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/blanc.png");
            }
            cell[x][y].set("img/Othellier/blanc_rel.png");
        }
        else
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/noir.png");
            }
            cell[x][y].set("img/Othellier/noir_rel.png");
        }
        Oth.switch_camp();
        majscores();
        Lis.empty();
        Lis.add_beginning(x, y, Oth.opp(), Oth.opp());
        listcoup.empty();
        Oth.gen_coup_legal(listcoup);
        std::cout<< "Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
        if(listcoup.get_nb_maillons() < 1)      // Si pas de coups l�gaux
        {
            if(Oth.complet())   // Fin de la partie
            {
                std::cout<< "Othelier complet !!!";
                gameover(0);
            }
            else            // Dans ce cas, le joueur passe son tour.
            {
                if(Oth.get_joueur() == 'b') set_information("Les blancs passent leur tour !!");
                else set_information("Les noirs passent leur tour !!");
                Oth.switch_camp();
                majscores();            // Change la fleche (a qui le tour)
                listcoup.empty();
                Oth.gen_coup_legal(listcoup);
                std::cout<< "Passe dc recalcul des coups : Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
                if(listcoup.get_nb_maillons() < 1) gameover(Oth.get_joueur() == 'b');     // Si pas de coups l�gaux � nouveau (l'autre camp passe aussi)
            }
        }
    }
    return false;
}

void Fenetre::gameover(int etat)
{
    int a, b, c, d, N, B;
    std::string msg, temp, nom_joueur;
    char car = 'a';
    if(etat == 0) msg = "L'othellier est complet ! ";
    else if(etat == 1) msg = "Les blancs passent aussi leur tour, il n'y a plus de coups possibles ! ";
    else if(etat == 2) msg = "Les noirs passent aussi leur tour, il n'y a plus de coups possibles ! ";
    std::fstream fich("scores.sav", std::ios::in | std::ios::out | std::ios::app);
    if(fich)
    {
        msg.append("Fin du jeu, les scores sont enregistres.\nVictoire de ");
        Oth.get_score(a, b, c, d);
        N = 10*a+b;     // ScoresN
        B = 10*c+d;     // ScoresB
        if(N>B)
        {
            if(donn_fen.nomN == "IA_ordi") msg.append("l'Ordinateur");
            else msg.append(donn_fen.nomN);
        }
        else if(a==c && b==d) msg = "Fin du jeu, les scores sont enregistres.\nMatch Nul";        // Egalit�
        else
        {
            if(donn_fen.nomB == "IA_ordi") msg.append("l'Ordinateur");
            else msg.append(donn_fen.nomB);
        }
        msg.append(" !!!");

        // Ecrit les scores dans le fichier !!
        fich.get(car);
        while(car == '$')       // pour chaque nom du fichier
        {
            fich >> nom_joueur;
            fich.get(car);
            while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces. On a le nom !!
            {
                nom_joueur.append(" ");
                fich >> temp;
                nom_joueur.append(temp);
                fich.get(car);
            }
            if(nom_joueur == donn_fen.nomN || nom_joueur == donn_fen.nomB)     // si le nom est celui du joueur Noir ou Blanc
            {
                int nb_parties = 1;     //nombre de ses parties (commence a 1 car il vient d'en faire 1 de + !!)
                char num;
                fich.get(num);
                while(num != '$')   // compte le nb de parties et positionne le curseur a la fin de ses parties
                {
                    nb_parties++;
                    getline(fich, temp);
                    fich.get(num);
                }
                //revenir d'un caractere (le $) puis ecriture
                if(nom_joueur == donn_fen.nomN)     // scores du joueur noir
                {
                    fich << nb_parties;
                    if(N>B) fich << 'v';        //victoire
                    else if(N==B) fich << 'n';  //nul
                    else fich << 'd';           //defaite
                    fich << N << '-' << B << ' ';
                    if(donn_fen.nomN == "IA_ordi") fich << donn_fen.nomB << ' ' << donn_fen.difficulte << '\n';
                    else if(donn_fen.nomB == "IA_ordi") fich << "IA_ordi" << ' ' << donn_fen.difficulte << '\n';
                    else fich << donn_fen.nomB << '\n';         // aucun des 2 n'est l'ordinateur
                }
                else                                // score du blanc
                {
                    fich << nb_parties;
                    if(N<B) fich << 'v';        //victoire
                    else if(N==B) fich << 'n';  //nul
                    else fich << 'd';           //defaite
                    fich << B << '-' << N << ' ';
                    if(donn_fen.nomN == "IA_ordi") fich << "IA_ordi" << ' ' << donn_fen.difficulte << '\n';
                    else if(donn_fen.nomB == "IA_ordi") fich << donn_fen.nomN << ' ' << donn_fen.difficulte << '\n';
                    else fich << donn_fen.nomN << '\n';         // aucun des 2 n'est l'ordinateur
                }
            }
            fich.get(car);
        }
    }
    else
    {
        msg.append("Fin du jeu, mais le fichier \"scores.sav\" n'a pas pu etre ouvert ! Les statistiques du jeu ne "\
                   "seront pas chargees. Reinstallez le programme pour corriger le probleme :-S");
    }
    fich.close();
    set_barre("La partie est terminee !");
    set_information(msg);
}

bool Fenetre::joue_ordi(GdkEventButton* event, int x, int y)
// Jeu du joueur en case (x, y) puis appel de la fonction pour faire jouer l'ordi.
{
    if(!listcoup.appartient(x, y, lijoue))      // Coup l�gal ? et en m�me temps recuperation de lijoue (liste des reournements)
    {
        if(Oth.complet()) set_barre("La partie est terminee !");
        else set_barre("Coup INVALIDE. Impossible de placer le pion ici. Consultez les regles !");
    }
    else
    {
        barreEtat.remove_all_messages();
        liste inutile;
        Oth.joue(x, y, inutile);
        int a, b, plafond = lijoue.get_nb_maillons();
        char c1, c2;
        if(Oth.get_joueur() == 'b')
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/blanc.png");
            }
        }
        else
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/noir.png");
            }
        }
        Oth.switch_camp();
        majscores();
        Lis.empty();
        Lis.add_beginning(x, y, Oth.opp(), Oth.opp());
        listcoup.empty();
        Oth.gen_coup_legal(listcoup);
        std::cout<< "Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
        if(listcoup.get_nb_maillons() < 1)      // Si pas de coups l�gaux pr l'adverse, l'adverse passe son tour.
        {
            if(Oth.complet())   // Fin de la partie
            {
                std::cout<< "Othelier complet !!!";
                gameover(0);
            }
            else            // Si pas complet, verification que le joueur peut rejouer
            {
                Oth.switch_camp();
                majscores();
                listcoup.empty();
                Oth.gen_coup_legal(listcoup);
                std::cout<< "Passe dc recalcul des coups : Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
                if(listcoup.get_nb_maillons() < 1) gameover(Oth.get_joueur() == 'b');     // Si NON (les 2 passent), FIN DE LA PARTIE
                else                                 // Sinon OUI, seul l'adverse passe son tour
                    set_information("L'ordinateur passe son tour !! :)");
            }
        }
        else choix_coup();            // Sinon, il y a des coups l�gaux, l'adverse (ordi) va choisir le meilleur ^^
    }
    return false;
}

void Fenetre::choix_coup()
// Tant que le joueur passe psk il a plus de coups legaux :
// appel de joue_ordi de la classe Othelier pr avoir la liste des pions a changer graphiquement puis changement des pions !!! Et verif que partie est pas finie ou que le joueur repasse !!
{
    while((donn_fen.nomB == "IA_ordi" && Oth.get_joueur() == 'b') || (donn_fen.nomN == "IA_ordi" && Oth.get_joueur() == 'n'))
    {
        Oth.joue_ordi(lijoue);
        int a, b, plafond = lijoue.get_nb_maillons();
        char c1, c2;
        if(Oth.get_joueur() == 'b')
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/blanc.png");
            }
        }
        else
        {
            for(int i=1; i<=plafond; i++)           // Parcourre la liste des changements d'image
            {
                if(lijoue.consult(i, a, b, c1, c2)) // Si la liste peut etre consult�e (pas d'erreur), on saisi a,b,c1 et c2
                    cell[a][b].set("img/Othellier/noir.png");
            }
        }
        Oth.switch_camp();
        majscores();
        std::cout<< "C'est aux "<<Oth.get_joueur()<< "de jouer.... fin de choix_coup et du jeu de l'ordi."<<std::endl<<std::endl<<std::endl;
        Lis.empty();
        listcoup.empty();
        Oth.gen_coup_legal(listcoup);
        std::cout<< "Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
        if(listcoup.get_nb_maillons() < 1)      // Si pas de coups l�gaux pr l'adverse, l'adverse passe son tour.
        {
            if(Oth.complet())   // Fin de la partie
            {
                std::cout<< "Othelier complet !!!";
                gameover(0);
            }
            else            // Si pas complet, verification que le joueur peut rejouer
            {
                Oth.switch_camp();
                majscores();
                listcoup.empty();
                Oth.gen_coup_legal(listcoup);
                std::cout<< "Passe dc recalcul cp : Il y a " << listcoup.get_nb_maillons() << " coups legaux" << std::endl;
                if(listcoup.get_nb_maillons() < 1) gameover(Oth.get_joueur() == 'b');     // Si NON (les 2 passent), FIN DE LA PARTIE
                else                                 // Sinon OUI, seul l'adverse passe son tour
                    set_information("Le joueur humain passe son tour !! :(");
            }
        }
    }
}

void Fenetre::set_barre(std::string msg)
{
    barreEtat.remove_all_messages();
    barreEtat.push(msg);
}

void Fenetre::set_information(std::string msg)
{
    std::string temp = buffer->get_text();
    temp.append("\n");
    temp.append(msg);
    buffer->set_text(temp);
}

void Fenetre::a_propos()
{
    Gtk::AboutDialog dialogue;
    std::vector<Glib::ustring> Auteurs, Docs, Bugs;

    dialogue.set_position(Gtk::WIN_POS_CENTER);
    dialogue.set_icon(Gdk::Pixbuf::create_from_file("img/Icone.png"));
    dialogue.set_program_name("Othello");
    dialogue.set_version("1.0");
    dialogue.set_copyright("CopyMe 2012");
    dialogue.set_comments("Othello (aussi appelle Reversi) est un jeu de societe qui se joue a 2."\
                          " Le but est d'avoir le plus de pion de sa couleur lorsque le dammier sera complet.");
    Bugs.push_back("BUGS CONNUS :\n\n\nLors du clic sur la petite croix de la fenetre inter,"\
                   " le programme est lanc� comme si on avait cliqu� sur Jouer !!!");
//    dialogue.add_credits_section("Bugs", Bugs);       Fonctionnel a partir de la version 3.4 de gtkmm !!!
    dialogue.set_license("Aucune : Logiciel 100% libre !!");
    dialogue.set_website("http://bert.guillaum.free.fr/Pages/Jeux.html");
    dialogue.set_website_label("Site Web");
    dialogue.set_logo(Gdk::Pixbuf::create_from_file("img/Logo.png"));
    Auteurs.push_back("Guillaume");
    dialogue.set_authors(Auteurs);
    Docs.push_back("www.siteduzero.com/       pour le tuto\ndeveloper.gnome.org/      pour les references gtkmm");
    dialogue.set_documenters(Docs);
    dialogue.run();
}

void Fenetre::regles()
{
    Gtk::Dialog boitregl("Regles du jeu", this);
    Gtk::Box *Vboite(boitregl.get_vbox());
    Gtk::Label titre, contenu1, contenu2, contenu3, site_rules, title_pcpe, title_tour, title_fin;
    Gtk::Image ffo("img/FFO.jpg");
    Gtk::Frame pcpe, tour, fin;

    boitregl.set_position(Gtk::WIN_POS_CENTER);
    boitregl.set_border_width(15);
    boitregl.set_icon(Gdk::Pixbuf::create_from_file("img/Icone.png"));

    Vboite->pack_start(ffo, Gtk::PACK_SHRINK);
    titre.set_markup("\n<span font_size='xx-large' underline='single' foreground='#004cff'><b>Regles du jeu</b></span>");
    Vboite->pack_start(titre, Gtk::PACK_SHRINK, 10);

    contenu1.set_markup("Othello est un jeu de strategie a deux joueurs. "\
                        "Le noir commence a jouer, puis c'est chacun a tour de role.");
    contenu1.set_line_wrap();
    contenu1.set_justify(Gtk::JUSTIFY_FILL);
    title_pcpe.set_markup("<big>Principe</big>");
    pcpe.set_label_widget(title_pcpe);
    pcpe.add(contenu1);
    Vboite->pack_start(pcpe, Gtk::PACK_SHRINK, 3);
    contenu2.set_markup("A chaque tour, le joueur pose son pion sur une case vide, de maniere "\
                        "a retourner au moins un pion adverse. Le retournement s'effectue "\
                        "lorsque le pion qui vient d'etre pose 'prend en sandwich' le(s) "\
                        "pion(s) adverse dans une des 8 directions (horizontale, verticale "\
                        "ou diagonale). Ces derniers sont alors retournes a l'avantage du joueur. "\
                        "Plusieurs encadrements sont parfois possibles en meme temps : tous les "\
                        "pions en sandwich sont retournes. Aucun pion ne peut etre retire ou deplace.");
    contenu2.set_line_wrap();
    contenu2.set_justify(Gtk::JUSTIFY_FILL);
    title_tour.set_markup("<big>Tour</big>");
    tour.set_label_widget(title_tour);
    tour.add(contenu2);
    Vboite->pack_start(tour, Gtk::PACK_SHRINK, 3);
    contenu3.set_markup("Si un joueur n'a pas de coup legal a jouer, il passe son tour et laisse "\
                        "la main a son adversaire. Le jeu s'arrete quand il n'y a plus de "\
                        "possibilite pour aucun des deux joueurs.");
    contenu3.set_justify(Gtk::JUSTIFY_FILL);
    contenu3.set_line_wrap();
    title_fin.set_markup("<big>Fin de partie</big>");
    fin.set_label_widget(title_fin);
    fin.add(contenu3);
    Vboite->pack_start(fin, Gtk::PACK_SHRINK, 3);

    site_rules.set_alignment(0, 0.5);
    site_rules.set_markup("<a href=\"http://www.ffothello.org/jeu/regles.php\">"\
                          "Regles detaillees</a>, plus approfodies.");
    Vboite->pack_start(site_rules, Gtk::PACK_SHRINK, 2);

    boitregl.add_button(Gtk::Stock::CLOSE, Gtk::RESPONSE_CLOSE);
    boitregl.show_all();
    boitregl.run();
}

void Fenetre::nv_2pl()
{
    outil.fen_inter(1);
    donn_fen = outil.get_donnees();
    std::cout << "Reponse=" << donn_fen.reponse << "\nNomB=" << donn_fen.nomB << "\nNomN=" << donn_fen.nomN;
    std::cout << "\nChemin=" << donn_fen.chemin << "\nDifficulte=" << donn_fen.difficulte << "\nEND" << std::endl;
}

void Fenetre::nv_ordi()
{
    outil.fen_inter(2);
    donn_fen = outil.get_donnees();
    std::cout << "Reponse=" << donn_fen.reponse << "\nNomB=" << donn_fen.nomB << "\nNomN=" << donn_fen.nomN;
    std::cout << "\nChemin=" << donn_fen.chemin << "\nDifficulte=" << donn_fen.difficulte << "\nEND" << std::endl;
}

void Fenetre::charge()
{
    outil.fen_inter(3);
    donn_fen = outil.get_donnees();
    std::cout << "Reponse=" << donn_fen.reponse << "\nNomB=" << donn_fen.nomB << "\nNomN=" << donn_fen.nomN;
    std::cout << "\nChemin=" << donn_fen.chemin << "\nDifficulte=" << donn_fen.difficulte << "\nEND" << std::endl;
}

void Fenetre::aff_score()
{
    Gtk::Dialog scr("Tableau des scores");
    Gtk::VBox *intermediaire0(scr.get_vbox());
    Gtk::HBox intermediaire, inbox[11];
    Gtk::Label intitule("   Joueurs :\n_____________\n\n\nParties jouees :\n\n      Victoires :\n\n            Nuls :\n\n\n");
    Gtk::Label stats[11];
    Gtk::Notebook onglet;
    Gtk::TextView details[11];
    Gtk::Frame framedetails[11];
    Gtk::ScrolledWindow defilwin[11];
    Glib::RefPtr<Gtk::TextBuffer> Buff[11];

    scr.set_position(Gtk::WIN_POS_CENTER);
    scr.set_icon(Gdk::Pixbuf::create_from_file("img/Icone.png"));
    scr.set_border_width(4);
    scr.resize(550, 170);
    scr.add_button("Reinitialiser ce joueur", 1);
    scr.add_button("Reinitialiser Tout", 2);
    scr.add_button("Ok", 0);

    intermediaire0->pack_start(intermediaire);
    intermediaire.pack_start(intitule, Gtk::PACK_SHRINK, 0);
    intermediaire.pack_start(onglet);
    onglet.popup_enable();
    onglet.set_scrollable();

    std::ifstream fichier("scores.sav", std::ios::in);
    if(fichier)
    {
        char car;
        bool arret = false;
        int tot_r=0, tot_R=0, tot_H=0, tot_V=0;
        int nbv_r=0, nbv_R=0, nbv_H=0, nbv_V=0;
        int nbnul_r=0, nbnul_R=0, nbnul_H=0, nbnul_V=0;
        std::string temp, tempbis;
        std::ostringstream buffdetail, oss;

        for(int i=0; i<11 && !arret; i++)
        {
            int total=0, vict=0, nul=0;
            fichier >> temp;
            fichier.get(car);
            while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces
            {
                temp.append(" ");
                fichier >> tempbis;
                temp.append(tempbis);
                fichier.get(car);
            }
            if(i==0) onglet.append_page(inbox[i], "Ordinateur");            // creation onglet pr l'ordi
            else onglet.append_page(inbox[i], temp);                        // creation des autres onglets
            inbox[i].pack_start(stats[i], Gtk::PACK_SHRINK, 6);
            inbox[i].pack_start(framedetails[i], Gtk::PACK_EXPAND_WIDGET, 2);
            framedetails[i].add(defilwin[i]);
            framedetails[i].set_label("Detail des parties");
            defilwin[i].set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
            defilwin[i].add(details[i]);
            details[i].set_wrap_mode(Gtk::WRAP_WORD);
            details[i].set_cursor_visible(false);
            details[i].set_editable(false);
            details[i].set_left_margin(4);
            details[i].set_right_margin(4);
            details[i].set_justification(Gtk::JUSTIFY_FILL );
            details[i].set_pixels_above_lines(2);
            Buff[i] = details[i].get_buffer();

            fichier.get(car);
            arret = fichier.eof();
            if(car == '$' || arret) stats[i].set_label("\n\n0\n\n0\n\n0\n\n");
            while(car != '$' && !arret)
            {
                buffdetail << car;      // car est le numero de la partie
                fichier.get(car);
                if(car == 'v') buffdetail << ". Victoire ";
                else if(car == 'n') buffdetail << ". Match nul";
                else buffdetail << ". Defaite ";

                fichier >> temp;            // temp est le score...
                if(car != 'n') buffdetail << temp;

                if(i==0)        // m�j du nb parties joues, gagnees, nulles (pr l'ordi et else si pas ordi...)
                {
                    char car2;
                    fichier.get(car2);
                    fichier.get(car2);
                    switch (car2)
                    {
                    case '1':
                        tot_r++;
                        if(car == 'v') nbv_r++;
                        else if(car == 'n') nbnul_r++;
                        break;
                    case '2':
                        tot_R++;
                        if(car == 'v') nbv_R++;
                        else if(car == 'n') nbnul_R++;
                        break;
                    case '3':
                        tot_H++;
                        if(car == 'v') nbv_H++;
                        else if(car == 'n') nbnul_H++;
                        break;
                    case '4':
                        tot_V++;
                        if(car == 'v') nbv_V++;
                        else if(car == 'n') nbnul_V++;
                    }
                }
                else
                {
                    total++;
                    if(car == 'v') vict++;
                    else if(car == 'n') nul++;
                }
                fichier >> temp;    // lit le debut du nom du joueur adverse
                if(temp == "IA_ordi")
                {
                    fichier.get(car);
                    fichier.get(car);       // lit le niveau de difficulte
                    switch(car)
                    {
                    case '1':
                        buffdetail << " contre l'ordinateur (Recruit)";
                        break;
                    case '2':
                        buffdetail << " contre l'ordinateur (Regular)";
                        break;
                    case '3':
                        buffdetail << " contre l'ordinateur (Hardened)";
                        break;
                    case '4':
                        buffdetail << " contre l'ordinateur (Veteran)";
                    }
                    fichier.get(car);
                }
                else
                {
                    fichier.get(car);       // lit le car suivant le nom (' ' ou '\n')
                    buffdetail << " contre " << temp;
                    while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces
                    {
                        fichier >> tempbis;
                        buffdetail << " " << tempbis;
                        fichier.get(car);
                    }
                }
                buffdetail << "\n";
                fichier.get(car);

                if(i==0)
                {
                    oss << "Diff : 01    02    03    04\n\n";
                    oss << "         " << tot_r << "     " << tot_R << "     " << tot_H << "     " << tot_V << "\n\n";
                    oss << "         " << nbv_r << "     " << nbv_R << "     " << nbv_H << "     " << nbv_V << "\n\n";
                    oss << "         " << nbnul_r << "     " << nbnul_R << "     " << nbnul_H << "     " << nbnul_V << "\n\n";
                }
                else oss << "\n\n" << total << "\n\n" << vict << "\n\n" << nul << "\n\n";

                temp = buffdetail.str();
                Buff[i]->set_text(temp);
                temp = oss.str();
                stats[i].set_label(temp);

                oss.str("");
                arret = fichier.eof();  // Arret a la fin du fichier !!!
            }
            buffdetail.str("");     // Vidage des flux
        }
        scr.show_all();
        int res = scr.run();
        if(res == 1)            // Init jou
        {
            std::string name;   // nom du joueur a reinit
            name = onglet.get_tab_label_text(*onglet.get_nth_page(onglet.get_current_page()));
            init_stats(name);
        }
        else if(res == 2) init_stats("ALL");       // Init tout
    }
    else        // Fichier non ouvert (fichier == false)
    {
        Gtk::MessageDialog dialogue("Fichier introuvable ou corrompu :(", false, Gtk::MESSAGE_ERROR, Gtk::BUTTONS_CLOSE);
        dialogue.set_position(Gtk::WIN_POS_CENTER);
        dialogue.set_title("Erreur fatale");
        dialogue.set_secondary_text("   Le fichier <b>'scores.sav'</b> n'a pas pu etre ouvert ! Les scores du jeu sont "\
                                    "introuables. Reinstallez le programme pour corriger le probleme :-S", true);
        dialogue.run();
    }
    fichier.close();
}

void Fenetre::init_stats(std::string name)
{
    if(name == "ALL")
    {
        std::ifstream lecture("scores.sav", std::ios::in);
        std::ostringstream contenu;
        std::string temp;
        char car;
        bool end_of_fic = false;

        contenu << "$IA_ordi";
        getline(lecture, temp);
        end_of_fic = lecture.eof();
        while(!end_of_fic)
        {
            lecture.get(car);
            if(car == '$')
            {
                getline(lecture, temp);
                contenu << "\n$" << temp;
            }
            else getline(lecture, temp);
            end_of_fic = lecture.eof();
        }
        contenu << "\n";
        temp = contenu.str();
        lecture.close();

        std::ofstream fic("scores.sav", std::ios::out | std::ios::trunc);   // R��crit le contenu dans le fichier
        if(fic) fic << temp;
        fic.close();

        Gtk::MessageDialog confirmation("Toutes les statistiques de jeu ont ete reinitialisees avec succes.");
        confirmation.set_position(Gtk::WIN_POS_CENTER);
        confirmation.set_icon_from_file("img/Icone.png");
        confirmation.set_title("Suppression effectuee !");
        confirmation.set_border_width(10);
        confirmation.show_all();
        confirmation.run();
    }
    else
    {
        std::ifstream lecture("scores.sav", std::ios::in);
        std::ostringstream contenu;
        std::string temp, temp2;
        char car;
        bool end_of_fic = false;

        lecture.get(car);
        while(car == '$' && !end_of_fic)               // On regarde si le nom est celui � supprimer....
        {
            lecture >> temp;
            lecture.get(car);
            while(car == ' ')       // ajoute les mots suivants dans le cas o� il y a des espaces
            {
                temp.append(" ");
                lecture >> temp2;
                temp.append(temp2);
                lecture.get(car);
            }
            if(temp != name)   // Si c'est PAS ce nom-l�, Sauvegarde des lignes suivantes dans contenu_tot
            {
                contenu << "$" << temp << "\n";
                lecture.get(car);
                while(car != '$')               // sauvegarde les parties jusqu'au joueur suivant
                {
                    getline(lecture, temp);
                    contenu << car << temp << "\n";
                    lecture.get(car);
                }    //Le curseur est apres le $ devant le nom du joueur
            }
            else
            {
                contenu << temp;
                end_of_fic = lecture.ignore(10000, '$');             // le curseur est apres le $ suivant
            }
        }

        std::ofstream fic("scores.sav", std::ios::out | std::ios::trunc);   // R��crit le contenu dans le fichier
        if(fic) fic << contenu;
        fic.close();

        Gtk::MessageDialog confirmation("");
        confirmation.set_position(Gtk::WIN_POS_CENTER);
        confirmation.set_icon_from_file("img/Icone.png");
        confirmation.set_title("Suppression effectuee !");
        confirmation.set_border_width(10);
        temp = "Les statistiques de jeu du joueur <b>'";
        temp.append(name);
        temp.append("'</b> ont ete reinitialisees avec succes.");
        confirmation.set_message(temp, true);
        confirmation.show_all();
        confirmation.run();
    }
}
