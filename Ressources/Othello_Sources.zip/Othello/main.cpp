/*  _____________________________________________________________________________________________

    Programme fait maison. Les commentaires commentent toujours ce qui est en dessous (ou � c�t�)
    _____________________________________________________________________________________________ */

#include "Fenetre_ppale.h"

int main(int argc, char* argv[])
{
    Gtk::Main app(argc, argv);      // Initialise gtkmm et regarde dans les arguments du programme.
    DATA donn;
    {
        f_depart dep;
// Affiche la fen�tre et d�marre la boucle, qui se terminera lorsqu'on choisira l'action � faire.
        Gtk::Main::run(dep);
// R�cup�re les donn�es sur l'initialisation de la fen�tre principale.
        donn = dep.get_donnees();
        std::cout << "Reponse=" << donn.reponse << "\nNomB=" << donn.nomB << "\nNomN=" << donn.nomN;
        std::cout << "\nChemin=" << donn.chemin << "\nDifficulte=" << donn.difficulte << "\nEND" << std::endl;
    }
    while(donn.reponse != 0)      // Boucle pour la relance de la fen�tre lorsqu'on charge une partie etc...
    {
        Fenetre oth(donn);        // Cr�e un objet Fenetre principale.
        Gtk::Main::run(oth);      // Affiche la fen�tre et d�marre la boucle qui finira qd on appelera Gtk::Main::quit()
        donn = oth.get_donnee();
    }
    return 0;
}
