#include "maillon_cp.h"

maillon_cp::maillon_cp(int x, int y, liste l)
{
    this->x = x;
    this->y = y;
    this->l = l;
    next = NULL;
}
