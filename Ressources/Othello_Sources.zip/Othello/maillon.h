#ifndef MAILLON_H_INCLUDED
#define MAILLON_H_INCLUDED

#include <iostream>

// Chaque instance de maillon est un chainon de la liste.
class maillon
{
    friend class liste;

private :
    int x, y;            // Abscisse et ordonn�e de l'image (cell[x][y])
// Couleurs : G=gris v=vide plat ; V=vide relief ; N & n ; B & b idem !
    char coul_init;      // Image initialement pr�sente dans la case
    char coul_a_mettre;  // Image � mettre temporairement (quand la souris va sur l'image)
    maillon* next;

    maillon(int x, int y, char c_i, char c_m);
};
#endif // MAILLON_H_INCLUDED
