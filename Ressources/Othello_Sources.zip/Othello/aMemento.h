/// A FINIR
/*
menu d�roulant Ficher
{
    enregistrer....
}

Infos sur la droite de l'othellier de la fenetre principale
{
    bouton pour annuler le dernier coup
}

enregistrement des scores en fin de partie (ds gameover ????)

fenetre ppale pr les parties chargees

controle du nom des joueurs a la creation :
    - contient pas caract accentues
    - contient pas de '$'
    - est != de 'ALL'
    - est != de 'IA_ordi'
    - fini pas par un espace pr pas ajouter de mot apres l'espace ds lecture fichier

*/
/// BUGS
/*
Fait comme si on cliquait sur Jouer ou charger dans la fenetre parametres de la partie. lorsqu'on clique petite croix !!
Dans Fichier > Nouvelles parties.... Surnombre de fenetres quand on quitte !!
Rajoute un dernier joueur identique quand on supprime ts scores alors qu'ils sont deja ts suppr !!!!


*/
/// FONCTIONNEMENT > Fichier 'scores.sav'
/*

<<
$IA_ordi
1d22-42 nom du joueur 2     => correspondance avec la victoire n�1 de 'nom du joueur' !!!
2d10-54 nom deux 1          partie n�2, defaite, contre le joueur 'nom deux' en difficulte 1.
$nom du joueur
1v42-22 IA_ordi 2		    partie n�1, victoire, contre l'ordi avec 42 points (l'ordi a 22). Difficulte 2
2d30-34 playboy     	    partie n�2, d�faite, contre le joueur 'playboy'
3n32-32 trois.              partie n�3, nul, contre le joueur 'trois.'
4d45-11 joueur3             etc...
$nom deux
1v54-10 IA_ordi 1
                            tjrs retour a la ligne a fin fichier
>>

*/

/// FONCTIONNEMENT > Fichier sauvegarde 'partie1.txt'
/*

<<
3               difficulte (0=2joueurs ; 1-4=Niveau de a_b)
n               a qui le tour
12 16           score (B N)
joueurN         noms
joueurB
vvvvnvbbvvnvvvvnvbvbbn     etat de l'othellier(64 lettres)
debut de partie             informations
le noir passe...

>>

*/
