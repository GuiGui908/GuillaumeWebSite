#include "maillon.h"

maillon::maillon(int x, int y, char c_i, char c_m)
{
    this->x = x;
    this->y = y;
    coul_init = c_i;
    coul_a_mettre = c_m;
    next = NULL;
}
