#include "liste_cp.h"

liste_cp::liste_cp()
{
    tete = NULL;
    nb_maillons = 0;
}

int liste_cp::get_nb_maillons()
{
    return nb_maillons;
}

void liste_cp::add_beginning(int x, int y, liste l)
{
    maillon_cp* nouveau = new maillon_cp(x, y, l);
    nouveau->next = tete;
    tete = nouveau;
    nb_maillons ++;
}

void liste_cp::remove_beginning()
{
    if (nb_maillons > 0)
    {
        maillon_cp* victime = tete;
        tete = tete->next;
        delete victime;
        nb_maillons --;
    }
}
void liste_cp::empty()
{
    while (nb_maillons > 0) remove_beginning();
}

bool liste_cp::consult(int position, int &x, int &y, liste &l)
// La position va de 1 (=premier �l�ment) � nb_maillons (=dernier) 0=Vide.
// Renvoie false si la position est incorrecte, true sinon.
{
    if (position < 1 || position > nb_maillons) return false;
    maillon_cp* cpt = tete;
    for(int i=1; i<position; i++) cpt = cpt->next;
    x = cpt->x;
    y = cpt->y;
    l = cpt->l;
    return true;
}

bool liste_cp::appartient(int x, int y, liste &Lis)
{
    maillon_cp* cpt = tete;
    while(cpt != NULL)
    {
        if(x == cpt->x && y == cpt->y)
        {
            Lis = cpt->l;
            return true;
        }
        cpt = cpt->next;
    }
    return false;
}
