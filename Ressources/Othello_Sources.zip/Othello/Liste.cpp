#include "Liste.h"

liste::liste()
{
    tete = NULL;
    nb_maillons = 0;
}

int liste::get_nb_maillons()
{
    return nb_maillons;
}

void liste::add_beginning(int x, int y, char coul_init, char coul_a_mettre)
{
    maillon* nouveau = new maillon(x, y, coul_init, coul_a_mettre);
    nouveau->next = tete;
    tete = nouveau;
    nb_maillons ++;
}

void liste::remove_beginning()
{
    if (nb_maillons > 0)
    {
        maillon* victime = tete;
        tete = tete->next;
        delete victime;
        nb_maillons --;
    }
}
void liste::empty()
{
    while (nb_maillons > 0) remove_beginning();
}

bool liste::consult(int position, int &x, int &y, char &c_i, char &c_m)
/* La position va de 1 (=premier �l�ment) � nb_maillons (=dernier) 0=Vide.
   Renvoie false si la position est incorrecte, true sinon. */
{
    if (position < 1 || position > nb_maillons) return false;
    maillon* cpt = tete;
    for(int i=1; i<position; i++) cpt = cpt->next;
    x = cpt->x;
    y = cpt->y;
    c_i = cpt->coul_init;
    c_m = cpt->coul_a_mettre;
    return true;
}

bool liste::vide()
{
    return (nb_maillons == 0);
}
