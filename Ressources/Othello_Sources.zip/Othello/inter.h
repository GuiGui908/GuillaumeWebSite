#ifndef INTER_H
#define INTER_H

#include <gtkmm.h>
#include <iostream>
#include <fstream>
#include <string>
#include "data.h"

/* Initialse les donn�es DATA � travers
une fen�tre interm�diaire.
Quitte la premi�re fen�tre. */
class inter
{
private:
    Gtk::Dialog interdialog;
    Gtk::Box *vboite;
    Gtk::Frame gauche, droite;
    Gtk::HBox box_frames;

    Gtk::HButtonBox box_bouton_g, box_bouton_d;
    Gtk::Button create_g, create_d, suppr_g, suppr_d;
    Gtk::VBox box_frame_g, box_frame_d;

    Gtk::RadioButtonGroup  camp, difficulte, nom_joueur_b, nom_joueur_n;
    Gtk::RadioButton noir, blanc, r, R, H, V, names_b[10], names_n[10];
    Gtk::Label lbl_camp, lbl_difficulte;

    DATA donnees;
    bool valide;
    void creation(char coul);
    void suppression(char coul);
// Callback lors du clic sur 'ptite croix'
    bool on_quit(GdkEventAny* event);

public:
    inter(int choix);
    DATA get_donnees();
    bool get_valide();
};
#endif // INTER_H
