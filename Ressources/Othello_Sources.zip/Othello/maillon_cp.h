#ifndef MAILLON_CP_H
#define MAILLON_CP_H

#include "Liste.h"

class maillon_cp
{
    friend class liste_cp;

private :
    int x, y;       // Abscisse et ordonn�e de la case
    liste l;
    maillon_cp* next;

    maillon_cp(int x, int y, liste l);
};
#endif // MAILLON_CP_H
