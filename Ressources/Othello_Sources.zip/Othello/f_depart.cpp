#include "f_depart.h"

f_depart::f_depart() :
// Liste d'initialisation
    box(false),
    nouvbox(false),
    nv1(),
    nv2(),
    charger(),
    quit(),
    fra_lbl_nouv(),
    infos(),
    img1("img/Popup/joueurs.jpg"),
    img2("img/Popup/pc.jpg"),
    img3("img/Popup/charger.jpg"),
    img4("img/Popup/quitter.jpg")
{
    /* Load background image
    Glib::RefPtr<Gdk::Pixmap> pixmap;
    Glib::RefPtr<Gdk::Bitmap> mask;
    pixbuf = Gdk::Pixbuf::create_from_file("img/Popup/BG_popup.png");
    pixbuf->render_pixmap_and_mask(pixmap, mask, 0);*/

// Propri�t�s de la fen�tre
    set_title("");
    set_icon_from_file("img/Icone.png");
    set_border_width(25);
    set_position(Gtk::WIN_POS_CENTER);
    signal_delete_event().connect(sigc::mem_fun(*this, &f_depart::on_quit));    // Clic sur petite croix !
    add(boxppale);

// Cr�ation des boutons
    nv1.set_image(img1);
    nv2.set_image(img2);
    charger.set_image(img3);
    quit.set_image(img4);
    nv1.set_can_focus(false);
    nv2.set_can_focus(false);
    charger.set_can_focus(false);
    quit.set_can_focus(false);

// Remplissage nouvbox avec les 2 boutons nouveau (+ signaux de clic)
    nouvbox.pack_start(nv1, Gtk::PACK_SHRINK, 5);
    nv1.signal_clicked().connect(sigc::bind<int>(sigc::mem_fun(*this, &f_depart::fen_inter), 1));
    nv1.signal_enter().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &f_depart::set_lab), "<big>2 joueurs</big>"));
    nouvbox.pack_start(nv2, Gtk::PACK_SHRINK, 5);
    nv2.signal_clicked().connect(sigc::bind<int>(sigc::mem_fun(*this, &f_depart::fen_inter), 2));
    nv2.signal_enter().connect(sigc::bind<std::string>(sigc::mem_fun(*this, &f_depart::set_lab), "<big>Contre l'ordinateur</big>"));

// Remplissage de la frame fra contenant la nouvbox
    fra_lbl_nouv.set_markup("<big>Nouvelle partie</big>");
    fra.set_label_widget(fra_lbl_nouv);
    fra.add(nouvbox);

// Remplissage de la box avec fra, charger et quitter (+ signaux)
    box.pack_start(fra, Gtk::PACK_SHRINK, 5);
    box.pack_start(charger, Gtk::PACK_SHRINK, 5);
    charger.signal_clicked().connect(sigc::bind<int>(sigc::mem_fun(*this, &f_depart::fen_inter), 3));
    charger.signal_enter().connect(sigc::bind<const std::string>(sigc::mem_fun(*this, &f_depart::set_lab), "<big>Reprendre une partie sauvegardee</big>"));
    box.pack_start(quit, Gtk::PACK_SHRINK, 5);
    quit.signal_clicked().connect(sigc::bind<int>(sigc::mem_fun(*this, &f_depart::fen_inter), 0));
    quit.signal_enter().connect(sigc::bind<const std::string>(sigc::mem_fun(*this, &f_depart::set_lab), "<big>Quitter le jeu</big>"));

// Remplissage de la box principale (box + le texte pr les infos)
    boxppale.pack_start(evbox_around_box, Gtk::PACK_SHRINK, 15);
    evbox_around_box.add(box);
    evbox_around_box.signal_leave_notify_event().connect(sigc::mem_fun(*this, &f_depart::init_labl));
    infos.set_markup("<big>Choisissez quoi faire...</big>");
    boxppale.pack_start(infos);

    boxppale.show_all();
}

DATA f_depart::get_donnees()
{
    return donnees;
}

void f_depart::fen_inter(int choix)
{
    inter fen_intermed(choix);
    if(fen_intermed.get_valide())
    {
        donnees = fen_intermed.get_donnees();
        Gtk::Main::quit();
    }
}

bool f_depart::init_labl(GdkEventCrossing* event)
{
    infos.set_markup("<big>Choisissez quoi faire...</big>");
    return false;
}

void f_depart::set_lab(std::string str)
{
    const std::string& play = str;
    infos.set_markup(play);
}

bool f_depart::on_quit(GdkEventAny* event)
{
    Gtk::Main::quit();
    return true;
}
