#ifndef OTHELLIER_H_INCLUDED
#define OTHELLIER_H_INCLUDED

#include "liste_cp.h"
#include "data.h"

// Gestion de l'othellier en m�moire (pour les calculs)
class Othellier
{
private :
/* Tableau conteant les propri�taires des pions de l'othelier (b=blancs, n=noirs, v=personne)
Origine du rep�re en bas � gauche. Donc [0][7] est la case A1 (haut gauche). */
    char t[8][8];
    char joueur;        // Couleur du joueur en train de jouer (b ou n)
    char joueur_init;   //Sauvegarde pr l'algo a-b du joueur qui jouait au d�but de l'algo
    int scoreB;         // Scores (nombre de pions de la couleur)
    int scoreN;
    int difficulte;     // Profondeur pr l'alpha-beta

public :
    Othellier(int diffi);
    char get_joueur();
    void get_score(int &noirDiz, int &noirUni, int &blancDiz, int &blancUni);
    char opp();           // Renvoie la couleur du joueur qui ne joue pas
    void switch_camp();   // Change la couleur du joueur (typiquement a chaque tour)
    bool complet();       // Revoie vrai si il n'y a plus de place sur le plateau de jeu
/* Execute le coup : le joueur "joueur" place un pion dans la case [x][y].
   Retourne les pions qu'il faut dans l'othelier en m�moire.(jeu � 2 joueurs) */
    void joue(int x, int y, liste &retourne);
// Remet en place l'othelier apres avoir jou� le coup
    void remet(liste retournes);
// Retourne les pions qu'il faut dans l'othelier en m�moire. (jeu de l'ordinateur avec minmax)
    void joue_ordi(liste &lij);
// Ajoute des maillons a la liste Lis pour savoir quelles cases mettre en relief lorsque la souris arrive sur l'image [x][y]
    void remplir_l(liste &Lis, int x, int y);
// Rempli la liste des coups l�gaux;
    void gen_coup_legal(liste_cp &Lcoup);
// Algo pour l'IA
    int alpha_beta(int profondeur, int a, int b);
};
#endif // OTHELLIER_H_INCLUDED
