#include"donnee.h"
#include"generateur_liste.h"
#include<stdlib.h>
#include"liste_echec.h"
#include"deplac_roi.h"

int evaluation(Techiquier ec)
/* Renvoie la somme des pièces de l'echiquier. Les pièces blanches sont comptées en négatif et les noires en positif. */
{
	int i, j, e=0;
	Tcoord pos;
	for(i=0; i<8; i++)
	{
		for(j=0; j<8; j++)
		{
			if(ec[i][j].coul=='V');
			else if(ec[i][j].coul=='B')
			{
				if(ec[i][j].piece=='P')
				{
					e=e-10;
					if(j==3) e=e-3;
					else if(j==4) e=e-6;
					else if(j==5) e=e-8;
					else if(j==6) e=e-10;
				}
				if(ec[i][j].piece=='F' || ec[i][j].piece=='C')
					e=e-30;
				if(ec[i][j].piece=='T')
					e=e-50;
				if(ec[i][j].piece=='D')
					e=e-100;
				if(ec[i][j].piece=='R')
				{
					pos.r = i;
					pos.c = j;
					if(!roi_coup_legal(ec, pos)) e=e-100;
				}
			}
			else
			{
				if(ec[i][j].piece=='P')
				{
					e=e+10;
					if(j==5) e=e+3;
					else if(j==6) e=e+6;
					else if(j==7) e=e+8;
					else if(j==8) e=e+10;
				}
				if(ec[i][j].piece=='F' || ec[i][j].piece=='C')
					e=e+30;
				if(ec[i][j].piece=='T')
					e=e+50;
				if(ec[i][j].piece=='D')
					e=e+100;
				if(ec[i][j].piece=='R')
				{
					pos.r = i;
					pos.c = j;
					if(!roi_coup_legal(ec, pos)) e=e+100;
				}
			}
		}
	}
	return(e);
}


void choix_naif_coup(Tcouleur camp, Techiquier ec, Tcoup *mcp, Tliste lcoup)
/* Choisi le meilleur coup à jouer pour la couleur "camp" (sachant que la liste lcoup est la liste des coups joués).
Retourne à travers "mcp" le coup ayant l'évaluation la plus élevée. */
{
	Tliste l=NULL, sav;
	Tcase temp;
	int e, max = -99;
	generateur(ec, camp, &l, lcoup);
	if(l==NULL) (*mcp).depart.r = -1;
	else
	{
		sav = l;
		while(l!=NULL)
		{
			temp = ec[(l->arrivee).r][(l->arrivee).c];
			ec[(l->arrivee).r][(l->arrivee).c] = ec[(l->depart).r][(l->depart).c];
			ec[(l->depart).r][(l->depart).c].coul='V';
			e = evaluation(ec);
			if(e > max)
			{
				max = e;
				*mcp = *l;
			}
			ec[(l->depart).r][(l->depart).c] = ec[(l->arrivee).r][(l->arrivee).c];
			ec[(l->arrivee).r][(l->arrivee).c] = temp;
			l = l->suiv;
		}
		suppression_tot(&sav);
	}
}


