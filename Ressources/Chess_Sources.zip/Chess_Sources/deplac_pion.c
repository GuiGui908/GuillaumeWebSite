#include "donnee.h"
#include "manip.h"


/* Auteur du fichier : Guillaume BERT */
int pion_dep(Techiquier ec, Tcoord pos)
/* Valeur retournée :
0 si aucun déplacement possible
Pour le déplacement d'un pion BLANC : Retourne 1 pour une case et 2 pour une ou deux cases vers l'avant
Pour le déplacement d'un pion NOIR :  Retourne 11 pour une case et 22 pour une ou deux cases vers l'avant */
{
	if(ec[pos.r][pos.c].coul=='B')
	{
		if(pos.c==1 && ec[pos.r][pos.c+1].coul=='V' && ec[pos.r][pos.c+2].coul=='V') return(2);
		else if(pos.c<7 && ec[pos.r][pos.c+1].coul=='V') return(1);
		     else return(0);
	}
	else if(ec[pos.r][pos.c].coul=='N')
	{
		if(pos.c==6 && ec[pos.r][pos.c-1].coul=='V' && ec[pos.r][pos.c-2].coul=='V') return(22);
		else if(pos.c>0 && ec[pos.r][pos.c-1].coul=='V') return(11);
		     else return(0);
	}
	else return(0);
}

int pion_pr_g(Techiquier ec, Tcoord pos)
/* Valeur retournée :
0 si aucun déplacement possible
1 si le pion BLANC peut manger à gauche
2 si le pion NOIR peut manger à gauche */
{
	if(ec[pos.r][pos.c].coul=='B' && pos.r>0 && pos.c<7 && ec[(pos.r)-1][(pos.c)+1].coul=='N')
		return(1);
	if(ec[pos.r][pos.c].coul=='N' && pos.r>0 && pos.c>0 && ec[(pos.r)-1][(pos.c)-1].coul=='B')
		return(2);
	else return(0);
}

int pion_pr_d(Techiquier ec, Tcoord pos)
/* Valeur retournée :
0 si aucun déplacement possible
1 si le pion BLANC peut manger à droite
2 si le pion NOIR peut manger à droite */
{
	if(ec[pos.r][pos.c].coul=='B' && pos.r<7 && pos.c<7 && ec[(pos.r)+1][(pos.c)+1].coul=='N')
		return(1);
	if(ec[pos.r][pos.c].coul=='N' && pos.r<7 && pos.c>0 && ec[(pos.r)+1][(pos.c)-1].coul=='B')
		return(2);
	else return(0);
}
