#ifndef DEPLAC_DAMES_H
#define DEPLAC_DAMES_H

int dep_dame(Techiquier ec, Tcoord pos);
/* De la même manière que le cavalier, cette fonction retourne 0 ou 1 si la dame peut ou non se déplacer. */

int dame_pr_g(Techiquier ec, Tcoord pos);
/* Les fonctions de prise retournent 1 si la dame peut manger une pièce dans une des cases
accessibles dans la direction spécifiée (g = gauche.... etc.) */
int dame_pr_d(Techiquier ec, Tcoord pos);
int dame_pr_h(Techiquier ec, Tcoord pos);
int dame_pr_b(Techiquier ec, Tcoord pos);
int dame_pr_g_h(Techiquier ec, Tcoord pos);
int dame_pr_g_b(Techiquier ec, Tcoord pos);
int dame_pr_d_h(Techiquier ec, Tcoord pos);
int dame_pr_d_b(Techiquier, Tcoord pos);

#endif
