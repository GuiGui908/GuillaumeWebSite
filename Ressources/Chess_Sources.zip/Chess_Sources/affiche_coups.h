#ifndef AFFICHE_COUPS_H
#define AFFICHE_COUPS_H


void affiche_coups_case(Techiquier ec, Tcoord pos);
/*Appelle les fonctions de déplacement pour la pièce éventuellement présente sur la case pos.
C'est une fonction de test pour les prises et les déplacements. */


#endif
