#include <stdio.h>
#include "donnee.h"
#include "deplac_roi.h"

int pr_en_passant(Techiquier ec, Tliste lcoup, Tcoord pos)
/* Retourne 1 si le pion Blanc peut prendre en passant à gauche
Retourne 10 si le pion Blanc peut prendre en passant à droite
Retourne 2 si le pion Noir peut prendre en passant à gauche
Retourne 20 si le pion Noir peut prendre en passant à droite
Retourne 0 sinon */
{
	Tliste cpt=lcoup;
	if (lcoup!=NULL)
	{
		for(cpt=lcoup; cpt->suiv!=NULL; cpt=cpt->suiv);
		if(pos.c==4 && ec[pos.r][pos.c].piece=='P' && ec[pos.r][pos.c].coul=='B')
		{
			if(pos.r>0 && ec[pos.r-1][pos.c].piece=='P' && ec[pos.r-1][pos.c].coul=='N')
			{
				if(cpt->depart.r==pos.r-1 && cpt->depart.c==pos.c+2 && cpt->arrivee.r==pos.r-1 && cpt->arrivee.c==pos.c)	
					return(1);
			}
			if(pos.r<7 && ec[pos.r+1][pos.c].piece=='P' && ec[pos.r+1][pos.c].coul=='N')
			{			
				if(cpt->depart.r==pos.r+1 && cpt->depart.c==pos.c+2 && cpt->arrivee.r==pos.r+1 && cpt->arrivee.c==pos.c)
					return(10);
			}
		}
		if(pos.c==3 && ec[pos.r][pos.c].piece=='P' && ec[pos.r][pos.c].coul=='N')
		{		
			if(pos.r>0 && ec[pos.r-1][pos.c].piece=='P' && ec[pos.r-1][pos.c].coul=='B')	
			{			
				if(cpt->depart.r==pos.r-1 && cpt->depart.c==pos.c-2 && cpt->arrivee.r==pos.r-1 && cpt->arrivee.c==pos.c)
					return(2);
			}
			if(pos.r<7 && ec[pos.r+1][pos.c].piece=='P' && ec[pos.r+1][pos.c].coul=='B')
			{			
				if(cpt->depart.r==pos.r+1 && cpt->depart.c==pos.c-2 && cpt->arrivee.r==pos.r+1 && cpt->arrivee.c==pos.c)
					return(20);
			}
		}
	}
	return(0);
}

int grand_roque_b(Techiquier ec, Tliste lcoup)
/* Retourne 3 si le grand roque est possible pour les blancs
Retourne 0 sinon */
{
	int i;
	Tliste cpt;
	Tcoord pos;
	pos.c=0;
	if (lcoup!=NULL)
	{		
		for(cpt=lcoup; cpt!=NULL; cpt=cpt->suiv)		/* RB et TB ne se sont pas deplacés */
			if((cpt->depart.r==4 && cpt->depart.c==0) || (cpt->depart.r==0 && cpt->depart.c==0))
				return(0);

		for(i=1; i<4; i++)			/* Vérifie pour chaque position intemédiaire du déplacement que le roi n'est pas en échec */
		{
			pos.r=i;
			if(ec[i][0].coul!='V')
				return(0);
			ec[i][0] = ec[4][0];		/* Deplace le roi dans la case pos */
			ec[4][0].coul = 'V';
			if(roi_coup_legal(ec, pos)!=1)
			{
				ec[4][0] = ec[i][0];	/* Replace le roi. */
				ec[i][0].coul = 'V';
				return(0);
			}
			ec[4][0] = ec[i][0];
			ec[i][0].coul = 'V';
		}
		return 3;
	}
	else return 0;
}

int grand_roque_n(Techiquier ec, Tliste lcoup)
/* Retourne 4 si le grand roque est possible pour les noirs
Retourne 0 sinon */
{
	int i;
	Tliste cpt;
	Tcoord pos;
	pos.c=7;
	if (lcoup!=NULL)
	{		
		for(cpt=lcoup; cpt!=NULL; cpt=cpt->suiv)		/* RN et TN ne se sont pas deplacer */
			if((cpt->depart.r==4 && cpt->depart.c==7) || (cpt->depart.r==0 && cpt->depart.c==7))
				return(0);

		for(i=1; i<4; i++)			/* Vérifie pour chaque position intemédiaire du déplacement que le roi n'est pas en échec */
		{
			pos.r=i;
			if(ec[i][7].coul!='V')
				return(0);
			ec[i][7] = ec[4][7];		/* deplace le roi dans la case pos */
			ec[4][7].coul = 'V';
			if(roi_coup_legal(ec, pos)!=1)
			{
				ec[4][7] = ec[i][7];	/* replace le roi. */
				ec[i][7].coul = 'V';
				return(0);
			}
			ec[4][7] = ec[i][7];
			ec[i][7].coul = 'V';
		}
		return 4;
	}
	else return 0;
}

int petit_roque_b(Techiquier ec, Tliste lcoup)
/* Retourne 30 si le petit roque est possible pour les blancs
Retourne 0 sinon */
{
	Tliste cpt;
	int i;
	Tcoord pos;
	pos.c=0;
	if (lcoup!=NULL)
	{		
		for(cpt=lcoup; cpt!=NULL; cpt=cpt->suiv)		/* RN et TN ne se sont pas deplacés */
			if((cpt->depart.r==4 && cpt->depart.c==0) || (cpt->depart.r==7 && cpt->depart.c==0))
				return(0);

		for(i=5; i<7; i++)			/* Vérifie pour chaque position intemédiaire du déplacement que le roi n'est pas en échec */
		{
			pos.r=i;
			if(ec[i][0].coul!='V')
				return(0);
			ec[i][0] = ec[4][0];		/* deplace le roi dans la case pos */
			ec[4][0].coul = 'V';
			if(roi_coup_legal(ec, pos)!=1)
			{
				ec[4][0] = ec[i][0];	/* replace le roi. */
				ec[i][0].coul = 'V';
				return(0);
			}
			ec[4][0] = ec[i][0];
			ec[i][0].coul = 'V';
		}
		return 30;
	}
	else return 0;
}

int petit_roque_n(Techiquier ec, Tliste lcoup)
/* Retourne 40 si petit roque possible pour les noirs
Retourne 0 sinon */
{
	int i;
	Tliste cpt;
	Tcoord pos;
	pos.c=7;
	if (lcoup!=NULL)
	{		
		for(cpt=lcoup; cpt!=NULL; cpt=cpt->suiv)		/* RN et TN ne se sont pas deplacer */
			if((cpt->depart.r==4 && cpt->depart.c==7) || (cpt->depart.r==7 && cpt->depart.c==7))
				return(0);

		for(i=5; i<7; i++)			/* Vérifie pour chaque position intemédiaire du déplacement que le roi n'est pas en échec */
		{
			pos.r=i;
			if(ec[i][7].coul!='V')
				return(0);
			ec[i][7] = ec[4][7];		/* deplace le roi dans la case pos */
			ec[4][7].coul = 'V';
			if(roi_coup_legal(ec, pos)!=1)
			{
				ec[4][7] = ec[i][7];	/* replace le roi. */
				ec[i][7].coul = 'V';
				return(0);
			}
			ec[4][7] = ec[i][7];
			ec[i][7].coul = 'V';
		}
		return 40;
	}
	else return 0;
}


