#include <stdio.h>
#include "donnee.h"
#include "Init.h"
#include "Affiche.h"
#include "generateur_liste.h"
#include "manip.h"
#include "saisie.h"
#include "evaluation.h"
#include "MinMax.h"
#include "coups_speciaux.h"
#include "liste_echec.h"


/* Auteur du fichier : Guillaume BERT */
char partie_2_joueurs(Tliste *lcoup)
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */
{int i;Tliste cpt;
	Techiquier echec;
	Tpiece p;
	Tcoup cp;
	Tcouleur coul = 'B';
	Tliste l = NULL;
	init_echiquier(echec);
	affichage(echec);

	while(0==0)
	{
		generateur(echec, coul, &l, *lcoup);
		if(l==NULL) return coul;
for(cpt=l,i=1; cpt!=NULL; cpt=cpt->suiv,i++)
	printf("%d - (%d, %d) -> (%d, %d)spec:%d\n", i, cpt->depart.r+1, cpt->depart.c+1, cpt->arrivee.r+1, cpt->arrivee.c+1, cpt->spec);
printf("generateur_liste de coups terminee\n\n");
		printf("Joueur %c, saisi le coup :\n", coul);
		saisie_clavier_coup(&cp);
		if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		while(verification_coup(&cp, l)!=1)
		{
			printf("Le coup n'est pas valide !!!!\n\nJoueur %c, REsaisi le coup :\n", coul);
			saisie_clavier_coup(&cp);
			if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		}
		if(cp.spec == 9)
		{
			echec[(cp.arrivee).r][(cp.arrivee).c].coul=echec[(cp.depart).r][(cp.depart).c].coul;		
			printf("Choisir la pièce à échanger avec le pion : "); 			
			while(scanf("%c", &p) != 1);
			echec[(cp.arrivee).r][(cp.arrivee).c].piece=p;
			echec[(cp.depart).r][(cp.depart).c].coul='V';
		}
		else execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		affichage(echec);
		coul = adversaire(coul);
	}
}
char partie_vs_PC_con(Tliste *lcoup)
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */
{
	Techiquier echec;
	Tpiece p;
	Tcoup cp;
	Tcouleur coul = 'B';
	Tliste l = NULL;
	init_echiquier(echec);
	affichage(echec);

	while(0==0)
	{
		generateur(echec, coul, &l, *lcoup);
		if(l==NULL) return coul;
		printf("Joueur Blanc, saisi le coup :\n");
		saisie_clavier_coup(&cp);
		if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		while(verification_coup(&cp, l)!=1)
		{
			printf("Le coup n'est pas valide !!!!\n\nJoueur Blanc, REsaisi le coup :\n");
			saisie_clavier_coup(&cp);
			if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		}
		if(cp.spec == 9)
		{
			echec[(cp.arrivee).r][(cp.arrivee).c].coul=echec[(cp.depart).r][(cp.depart).c].coul;		
			printf("Choisir la pièce à échanger avec le pion : "); 			
			while(scanf("%c", &p) != 1);
			echec[(cp.arrivee).r][(cp.arrivee).c].piece=p;
			echec[(cp.depart).r][(cp.depart).c].coul='V';
		}
		else execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		affichage(echec);

		choix_naif_coup(adversaire(coul), echec, &cp, *lcoup);
		if(cp.depart.r == -1) return adversaire(coul);
		execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		printf("Coup de l'ordinateur :  (%d,%d) (%d,%d)\n", cp.depart.r+1, cp.depart.c+1, cp.arrivee.r+1, cp.arrivee.c+1);
		affichage(echec);
	}
}

char partie_vs_PC(Tliste *lcoup)
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */
{
	Techiquier echec;
	Tcoup cp;
	Tpiece p;
	Tcouleur coul = 'B';
	Tliste l = NULL;
/*Tliste cpt;int i;*/
	init_echiquier(echec);
	affichage(echec);

	while(0==0)
	{
		generateur(echec, coul, &l, *lcoup);
		if(l==NULL) return coul;
/*for(cpt=l,i=1; cpt!=NULL; cpt=cpt->suiv,i++)
	printf("%d - (%d, %d) -> (%d, %d)spec:%d\n", i, cpt->depart.r+1, cpt->depart.c+1, cpt->arrivee.r+1, cpt->arrivee.c+1, cpt->spec);
printf("generateur_liste de coups terminee\n\n");
*/
		printf("Joueur Blanc, saisi le coup :\n");
		saisie_clavier_coup(&cp);
		if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		while(verification_coup(&cp, l)!=1)
		{
			printf("Le coup n'est pas valide !!!!\n\nJoueur Blanc, REsaisi le coup :\n");
			saisie_clavier_coup(&cp);
			if(cp.depart.r==8 || cp.arrivee.r==8) return('Q');
		}
		if(cp.spec == 9)
		{
			echec[(cp.arrivee).r][(cp.arrivee).c].coul=echec[(cp.depart).r][(cp.depart).c].coul;		
			printf("Choisir la pièce à échanger avec le pion : "); 			
			while(scanf("%c", &p) != 1);
			echec[(cp.arrivee).r][(cp.arrivee).c].piece=p;
			echec[(cp.depart).r][(cp.depart).c].coul='V';
		}
		else execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		affichage(echec);

		choix_coup(adversaire(coul), echec, 5, &cp, *lcoup);
		if(cp.depart.r == -1) return adversaire(coul);
		execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		printf("Coup de l'ordinateur :  (%d,%d) (%d,%d)\n", cp.depart.r+1, cp.depart.c+1, cp.arrivee.r+1, cp.arrivee.c+1);
		affichage(echec);
	}
}

char partie_PC_vs_PC(Tliste *lcoup)
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N). */
{
	Techiquier echec;
	Tcoup cp;
	Tcouleur coul = 'B';
	init_echiquier(echec);
	affichage(echec);

	while(0==0)
	{
/*		getchar();*/
		choix_coup(coul, echec, 4, &cp, *lcoup);
		if(cp.depart.r == -1) return adversaire(coul);
		execute_coup(echec, cp);
		ajout(&(*lcoup), cp);
		printf("Coup de l'ordinateur :  (%d,%d) (%d,%d)\n", cp.depart.r+1, cp.depart.c+1, cp.arrivee.r+1, cp.arrivee.c+1);
		affichage(echec);
		coul = adversaire(coul);
	}
}

void enreg_partie(Tliste lcoup)
/* Enregistre la partie : écrit la liste les coups joués (lcoup) dans le fichier nommé par l'utilisateur. */
{
 	char c, nom[50];
	FILE *fic;
	printf("\nLa partie est terminée ou a été interrompue. Voulez vous la sauvegarder ?? (y or n)  ");
	while(scanf("%c", &c)!=1);
	if(c=='y')
	{
		while((c=getchar())!='\n' && c != EOF )
		{
                ;
		}
		printf("Nom du fichier de sauvegarde (sans espaces) : ");
		while(scanf("%s", nom)!=1);
		fic = fopen(nom, "w");		/* Ouverture du fichier en écriture */

		/* Sauvegarde de la liste de coups dans le fichier "nom" si le fichir a bien été ouvert */
		if(fic!=NULL)
		{
			while(lcoup!=NULL)
			{
			  	fprintf(fic, "%d,%d -> %d,%d;sp%d\n", lcoup->depart.r, lcoup->depart.c, lcoup->arrivee.r, lcoup->arrivee.c, lcoup->spec);
				lcoup = lcoup->suiv;
			}
			printf("La partie a été sauvegardée dans le fichier %s\n\n", nom);
		}
		else  printf("Erreur !! Le fichier n'a pas été ouvert. Partie non sauvegardée...");
		fclose(fic);
	}
}

void rejoue()
/* Réaffiche la partie enregistrée, coup par coup. */
{
	char nom[50];
	Tcoup cp;
	Techiquier echec;
	Tliste lcoup = NULL;
	FILE *fic;

	init_echiquier(echec);
	printf("Entrer le  nom du fichier de sauvegarde : ");
	while(scanf("%s", nom)!=1);

	fic = fopen(nom, "r");		/* Ouverture du fichier en lecture */
	if(fic == NULL) printf("Impossible d'ouvrir ce fichier... Il n'existe peut etre pas !!\n\n");

	/* Rejoue la partie coup par coup */
	else
	{
		affichage(echec);
		while(fscanf(fic, "%d,%d -> %d,%d;sp%d\n", &cp.depart.r, &cp.depart.c, &cp.arrivee.r, &cp.arrivee.c, &cp.spec) != EOF)
		{
			printf("Appuyer sur entrée pour continuer");
			getchar();
		 	execute_coup(echec, cp);
			ajout(&lcoup, cp);
			affichage(echec);
		}
	}
}

/* ID D'amélioration : Annonnce les coups joués sur la partie précédente et c'est ensuite l'utilisateur qui choisit si il joue ce coup. Si il change, la partie repart de là et elle se continue normalement. */


