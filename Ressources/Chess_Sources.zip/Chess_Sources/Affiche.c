#include "donnee.h"
#include <stdio.h>

void affichage(Techiquier af)
{
	int i, j, cpt;
	for(j=7, cpt=8; j>=0 && cpt>0; j--, cpt--)
	{	
		
		printf("\n\n");		
		for(i=0; i<8; i++)
		{			
			if (af[i][j].coul== 'V')
				printf(". ");
			else printf("%c%c",af[i][j].piece,af[i][j].coul);
			printf("   ");
		}
		printf("  %d",cpt);
	}
	printf("\n\n");
	printf("A    B    C    D    E    F    G    H");
	printf("\n\n");   
}
