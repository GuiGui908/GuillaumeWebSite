#ifndef PARTIE_H
#define PARTIE_H

char partie_2_joueurs(Tliste *lcoup);
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */

char partie_vs_PC_con(Tliste *lcoup);
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */

char partie_vs_PC(Tliste *lcoup);
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N) ou Q si le joueur décide d'arrêter. */

char partie_PC_vs_PC(Tliste *lcoup);
/* Joue une partie.
Retourne la couleur du joueur qui a perdu (B ou N). */

void enreg_partie(Tliste lcoup);
/* Enregistre la partie : écrit la liste les coups joués (lcoup) dans le fichier nommé par l'utilisateur. */

void rejoue();
/* Réaffiche la partie enregistrée, coup par coup. */


#endif
