#include "donnee.h"
#include "manip.h"

/* Auteur : Fidèle Adico */
int tour_dep(Techiquier ec, Tcoord pos)
/* De la même manière que le cavalier, cette fonction retourne 0 ou 1 si la tour peut ou non se déplacer. */
{
	if(pos.c<7 && ec[pos.r][(pos.c)+1].coul=='V')
		return(1);
		if(pos.c>0 && ec[pos.r][(pos.c)-1].coul=='V')
			return(1);
			if(pos.r<7 && ec[(pos.r)+1][pos.c].coul=='V')
				return(1);
				if(pos.r>0 && ec[(pos.r)-1][pos.c].coul=='V')
					return(1);
					else return(0);
}

/* En s'appuyant sur les fonctions de prise de la dame, on fait pareil pour la tour. */
int tour_pr_g(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.r-1; i>=0 && ec[i][pos.c].coul=='V'; i--);
	if(i<0) return(0);		
	else	if(ec[i][(pos.c)].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int tour_pr_d(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.r+1; i<=7 && ec[i][pos.c].coul=='V'; i++);
	if(i>7) return(0);		
	else	if(ec[i][(pos.c)].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}
int tour_pr_h(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.c+1; i<=7 && ec[pos.r][i].coul=='V'; i++);
	if(i>7) return(0);		
	else	if(ec[pos.r][i].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}
	
int tour_pr_b(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.c-1; i>=0 && ec[pos.r][i].coul=='V'; i--);
	if(i<0) return(0);		
	else	if(ec[pos.r][i].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int fou_dep(Techiquier ec, Tcoord pos)
/* De la même manière que le cavalier, cette fonction retourne 0 ou 1 si le fou peut ou non se déplacer. */
{
	if(pos.r<7)
	{
		if(pos.c<7 && ec[pos.r+1][pos.c+1].coul=='V') return(1);
		if(pos.c>0 && ec[pos.r+1][pos.c-1].coul=='V') return(1);
	}
	if(pos.r>0)
	{
		if(pos.c<7 && ec[pos.r-1][pos.c+1].coul=='V') return(1);
		if(pos.c>0 && ec[pos.r-1][pos.c-1].coul=='V') return(1);
	}
	return(0);
}

/* En s'appuyant sur les fonctions de prise de la dame, on fait pareil pour le fou. */
int fou_pr_g_h(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r-1, j=pos.c+1; i>=0 && j<=7 && ec[i][j].coul=='V'; i--, j++);
	if((i<0)||(j>7)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int fou_pr_g_b(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r-1, j=pos.c-1; i>=0 && j>=0 && ec[i][j].coul=='V'; i--, j--);
	if((i<0)||(j<0)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int fou_pr_d_h(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r+1, j=pos.c+1; i<=7 && j<=7 && ec[i][j].coul=='V'; i++, j++);
	if((i>7)||(j>7)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int fou_pr_d_b(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r+1, j=pos.c-1; i<=7 && j>=0 && ec[i][j].coul=='V'; i++, j--);
	if((i>7)||(j<0)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

