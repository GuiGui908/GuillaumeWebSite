// g_signal_handlers_destroy(G_OBJECT());
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "donnee.h"
#include "Init.h"
#include "Affiche.h"
#include "generateur_liste.h"
#include "manip.h"
#include "saisie.h"
#include "evaluation.h"
#include "MinMax.h"
#include "coups_speciaux.h"
#include "liste_echec.h"

/* Variables GTK globale au main */
GtkWidget *Window;		/* Fenetre */

GtkWidget *noirebox;		/* Box */
GtkWidget *vertebox;
GtkWidget *rougebox;
GtkWidget *rosebox;
GtkWidget *bleubox[4];
GtkWidget *ebox[8][8];		/* Tableau d'eventbox contenant les pièces (= échiquier) */

GtkWidget *menu[6];		/* Boutons de menus en haut de la fenetre */

GtkWidget *table;		/* Table (pour organiser les event_box) */
GtkWidget *rosetab;		/* Table (pour organiser la partie droite de la fenêtre) */
GtkWidget *tour;		/* Image pour savoir à qui de jouer */
GtkWidget *affdepb;
GtkWidget *affdepn;
GtkWidget *affarrb;
GtkWidget *affarrn;
GtkWidget *affconseil;
GtkWidget *joue;
GtkWidget *pcpc;

/* Variables normales globale au main */
Techiquier echec;
Tliste lcoup = NULL;
Tcouleur coul = 'B';
Tcoup cp;
FILE *fic;
int cpt;
char tiret[50] = " - ";
char vers[50] = "                         vers :";
char A[50] = "A";
char B[50] = "B";
char C[50] = "C";
char D[50] = "D";
char E[50] = "E";
char F[50] = "F";
char G[50] = "G";
char H[50] = "H";
char un[50] = "1";
char deux[50] = "2";
char trois[50] = "3";
char quatre[50] = "4";
char cinq[50] = "5";
char six[50] = "6";
char sept[50] = "7";
char huit[50] = "8";




void init_pieces();


static GtkWidget *cree_img_ebox(gchar *xpm_filename)
/* Renvoie un pointeur sur une event_box dans laquelle est placée l'image 'xpm_filename' */
{
	GtkWidget *ev_box;
	GtkWidget *image;
	ev_box = gtk_event_box_new ();
	image = gtk_image_new_from_file(xpm_filename);
	gtk_container_add(GTK_CONTAINER(ev_box), image);
	return ev_box;
}

static void ajout_img(GtkBox *box, gchar *xpm_filename)
/* Ajoute dans la hbox 'hbox' l'image 'xpm_filename' à la suite des autres widgets */
{
	GtkWidget *image;
	image = gtk_image_new_from_file(xpm_filename);
	gtk_box_pack_start(GTK_BOX(box), image, FALSE, TRUE, 0);
	gtk_widget_show_all(GTK_WIDGET(box));
}

static void change_img(GtkEventBox *box, gchar *xpm_filename)
/* Modifie l'image contenue dans l'eventbox en paramètre ; la remplace par l'image 'xpm_filename' */
{
	GList *child;
	GtkWidget *image;
	child = gtk_container_get_children(GTK_CONTAINER(box));
	image = GTK_WIDGET(child->data);
	gtk_image_set_from_file(GTK_IMAGE(image), xpm_filename);
	gtk_widget_show_all(GTK_WIDGET(box));
}

void deplac_image(Tcoord dep, Tcoord arriv)
/* Déplace l'image de la pièce de dep vers arriv et met une image vide dans la case de départ. Affiche la pièce mangée si il y a prise. */
{
	if(echec[dep.r][dep.c].coul == 'B')		/* La pièce qui se déplace est blanche */
	{
		if(echec[arriv.r][arriv.c].coul!='V')	/* Si il y a prise, on affiche la pièce mangée dans la bleubox[1] */
		{
			if(echec[arriv.r][arriv.c].piece=='P') ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/PN.png");
			else if(echec[arriv.r][arriv.c].piece=='T') ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/TN.png");
			else if(echec[arriv.r][arriv.c].piece=='C') ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/CN.png");
			else if(echec[arriv.r][arriv.c].piece=='F') ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/FN.png");
			else if(echec[arriv.r][arriv.c].piece=='D') ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/DN.png");
		}
		if((arriv.r + arriv.c)%2 == 1)	/* Fond Blanc */
		{
			if(echec[dep.r][dep.c].piece=='P') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/PB.png");
			else if(echec[dep.r][dep.c].piece=='T') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/TB.png");
			else if(echec[dep.r][dep.c].piece=='C') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/CB.png");
			else if(echec[dep.r][dep.c].piece=='F') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/FB.png");
			else if(echec[dep.r][dep.c].piece=='D') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/DB.png");
			else if(echec[dep.r][dep.c].piece=='R') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/RB.png");
		}
		else				/* Fond Noir */
		{
			if(echec[dep.r][dep.c].piece=='P') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/PB.png");
			else if(echec[dep.r][dep.c].piece=='T') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/TB.png");
			else if(echec[dep.r][dep.c].piece=='C') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/CB.png");
			else if(echec[dep.r][dep.c].piece=='F') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/FB.png");
			else if(echec[dep.r][dep.c].piece=='D') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/DB.png");
			else if(echec[dep.r][dep.c].piece=='R') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/RB.png");
		}
	}
	if(echec[dep.r][dep.c].coul == 'N')		/* La pièce qui se déplace est noire */
	{
		if(echec[arriv.r][arriv.c].coul!='V')	/* Si il y a prise, on affiche la pièce mangée dans la bleubox[1] */
		{
			if(echec[arriv.r][arriv.c].piece=='P') ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/PB.png");
			else if(echec[arriv.r][arriv.c].piece=='T') ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/TB.png");
			else if(echec[arriv.r][arriv.c].piece=='C') ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/CB.png");
			else if(echec[arriv.r][arriv.c].piece=='F') ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/FB.png");
			else if(echec[arriv.r][arriv.c].piece=='D') ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/DB.png");
		}
		if((arriv.r + arriv.c)%2 == 1)	/* Fond Blanc */
		{
			if(echec[dep.r][dep.c].piece=='P') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/PN.png");
			else if(echec[dep.r][dep.c].piece=='T') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/TN.png");
			else if(echec[dep.r][dep.c].piece=='C') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/CN.png");
			else if(echec[dep.r][dep.c].piece=='F') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/FN.png");
			else if(echec[dep.r][dep.c].piece=='D') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/DN.png");
			else if(echec[dep.r][dep.c].piece=='R') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fb/RN.png");
		}
		else				/* Fond Noir */
		{
			if(echec[dep.r][dep.c].piece=='P') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/PN.png");
			else if(echec[dep.r][dep.c].piece=='T') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/TN.png");
			else if(echec[dep.r][dep.c].piece=='C') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/CN.png");
			else if(echec[dep.r][dep.c].piece=='F') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/FN.png");
			else if(echec[dep.r][dep.c].piece=='D') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/DN.png");
			else if(echec[dep.r][dep.c].piece=='R') change_img(GTK_EVENT_BOX(ebox[arriv.r][7-arriv.c]), "Pieces_fn/RN.png");
		}
	}
	if((dep.r+dep.c)%2 == 0) change_img(GTK_EVENT_BOX(ebox[dep.r][7-dep.c]), "Pieces_fn/V.png");
	else change_img(GTK_EVENT_BOX(ebox[dep.r][7-dep.c]), "Pieces_fb/V.png");
}

void execute_graph()
{
	int x, y;
	if(cp.spec == 0)				/* Coup normal */
		deplac_image(cp.depart, cp.arrivee);
	else if(cp.spec == 1 || cp.spec == 2)		/* prise en passant à gauche (pion blanc ou noir) */
	{
		if((cp.depart.r-1+cp.depart.c)%2 == 0) change_img(GTK_EVENT_BOX(ebox[cp.depart.r-1][7-cp.depart.c]), "Pieces_fn/V.png");
		else change_img(GTK_EVENT_BOX(ebox[cp.depart.r-1][7-cp.depart.c]), "Pieces_fb/V.png");
		deplac_image(cp.depart, cp.arrivee);
	}
	else if(cp.spec == 10 || cp.spec == 20)		/* prise en passant à droite (pion blanc ou noir) */
	{
		if((cp.depart.r+1+cp.depart.c)%2 == 0) change_img(GTK_EVENT_BOX(ebox[cp.depart.r+1][7-cp.depart.c]), "Pieces_fn/V.png");
		else change_img(GTK_EVENT_BOX(ebox[cp.depart.r+1][7-cp.depart.c]), "Pieces_fb/V.png");
		deplac_image(cp.depart, cp.arrivee);
	}
	else if(cp.spec == 3 || cp.spec == 4)		/* Grand roque (roi blanc ou noir) */
	{
		x = cp.depart.r;
		y = cp.arrivee.r;
		deplac_image(cp.depart, cp.arrivee);
		cp.depart.r=0;
		cp.arrivee.r=3;
		deplac_image(cp.depart, cp.arrivee);
		cp.depart.r = x;
		cp.arrivee.r = y;
	}
	else if(cp.spec == 30 || cp.spec == 40)		/* Petit roque (roi blanc ou noir) */
	{
		x = cp.depart.r;
		y = cp.arrivee.r;
		deplac_image(cp.depart, cp.arrivee);
		cp.depart.r=7;
		cp.arrivee.r=5;
		deplac_image(cp.depart, cp.arrivee);
		cp.depart.r = x;
		cp.arrivee.r = y;
	}
}

void execute(GtkWidget *widget, gpointer data)
{
	GtkWidget *boite;
	GtkWidget *msg1;
	if(fscanf(fic, "%d,%d -> %d,%d;sp%d\n", &cp.depart.r, &cp.depart.c, &cp.arrivee.r, &cp.arrivee.c, &cp.spec) == EOF)
	{
		msg1 = gtk_label_new("Fin de la partie enregistrée dans le fichier !!\nLe programme va se terminer.");
		boite = gtk_dialog_new_with_buttons("Rejoue terminée", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, TRUE, 15);
		gtk_widget_show_all(boite);
		gtk_dialog_run(GTK_DIALOG(boite));
		gtk_main_quit();
	}
 	execute_graph();
	execute_coup(echec, cp);
	ajout(&lcoup, cp);
}

void load(GtkWidget *widget, gpointer data)
/* Callback pour le bouton "charger" du menu :
Affiche une boite de dialogue pour choisir dans quel fichier on trouve la partie a rejouer.
Initialise le pointeur sur le fichier */
{
	const gchar* nom;
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *boite2;
	GtkWidget *msg2;
	GtkWidget *msg3;
	GtkWidget *saisie;
	msg1 = gtk_label_new("\n\nCharger une partie :\nDonnez le nom du fichier a ouvrir.\nLe nom ne doit pas comporter d'espace !!\n\nNom :");
	saisie = gtk_entry_new();
	boite = gtk_dialog_new_with_buttons("Ouvrir...", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Annuler", GTK_RESPONSE_CANCEL, "Charger", GTK_RESPONSE_OK, NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), saisie, FALSE, TRUE, 0);
	gtk_widget_show_all(boite);
	if(gtk_dialog_run(GTK_DIALOG(boite))==-5)
	{
		nom = gtk_entry_get_text(GTK_ENTRY(saisie));
		fic = fopen(nom, "r");		/* Ouverture du fichier en lecture */
		if(fic == NULL)
		{
			msg2 = gtk_label_new("\nLe fichier n'a pas pu être ouvert à cause d'une erreur....  :-(");
			msg3 = gtk_label_new("Le nom est peut-être mal écrit.\n");
			boite2 = gtk_dialog_new_with_buttons("Attention !", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);
			gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite2)->vbox), msg2, FALSE, TRUE, 0);
			gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite2)->vbox), msg3, FALSE, TRUE, 0);
			gtk_widget_show_all(boite2);
			gtk_dialog_run(GTK_DIALOG(boite2));
			gtk_widget_destroy(boite2);
		}
		else
		{
			joue = gtk_button_new_with_label("Coup suivant");/* Label cp svt */
			gtk_table_attach_defaults(GTK_TABLE(rosetab), joue, 1, 2, 6, 8);
			g_signal_connect(G_OBJECT(joue), "clicked", G_CALLBACK(execute), NULL);
		}
	}
	gtk_widget_destroy(boite);
}

void coord(int x, int y, char* affiche)
{
	switch(x)
	{
		case 0 : strcat(affiche, A); break;
		case 1 : strcat(affiche, B); break;
		case 2 : strcat(affiche, C); break;
		case 3 : strcat(affiche, D); break;
		case 4 : strcat(affiche, E); break;
		case 5 : strcat(affiche, F); break;
		case 6 : strcat(affiche, G); break;
		case 7 : strcat(affiche, H);
	}
	switch(y)
	{
		case 0 : strcat(affiche, un); break;
		case 1 : strcat(affiche, deux); break;
		case 2 : strcat(affiche, trois); break;
		case 3 : strcat(affiche, quatre); break;
		case 4 : strcat(affiche, cinq); break;
		case 5 : strcat(affiche, six); break;
		case 6 : strcat(affiche, sept); break;
		case 7 : strcat(affiche, huit);
	}
}

void enreg(GtkWidget *widget, gpointer data)
/* Callback pour le bouton "Enregistrer" du menu :
Affiche une boite de dialogue pour enregistrer la partie, puis enregistre la partie :
écrit la liste les coups joués (lcoup) dans le fichier 'nom'. */
{
	int r;
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *boite2;
	GtkWidget *msg2;
	GtkWidget *msg3;
	GtkWidget *saisie;
	char affiche[50] = "";
	coord(cp.depart.r, cp.depart.c, affiche);
	msg1 = gtk_label_new("\n\nEnregistrer la partie :\nLe fichier sera dans le dossier du programme.\nLe nom ne doit pas comporter d'espace !!\n\nNom :");
	saisie = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(saisie), "Partie.txt");
	boite = gtk_dialog_new_with_buttons("Enregistrer sous...", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Annuler", GTK_RESPONSE_CANCEL, "Enregistrer", GTK_RESPONSE_OK, NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), saisie, FALSE, TRUE, 0);
	gtk_widget_show_all(boite);
	r = gtk_dialog_run(GTK_DIALOG(boite));
	if(r==-5)
	{
		fic = fopen(gtk_entry_get_text(GTK_ENTRY(saisie)), "w");		/* Ouverture du fichier en écriture */
		if(fic==NULL)
		{
			msg2 = gtk_label_new("\nLa partie n'a pas pu être enregistrée à cause d'une erreur....");
			msg3 = gtk_label_new(":-(\n");
		}
		else
		{
			while(lcoup!=NULL)
			{
			  	fprintf(fic, "%d,%d -> %d,%d;sp%d\n", lcoup->depart.r, lcoup->depart.c, lcoup->arrivee.r, lcoup->arrivee.c, lcoup->spec);
				lcoup = lcoup->suiv;
			}
			fclose(fic);
			msg2 = gtk_label_new("\nLa partie a été enregistrée dans le fichier : ");
			msg3 = gtk_label_new(gtk_entry_get_text(GTK_ENTRY(saisie)));
		}
		boite2 = gtk_dialog_new_with_buttons("Confirmation", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite2)->vbox), msg2, FALSE, TRUE, 0);
		gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite2)->vbox), msg3, FALSE, TRUE, 0);
		gtk_widget_show_all(boite2);
		gtk_dialog_run(GTK_DIALOG(boite2));
		gtk_widget_destroy(boite2);
	}
	gtk_widget_destroy(boite);
}

void conseil(GtkWidget *widget, gpointer data)
{
	char affiche[50] = "";
	choix_coup(coul, echec, 4, &cp, lcoup);
	coord(cp.depart.r, cp.depart.c, affiche);
	strcat(affiche, tiret);
	coord(cp.arrivee.r, cp.arrivee.c, affiche);
	gtk_entry_set_text(GTK_ENTRY(affconseil), affiche);
}

void Apropos(GtkWidget *widget, gpointer data)
/* Callback pour le bouton "Apropos" du menu :
Affiche une boite de dialogue avec qques informations. */
{
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *msg2;
	GtkWidget *msg3;
	msg1 = gtk_label_new("Chess v1.0");
	gtk_label_set_justify(GTK_LABEL(msg1), GTK_JUSTIFY_CENTER);
	msg2 = gtk_label_new("    Petit jeu d'échec convivial.\n\n    Pour Jouer, il suffit de cliquer sur la pièce qu'on veut déplacer.\n    Ensuite, on clique dans la case dans laquelle on veut qu'elle aille.\n    En cas d'erreur (si le coup n'est pas autorisé ou en cas de changement d'avis),    \n    vous pourrez toujours resélecttionner le coup.\n\n    Il est possible de sauvegarder n'importe quand dans la partie,\n    et même plusieur fois.\n\n    Le bouton 'Aide' vous affiche le meilleur coup que l'ordinateur\n    aurait trouvé à votre place.\n\n\n");
	msg3 = gtk_label_new("Aucun droits réservés - © Copyme");
	boite = gtk_dialog_new_with_buttons("A Propos du jeu", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Fermer", GTK_RESPONSE_CLOSE, NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, FALSE, 40);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg2, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg3, FALSE, FALSE, 0);
	gtk_widget_show_all(boite);
	gtk_dialog_run(GTK_DIALOG(boite));
	gtk_widget_destroy(boite);
}

void quit(GtkWidget *widget, gpointer data)
/* Callback pour le bouton Quitter du menu
Ouvre une boite de dialogue pour demander si on enregistre. */
{
	int rep;
	GtkWidget *boite;
	GtkWidget *msg;
	msg = gtk_label_new("Etes vous sûr de vouloir quitter sans enregistrer ?");
	boite = gtk_dialog_new_with_buttons("Fermeture...", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Enregistrer", GTK_RESPONSE_OK, "Non", GTK_RESPONSE_NO, "Oui",  GTK_RESPONSE_YES,  NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg, FALSE, FALSE, 40);
	gtk_widget_show_all(boite);
	rep = gtk_dialog_run(GTK_DIALOG(boite));
	if(rep == -5)
	{
		enreg(boite, NULL);
		gtk_main_quit();
	}
	else if(rep == -9 || rep == -1)	gtk_widget_destroy(boite);
	else if(rep == -8) gtk_main_quit();
}

void victoire(Tcouleur vict)
/* Affiche une boite de dialogue pour annoncer la victoire : la couleur vict a gagné. */
{
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *image;
	image = gtk_image_new_from_file("Pieces_ft/mat.png");
	if(vict == 'B')
	{
		msg1 = gtk_label_new("Victoire des Blancs !");
	}
	else 
	{
		msg1 = gtk_label_new("Victoire des Noirs !");
	}
	gtk_label_set_justify(GTK_LABEL(msg1), GTK_JUSTIFY_CENTER);
	boite = gtk_dialog_new_with_buttons("Partie terminée", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Ok", GTK_RESPONSE_OK, NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, FALSE, 30);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), image, FALSE, FALSE, 10);
	gtk_widget_show_all(boite);
	gtk_dialog_run(GTK_DIALOG(boite));
	gtk_main_quit();
}

void init_pieces()
/* Place les images des pièces dans les event_box composant la table. */
{
	int i, j;
	init_echiquier(echec);
	for(i=0; i<8; i++)
	{
		for(j=2; j<6; j++)
		{
			if((i+j)%2 == 0) ebox[i][j] = cree_img_ebox("Pieces_fb/V.png");
			else ebox[i][j] = cree_img_ebox("Pieces_fn/V.png");
			gtk_table_attach_defaults(GTK_TABLE(table), ebox[i][j], i, i+1, j, j+1);
		}
	}
	for(i=0; i<8; i++)
	{
		if(i%2 == 0) ebox[i][1] = cree_img_ebox("Pieces_fn/PN.png");
		else ebox[i][1] = cree_img_ebox("Pieces_fb/PN.png");
		gtk_table_attach_defaults(GTK_TABLE(table), ebox[i][1], i, i+1, 1, 2);
	}
	for(i=0; i<8; i++)
	{
		if(i%2 == 0) ebox[i][6] = cree_img_ebox("Pieces_fb/PB.png");
		else ebox[i][6] = cree_img_ebox("Pieces_fn/PB.png");
		gtk_table_attach_defaults(GTK_TABLE(table), ebox[i][6], i, i+1, 6, 7);
	}
	ebox[0][0] = cree_img_ebox("Pieces_fb/TN.png");
	ebox[1][0] = cree_img_ebox("Pieces_fn/CN.png");
	ebox[2][0] = cree_img_ebox("Pieces_fb/FN.png");
	ebox[3][0] = cree_img_ebox("Pieces_fn/DN.png");
	ebox[4][0] = cree_img_ebox("Pieces_fb/RN.png");
	ebox[5][0] = cree_img_ebox("Pieces_fn/FN.png");
	ebox[6][0] = cree_img_ebox("Pieces_fb/CN.png");
	ebox[7][0] = cree_img_ebox("Pieces_fn/TN.png");
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[0][0], 0, 1, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[1][0], 1, 2, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[2][0], 2, 3, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[3][0], 3, 4, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[4][0], 4, 5, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[5][0], 5, 6, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[6][0], 6, 7, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[7][0], 7, 8, 0, 1);

	ebox[0][7] = cree_img_ebox("Pieces_fn/TB.png");
	ebox[1][7] = cree_img_ebox("Pieces_fb/CB.png");
	ebox[2][7] = cree_img_ebox("Pieces_fn/FB.png");
	ebox[3][7] = cree_img_ebox("Pieces_fb/DB.png");
	ebox[4][7] = cree_img_ebox("Pieces_fn/RB.png");
	ebox[5][7] = cree_img_ebox("Pieces_fb/FB.png");
	ebox[6][7] = cree_img_ebox("Pieces_fn/CB.png");
	ebox[7][7] = cree_img_ebox("Pieces_fb/TB.png");
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[0][7], 0, 1, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[1][7], 1, 2, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[2][7], 2, 3, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[3][7], 3, 4, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[4][7], 4, 5, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[5][7], 5, 6, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[6][7], 6, 7, 7, 8);
	gtk_table_attach_defaults(GTK_TABLE(table), ebox[7][7], 7, 8, 7, 8);

	ajout_img(GTK_BOX(bleubox[1]), "Pieces_ft/Hauteur.png");
	ajout_img(GTK_BOX(bleubox[3]), "Pieces_ft/Hauteur.png");
}

void deuxjoueurs_graph(GtkWidget *widget, gpointer data)
/* Stocke dans la variable globale cp la case où la souris a cliqué.
Si c'est le deuxième clic (cpt=1) alors on exécute le coup (s'il est valide). */
{
	int i, j, arret = 0;
	char affiche[50] = "";
	Tliste l=NULL;
	Tpiece p;
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *hbox;
	for(i=0; i<8 && arret==0; i++)
	{
		for(j=0; j<8 && arret==0; j++)
		{
			if(widget==ebox[i][j])
			{
				arret=1;
				i--;
				j--;
			}
		}
	}
	if(cpt == 0)
	{
		cp.depart.r = i;
		cp.depart.c = 7-j;
		coord(cp.depart.r, cp.depart.c, affiche);
		strcat(affiche, vers);
		if(coul == 'B')
		{
			gtk_entry_set_text(GTK_ENTRY(affdepb), affiche);
			gtk_entry_set_text(GTK_ENTRY(affarrb), "");
		}
		else
		{
			gtk_entry_set_text(GTK_ENTRY(affdepn), affiche);
			gtk_entry_set_text(GTK_ENTRY(affarrn), "");
		}
		cpt = 1;
		g_print("De (%d,%d) vers ", i, 7-j);
	}
	else
	{
		cp.arrivee.r = i;
		cp.arrivee.c = 7-j;
		coord(cp.arrivee.r, cp.arrivee.c, affiche);
		if(coul == 'B') gtk_entry_set_text(GTK_ENTRY(affarrb), affiche);
		else gtk_entry_set_text(GTK_ENTRY(affarrn), affiche);
		cpt = 0;
		g_print("(%d,%d)", i, 7-j);
		generateur(echec, coul, &l, lcoup);
		if(verification_coup(&cp, l)==1)
		{g_print("CoupOk !\n");
			gtk_entry_set_text(GTK_ENTRY(affconseil), "");
			if(cp.spec == 9)	/* Si il y a promotion du pion sur ce coup, affichage d'une boite de dialogue pour choisir. */
			{
				msg1 = gtk_label_new("Votre Pion va être promu !!!\nEn quoi voulez-vous qu'il se transforme ?");
				gtk_label_set_justify(GTK_LABEL(msg1), GTK_JUSTIFY_CENTER);
				hbox = gtk_hbox_new(TRUE, 0);
				boite = gtk_dialog_new_with_buttons("Promotion...", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Dame", 1, "Cavalier", 2, "Fou", 3, "Tour", 4, NULL);
				gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, TRUE, 30);
				gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), hbox, FALSE, TRUE, 0);
				if(coul == 'N')
				{
					ajout_img(GTK_BOX(hbox), "Pieces_ft/DN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/CN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/FN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/TN.png");
				}
				else
				{
					ajout_img(GTK_BOX(hbox), "Pieces_ft/DB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/CB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/FB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/TB.png");
				}
				gtk_widget_show_all(boite);
				switch(gtk_dialog_run(GTK_DIALOG(boite)))
				{
					case 1 : p='D'; break;
					case 2 : p='C'; break;
					case 3 : p='F'; break;
					case 4 : p='T'; break;
					default : p='V';
				}
				gtk_widget_destroy(boite);
				echec[(cp.depart).r][(cp.depart).c].piece=p;
				deplac_image(cp.depart, cp.arrivee);
				echec[(cp.arrivee).r][(cp.arrivee).c].coul=echec[(cp.depart).r][(cp.depart).c].coul;		
				echec[(cp.arrivee).r][(cp.arrivee).c].piece=p;
				echec[(cp.depart).r][(cp.depart).c].coul='V';
			}
			else
			{
				execute_graph();
				execute_coup(echec, cp);
			}
			ajout(&lcoup, cp);
			if(coul=='B') change_img(GTK_EVENT_BOX(tour), "Pieces_ft/Tourn.png");
			else change_img(GTK_EVENT_BOX(tour), "Pieces_ft/Tourb.png");
			generateur(echec, adversaire(coul), &l, lcoup);
			if(l==NULL) victoire(coul);			/* Si la liste est vide, la couleur coul gagne ! */
			coul = adversaire(coul);
		}
		else g_print("\n");
	}
}

void jeu_ordi(Tcouleur C)
/* Fais jouer l'ordinateur en tant que couleur 'C' */
{
	char affiche[50] = "";
	choix_coup(C, echec, 4, &cp, lcoup);
	if(cp.depart.r == -1) victoire(adversaire(C));			/* Si la coordonnée = -1, la couleur coul perd ! */
	coord(cp.depart.r, cp.depart.c, affiche);
	strcat(affiche, vers);
	gtk_entry_set_text(GTK_ENTRY(affdepn), affiche);
	affiche[0] = '\0';
	coord(cp.arrivee.r, cp.arrivee.c, affiche);
	gtk_entry_set_text(GTK_ENTRY(affarrn), affiche);
	execute_graph();
	execute_coup(echec, cp);
	ajout(&lcoup, cp);
}

void vspc_graph(GtkWidget *widget, gpointer data)
{
	int i, j, arret = 0;
	char affiche[50] = "";
	Tliste l=NULL;
	Tpiece p;
	GtkWidget *boite;
	GtkWidget *msg1;
	GtkWidget *hbox;
	for(i=0; i<8 && arret==0; i++)
	{
		for(j=0; j<8 && arret==0; j++)
		{
			if(widget==ebox[i][j])
			{
				arret=1;
				i--;
				j--;
			}
		}
	}
	if(cpt == 0)
	{
		cp.depart.r = i;
		cp.depart.c = 7-j;
		coord(cp.depart.r, cp.depart.c, affiche);
		strcat(affiche, vers);
		gtk_entry_set_text(GTK_ENTRY(affdepb), affiche);
		gtk_entry_set_text(GTK_ENTRY(affarrb), "");
		cpt = 1;
		g_print("De (%d,%d) vers ", i, 7-j);
	}
	else
	{
		cp.arrivee.r = i;
		cp.arrivee.c = 7-j;
		coord(cp.arrivee.r, cp.arrivee.c, affiche);
		gtk_entry_set_text(GTK_ENTRY(affarrb), affiche);
		cpt = 0;
		g_print("(%d,%d)", i, 7-j);
		generateur(echec, coul, &l, lcoup);
		if(l==NULL) victoire(adversaire(coul));			/* Si la liste est vide, la couleur coul perd ! */
		if(verification_coup(&cp, l)==1)
		{g_print("CoupOk !\n");
			gtk_entry_set_text(GTK_ENTRY(affconseil), "");
			if(cp.spec == 9)	/* Si il y a promotion du pion sur ce coup, affichage d'une boite de dialogue pour choisir. */
			{
				msg1 = gtk_label_new("Votre Pion va être promu !!!\nEn quoi voulez-vous qu'il se transforme ?");
				gtk_label_set_justify(GTK_LABEL(msg1), GTK_JUSTIFY_CENTER);
				hbox = gtk_hbox_new(TRUE, 0);
				boite = gtk_dialog_new_with_buttons("Promotion...", GTK_WINDOW(Window), GTK_DIALOG_MODAL, "Dame", 1, "Cavalier", 2, "Fou", 3, "Tour", 4, NULL);
				gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), msg1, FALSE, TRUE, 30);
				gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boite)->vbox), hbox, FALSE, TRUE, 0);
				if(coul == 'N')
				{
					ajout_img(GTK_BOX(hbox), "Pieces_ft/DN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/CN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/FN.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/TN.png");
				}
				else
				{
					ajout_img(GTK_BOX(hbox), "Pieces_ft/DB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/CB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/FB.png");
					ajout_img(GTK_BOX(hbox), "Pieces_ft/TB.png");
				}
				gtk_widget_show_all(boite);
				switch(gtk_dialog_run(GTK_DIALOG(boite)))
				{
					case 1 : p='D'; break;
					case 2 : p='C'; break;
					case 3 : p='F'; break;
					case 4 : p='T'; break;
					default : p='V';
				}
				gtk_widget_destroy(boite);
				echec[(cp.depart).r][(cp.depart).c].piece=p;
				deplac_image(cp.depart, cp.arrivee);
				echec[(cp.arrivee).r][(cp.arrivee).c].coul=echec[(cp.depart).r][(cp.depart).c].coul;		
				echec[(cp.arrivee).r][(cp.arrivee).c].piece=p;
				echec[(cp.depart).r][(cp.depart).c].coul='V';
			}
			execute_graph();
			execute_coup(echec, cp);
			ajout(&lcoup, cp);

			jeu_ordi(adversaire(coul));
		}
		else g_print("\n");
	}
}

void deuxpc_graph(GtkWidget *widget, gpointer data)
{
	if(cpt%2==0) jeu_ordi('B');
	else jeu_ordi('N');
	cpt++;
}

void partie2jou()
/* Initialise la fenetre pour pouvoir jouer à 2 joueurs */
{
	int i, j;
	GtkWidget *joker;
	GtkWidget *depart;
	GtkWidget *arrivee;

	joker = gtk_label_new("Meilleur coup :");		/* Label joker */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), joker, 0, 1, 6, 7);
	affconseil = gtk_entry_new();			/* zone de reponse joker */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affconseil, 1, 2, 6, 7);

	depart = gtk_label_new("Dernier coup blanc :");	/* Label blanc */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), depart, 0, 1, 10, 11);

	arrivee = gtk_label_new("Dernier coup noir :");	/* Label noir */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), arrivee, 0, 1, 9, 10);

	affdepb = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affdepb, 1, 2, 10, 11);

	affdepn = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affdepn, 1, 2, 9, 10);

	affarrb = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affarrb, 2, 3, 10, 11);

	affarrn = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affarrn, 2, 3, 9, 10);

	tour = cree_img_ebox("Pieces_ft/Tourb.png");	/* Image du tour */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), tour, 1, 2, 2, 4);
	for(i=0; i<8; i++)
		for(j=0; j<8; j++)
			g_signal_connect(G_OBJECT(ebox[i][j]), "button-release-event", G_CALLBACK(deuxjoueurs_graph), NULL);
}

void partieminmax()
/* Initialise la fenetre pour pouvoir jouer à contre l'ordi */
{
	int i, j;
	GtkWidget *joker;
	GtkWidget *depart;
	GtkWidget *arrivee;

	joker = gtk_label_new("Meilleur coup :");		/* Label joker */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), joker, 0, 1, 6, 7);
	affconseil = gtk_entry_new();			/* zone de reponse joker */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affconseil, 1, 2, 6, 7);

	depart = gtk_label_new("Dernier coup blanc :");	/* Label blanc */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), depart, 0, 1, 10, 11);

	arrivee = gtk_label_new("Dernier coup noir :");	/* Label noir */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), arrivee, 0, 1, 9, 10);

	affdepb = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affdepb, 1, 2, 10, 11);

	affdepn = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affdepn, 1, 2, 9, 10);

	affarrb = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affarrb, 2, 3, 10, 11);

	affarrn = gtk_entry_new();			/* zone de reponse depart */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), affarrn, 2, 3, 9, 10);

	tour = cree_img_ebox("Pieces_ft/Tourb.png");	/* Image du tour */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), tour, 1, 2, 2, 4);
	for(i=0; i<8; i++)
		for(j=0; j<8; j++)
			g_signal_connect(G_OBJECT(ebox[i][j]), "button-release-event", G_CALLBACK(vspc_graph), NULL);

}

void partie2pc()
{
	cpt = 0;
	deuxpc_graph(NULL, NULL);
	pcpc = gtk_button_new_with_label("Jouer un coup");/* Label pc vs pc */
	gtk_table_attach_defaults(GTK_TABLE(rosetab), pcpc, 1, 2, 8, 10);
	g_signal_connect(G_OBJECT(pcpc), "clicked", G_CALLBACK(deuxpc_graph), NULL);
}


int main(int argc,char **argv)
{
	int i, partie;
	GtkWidget *boiteinit;			/* Fenetre de démarrage */
	GtkWidget *msginit1;
	GtkWidget *msginit2;

	gtk_init(&argc, &argv);			/* Initialisation de l'environnement Gtk */	

/* Creation de la fenetre */
	Window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(Window), "Echecs");
	gtk_window_set_default_size(GTK_WINDOW(Window), 900, 576);
	gtk_window_set_position(GTK_WINDOW(Window), GTK_WIN_POS_CENTER);
	gtk_container_border_width (GTK_CONTAINER (Window), 10);

/* Création des boutons de menu et reliage par des callback */
/*	menu[0] = gtk_button_new_with_label("Nouveau");	
	menu[1] = gtk_button_new_with_label("Charger");
	gtk_signal_connect(GTK_OBJECT(menu[1]), "clicked", G_CALLBACK(load), NULL);
*/	menu[2] = gtk_button_new_with_label("Enregistrer");
	gtk_signal_connect(GTK_OBJECT(menu[2]), "clicked", G_CALLBACK(enreg), NULL);
	menu[3] = gtk_button_new_with_label("Conseil");	
	gtk_signal_connect(GTK_OBJECT(menu[3]), "clicked", G_CALLBACK(conseil), NULL);
	menu[4] = gtk_button_new_with_label("A Propos");	
	gtk_signal_connect(GTK_OBJECT(menu[4]), "clicked", G_CALLBACK(Apropos), NULL);
	menu[5] = gtk_button_new_with_label("Quitter");
	gtk_signal_connect(GTK_OBJECT(menu[5]), "clicked", G_CALLBACK(quit), NULL);

/* Ajout des box dans les box : */
	noirebox = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(Window), noirebox);

	bleubox[0] = gtk_hbox_new(TRUE, 20);
	gtk_box_pack_start(GTK_BOX(noirebox), bleubox[0], TRUE, TRUE, 0);

	vertebox = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(noirebox), vertebox, TRUE, TRUE,  0);

	rougebox = gtk_vbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(vertebox), rougebox, FALSE, TRUE,  0);

	rosebox = gtk_vbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(vertebox), rosebox, TRUE, TRUE,  0);

	bleubox[1] = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(rougebox), bleubox[1], FALSE, TRUE, 5);

	bleubox[2] = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(rougebox), bleubox[2], FALSE, TRUE, 5);

	bleubox[3] = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(rougebox), bleubox[3], FALSE, TRUE, 5);

/* Ajoute les boutons de menu à la bleubox[0] */
	for(i=2; i<6;i++)
		gtk_box_pack_start(GTK_BOX(bleubox[0]), menu[i], TRUE, TRUE, 0);

/* Crée la table, la remplit,  puis l'ajoute dans bleubox[2] */
	table = gtk_table_new(8, 8, FALSE);
	init_pieces();
	gtk_box_pack_start(GTK_BOX(bleubox[2]), table, FALSE, TRUE, 0);

/* Placement de la table à droite de l'échiquier */
	rosetab = gtk_table_new(15, 3, TRUE);
	gtk_box_pack_start(GTK_BOX(rosebox), rosetab, TRUE, TRUE, 0);

/* Fenêtre de démarrage : */
	msginit1 = gtk_label_new("\nJeu d'échecs.\n\n\nQue voulez-vous faire ?\n\n\n");
	msginit2 = gtk_label_new("2 joueurs		:  Démarre une nouvelle partie entre deux personnes\n\nOrdinateur	:  Démarre une nouvelle partie contre l'ordinateur\n\nSimulation	:  Démarre une nouvelle partie entre deux ordinateurs\n\nCharger		:  Réaffiche successivement les coups d'une ancienne partie sauvegardée\n\nQuitter		:  pour quitter\n");
	gtk_label_set_justify(GTK_LABEL(msginit1), GTK_JUSTIFY_CENTER);

	boiteinit = gtk_dialog_new_with_buttons("Bienvenue :-)", GTK_WINDOW(Window), GTK_DIALOG_MODAL,"2 joueurs", 1, "Ordinateur", 2, "Simulation", 3, "Charger", 4, "Quitter", GTK_RESPONSE_NONE, NULL);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boiteinit)->vbox), msginit1, FALSE, TRUE, 10);
	gtk_box_pack_start(GTK_BOX(GTK_DIALOG(boiteinit)->vbox), msginit2, FALSE, TRUE, 15);
	gtk_widget_show_all(boiteinit);
	partie = gtk_dialog_run(GTK_DIALOG(boiteinit));
	gtk_widget_destroy(boiteinit);

/* Appel des fonctions en fonction du mode de jeu choisi dans la fenêtre de démarrage */
	if(partie == 1) partie2jou();
	else if(partie == 2) partieminmax();
	else if(partie == 3) partie2pc();
	else if(partie == 4) load(NULL, NULL);
	else if(partie == -1) return EXIT_SUCCESS;

	gtk_signal_connect(GTK_OBJECT(Window), "destroy", G_CALLBACK(quit), NULL);
	gtk_widget_show_all(Window);
	gtk_main();
	return EXIT_SUCCESS;
}


