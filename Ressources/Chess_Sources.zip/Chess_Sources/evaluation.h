#ifndef EVALUATION_H
#define EVALUATION_H

int evaluation(Techiquier ec);
/* Renvoie la somme des pièces de l'echiquier. Les pièces blanches sont comptées en négatif et les noires en positif. */

void choix_naif_coup(Tcouleur camp, Techiquier ec, Tcoup *mcp, Tliste lcoup);
/* Choisi le meilleur coup à jouer pour la couleur "camp" (sachant que la liste lcoup est la liste des coups joués).
Retourne à travers "mcp" le coup ayant l'évaluation la plus élevée. */


#endif

