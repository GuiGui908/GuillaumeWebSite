#ifndef DONNEE_H
#define DONNEE_H

/* Piece : 'P'ion, 'C'avalier, 'F'ou, 'T'our, 'D'ame, 'R'oi */
typedef char Tpiece;

/* Couleur du contenu d'une case : 'B'lanc, 'N'oir, 'V'ide */
typedef char Tcouleur;

/* Contenu d'une case */
typedef struct
{
	Tcouleur coul;
	Tpiece piece;
} Tcase;

/* Echiquier : la case d'indice [0][0] désigne la case (1,A)
c'est à dire la case sur la colonne A et la rangée 1 */
typedef Tcase Techiquier [8][8];

/* Coordonnées de la case dans l'échiquier */
typedef struct
{
	int r;	/* Colonne (abscisse) */
	int c;	/*  Ligne  (ordonnee) */
} Tcoord;

/* Liste de coups */
typedef struct cellule
{
	Tcoord depart, arrivee;
	int spec;
	struct cellule *suiv;
} Tcoup;
typedef Tcoup *Tliste;

#endif
