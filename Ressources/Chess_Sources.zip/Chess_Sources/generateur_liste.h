#ifndef GENERATEUR_LISTE_H
#define GENERATEUR_LISTE_H

void generateur(Techiquier ec, Tcouleur coul, Tliste *l, Tliste lcoup);
/* Liste des coups possibles pour le camp de la couleur coul.
Cette procédure construit la liste *l qui contient tous les coups possibles pour le camp considéré. */

void affiche_coups_liste(Tliste l);
/* Affiche la liste des coups possibles : l */


#endif
