#ifndef MINMAX_H
#define MINMAX_H

void choix_coup(Tcouleur camp, Techiquier ec, int profmax, Tcoup *mcp, Tliste lcoup);
/* Explore l'arbre de jeu  jusqu'à un profondeur "Profmax" (4 pour 4 demi-coups).
Choisi le meilleur coup (+ grande évaluation) à jouer pour la couleur "camp" (sachant que la liste lcoup est la liste des coups joués).
Retourne ce coup à travers "mcp". */


#endif

