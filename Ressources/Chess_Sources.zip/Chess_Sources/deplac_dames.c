#include "donnee.h"
#include "manip.h"

/* Auteur du fichier : Fidèle ADICO */
int dep_dame(Techiquier ec, Tcoord pos)
/* De la même manière que le cavalier, cette fonction retourne 0 ou 1 si la dame peut ou non se déplacer. */
{
	if(pos.c<7)
	{
		if(ec[pos.r][(pos.c)+1].coul=='V')
			return(1);
			if(pos.r>0 && ec[pos.r-1][pos.c+1].coul=='V')
				return(1);
				if(pos.r<7 && ec[pos.r+1][pos.c+1].coul=='V')
					return(1);
	}
	if(pos.c>0)
	{
		if(ec[pos.r][(pos.c)-1].coul=='V')
			return(1);
			if(pos.r<7 && ec[pos.r+1][pos.c-1].coul=='V')
				return(1);
				if(pos.r>0 && ec[pos.r-1][pos.c-1].coul=='V')
					return(1);
	}
	if(pos.r>0 && ec[(pos.r)-1][pos.c].coul=='V')
		return(1);
		if(pos.r<7 && ec[(pos.r)+1][pos.c].coul=='V')
			return(1);
		else	return(0);
}

/* Les fonctions de prise retournent 1 si la dame peut manger une pièce dans une des cases
accessibles dans la direction spécifiée (g = gauche.... etc.) */
int dame_pr_g(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.r-1; i>=0 && ec[i][pos.c].coul=='V'; i--);
	if(i<0) return(0);		
	else	if(ec[i][(pos.c)].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_d(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.r+1; i<=7 && ec[i][pos.c].coul=='V'; i++);
	if(i>7) return(0);		
	else	if(ec[i][(pos.c)].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_h(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.c+1; i<=7 && ec[pos.r][i].coul=='V'; i++);
	if(i>7) return(0);		
	else	if(ec[pos.r][i].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}
	
int dame_pr_b(Techiquier ec, Tcoord pos)
{
	int i;
	for(i=pos.c-1; i>=0 && ec[pos.r][i].coul=='V'; i--);
	if(i<0) return(0);		
	else	if(ec[pos.r][i].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_g_h(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r-1, j=pos.c+1; i>=0 && j<=7 && ec[i][j].coul=='V'; i--, j++);
	if((i<0)||(j>7)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_g_b(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r-1, j=pos.c-1; i>=0 && j>=0 && ec[i][j].coul=='V'; i--, j--);
	if((i<0)||(j<0)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_d_h(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r+1, j=pos.c+1; i<=7 && j<=7 && ec[i][j].coul=='V'; i++, j++);
	if((i>7)||(j>7)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

int dame_pr_d_b(Techiquier ec, Tcoord pos)
{
	int i, j;
	for(i=pos.r+1, j=pos.c-1; i<=7 && j>=0 && ec[i][j].coul=='V'; i++, j--);
	if((i>7)||(j<0)) return(0);		
	else	
		if(ec[i][j].coul==adversaire(ec[pos.r][(pos.c)].coul))
			return(1);
		else	return(0);
}

