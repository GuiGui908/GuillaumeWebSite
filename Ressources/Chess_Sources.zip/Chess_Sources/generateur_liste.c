#include <stdio.h>
#include <stdlib.h>
#include "donnee.h"
#include "liste_echec.h"

#include "deplac_pion.h"
#include "deplac_tours_fous.h"
#include "deplac_cavaliers.h"
#include "deplac_dames.h"
#include "deplac_roi.h"
#include "coups_speciaux.h"
#include "saisie.h"


int clouage(Techiquier ec, Tcoup cp, Tcoord pos_roi)
/* Auteur : Guillaume BERT
Spécifications : Retourne 1 si l'exécution du coup cp met le roi (dans la case 'pos_roi) en échec. Retourne 0 sinon. */
{
	Tcase temp;
/* On sauvegarde la case d'arrivée puis on exécute le coup */
	temp = ec[cp.arrivee.r][cp.arrivee.c];	
	execute_coup(ec, cp);
/* Si la pièce n'est pas clouée : */
	if(roi_coup_legal(ec, pos_roi))
	{
	/* On remet ec dans son état initial */
		replace(ec, cp, temp);
		return(0);
	}
	else
	{
	/* On remet ec dans son état initial */
		replace(ec, cp, temp);
		return(1);
	}
}

void coups_possibles_case(Techiquier ec, Tcoord pos, Tliste *l, Tliste lcoup)
/* Auteur : Fidèle ADICO
Stocke la liste des coups possibles ET légaux pour la pièce dans la case pos.
La pièce ne peut pas se déplacer si le roi est en échec lorsqu'elle se déplace.
La liste l est passée en paramètre avec un pointeur pour qu'elle puisse être modifiée (on rajoute les coups à la fin).

ATTENTION ! Pour éviter une erreur de segmentation, il faut toujours placer les rois pendant les tests :
Cette fonction ne s'attend pas à ce qu'il manque un roi sur l'échiquier !!! */

{
	Tcoord pos_roi;
	Tcoup cp;
	int i, j;
	pos_roi.r = -1;
	pos_roi.c = -1;
	cp.depart = pos;
	cp.arrivee = pos;
	cp.spec = 0;
/* Recherche de la position du roi de la couleur de pos */
	for(i=0; i<8; i++)
		for(j=0; j<8; j++)
			if(ec[i][j].piece=='R' && ec[i][j].coul==ec[pos.r][pos.c].coul)
			{
				pos_roi.r = i;
				pos_roi.c = j;
			}
	if(ec[pos.r][pos.c].coul == 'V');		/* Si la couleur est vide, on ne fait rien !! */
	else if(ec[pos.r][pos.c].piece == 'P')	/* PION */
	{
		i = pion_dep(ec, pos);
		if(i==1)		/* PB avance de 1 */
		{
			cp.arrivee.c = pos.c+1;
			if(cp.arrivee.c == 7) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(i==2)		/* PB avance de 2 */
		{
			cp.arrivee.c = pos.c+1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
			cp.arrivee.c = pos.c+2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(i==11)		/* PN avance de 1 */
		{
			cp.arrivee.c = pos.c-1;
			if(cp.arrivee.c == 0) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(i==22)		/* PN avance de 2 */
		{
			cp.arrivee.c = pos.c-1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
			cp.arrivee.c = pos.c-2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);

		}
		if(pion_pr_g(ec, pos)==1)		/* PB mange à gauche */
		{
			cp.arrivee.r = pos.r-1;
			cp.arrivee.c = pos.c+1;
			if(cp.arrivee.c == 7) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(pion_pr_g(ec, pos)==2)		/* PN mange à gauche */
		{
			cp.arrivee.r = pos.r-1;
			cp.arrivee.c = pos.c-1;
			if(cp.arrivee.c == 0) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}

		if(pion_pr_d(ec, pos)==1)		/* PB mange à droite */
		{
			cp.arrivee.r = pos.r+1;
			cp.arrivee.c = pos.c+1;
			if(cp.arrivee.c == 7) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(pion_pr_d(ec, pos)==2)		/* PN mange à droite */
		{
			cp.arrivee.r = pos.r+1;
			cp.arrivee.c = pos.c-1;
			if(cp.arrivee.c == 0) cp.spec = 9;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		i = pr_en_passant(ec, lcoup, pos);
		if(i==1)		/* prise en passant pour le PB à gauche*/
		{
			cp.arrivee.r = pos.r-1;
			cp.arrivee.c = pos.c+1;
			cp.spec = 1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(i==2)	/* prise en passant pour le PN à gauche*/
		{
			cp.arrivee.r = pos.r-1;
			cp.arrivee.c = pos.c-1;
			cp.spec = 2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i==10)		/* prise en passant pour le PB à droite*/
		{
			cp.arrivee.r = pos.r+1;
			cp.arrivee.c = pos.c+1;
			cp.spec = 10;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		else if(i==20)	/* prise en passant pour le PN à droite*/
		{
			cp.arrivee.r = pos.r+1;
			cp.arrivee.c = pos.c-1;
			cp.spec = 20;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
	}
	else if(ec[pos.r][pos.c].piece == 'T')		/* TOUR */
	{
		for(i=pos.r-1; i>=0 && ec[i][pos.c].coul=='V'; i--)	/* Ajoute les cases VIDES vers la gauche */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && tour_pr_g(ec, pos))				/* Au cas où il y ait une PRISE vers la gauche */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1; i<=7 && ec[i][pos.c].coul=='V'; i++)	/* Ajoute les cases VIDES vers la droite */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && tour_pr_d(ec, pos))				/* Au cas où il y ait une PRISE vers la droite */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		cp.arrivee.r=pos.r;
		for(i=pos.c+1; i<=7 && ec[pos.r][i].coul=='V'; i++)	/* Ajoute les cases VIDES vers le haut */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && tour_pr_h(ec, pos))				/* Au cas où il y ait une PRISE vers le haut */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.c-1; i>=0 && ec[pos.r][i].coul=='V'; i--)	/* Ajoute les cases VIDES vers le bas */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && tour_pr_b(ec, pos))				/* Au cas où il y ait une PRISE vers le bas */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
	}
	else if(ec[pos.r][pos.c].piece == 'F')		/* FOU */
	{
		for(i=pos.r-1, j=pos.c+1; i>=0 && j<=7 && ec[i][j].coul=='V'; i--, j++)	/* Cases VIDES en haut à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && j<=7 && fou_pr_g_h(ec, pos))					/* Au cas où il y ait une PRISE en haut à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r-1, j=pos.c-1; i>=0 && j>=0 && ec[i][j].coul=='V'; i--, j--)	/* Cases VIDES en bas à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}		
		if(i>=0 && j>=0 && fou_pr_g_b(ec, pos))					/* Au cas où il y ait une PRISE en bas à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1, j=pos.c+1; i<=7 && j<=7 && ec[i][j].coul=='V'; i++, j++)	/* Cases VIDES en haut à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && j<=7 && fou_pr_d_h(ec, pos))					/* Au cas où il y ait une PRISE en haut à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1, j=pos.c-1; i<=7 && j>=0 && ec[i][j].coul=='V'; i++, j--)	/* Cases VIDES en bas à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && j>=0 && fou_pr_d_b(ec, pos))					/* Au cas où il y ait une PRISE en bas à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
	}
	else if(ec[pos.r][pos.c].piece == 'D')		/* DAME */
	{
		for(i=pos.r-1; i>=0 && ec[i][pos.c].coul=='V'; i--)	/* Ajoute les cases VIDES vers la gauche */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && dame_pr_g(ec, pos))				/* Au cas où il y ait une PRISE vers la gauche */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1; i<=7 && ec[i][pos.c].coul=='V'; i++)	/* Ajoute les cases VIDES vers la droite */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && dame_pr_d(ec, pos))				/* Au cas où il y ait une PRISE vers la droite */
		{
			cp.arrivee.r=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}				
		cp.arrivee.r=pos.r;
		for(i=pos.c+1; i<=7 && ec[pos.r][i].coul=='V'; i++)	/* Ajoute les cases VIDES vers le haut */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && dame_pr_h(ec, pos))				/* Au cas où il y ait une PRISE vers la haut */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}		
		for(i=pos.c-1; i>=0 && ec[pos.r][i].coul=='V'; i--)	/* Ajoute les cases VIDES vers le bas */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && dame_pr_b(ec, pos))				/* Au cas où il y ait une PRISE vers la bas */
		{
			cp.arrivee.c=i;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r-1, j=pos.c+1; i>=0 && j<=7 && ec[i][j].coul=='V'; i--, j++)	/* Cases VIDES en haut à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i>=0 && j<=7 && dame_pr_g_h(ec, pos))				/* Au cas où il y ait une PRISE en haut à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r-1, j=pos.c-1; i>=0 && j>=0 && ec[i][j].coul=='V'; i--, j--)	/* Cases VIDES en bas à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}		
		if(i>=0 && j>=0 && dame_pr_g_b(ec, pos))				/* Au cas où il y ait une PRISE en haut à gauche */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1, j=pos.c+1; i<=7 && j<=7 && ec[i][j].coul=='V'; i++, j++)	/* Cases VIDES en haut à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && j<=7 && dame_pr_d_h(ec, pos))				/* Au cas où il y ait une PRISE en haut à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		for(i=pos.r+1, j=pos.c-1; i<=7 && j>=0 && ec[i][j].coul=='V'; i++, j--)	/* Cases VIDES en bas à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(i<=7 && j>=0 && dame_pr_d_b(ec, pos))				/* Au cas où il y ait une PRISE en haut à droite */
		{
			cp.arrivee.r=i;
			cp.arrivee.c=j;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
	}
	else if(ec[pos.r][pos.c].piece=='C')		/* CAVALIER */
	{
		if(pos.r<7 && pos.c<6 && ec[pos.r+1][pos.c+2].coul=='V')	/* Déplacement haut(2)->droite(1) */
		{	
			cp.arrivee.r=pos.r+1;
			cp.arrivee.c=pos.c+2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}		
		if(pos.r<7 && pos.c>1 && ec[pos.r+1][pos.c-2].coul=='V')	/* Déplacement bas(2)->droite(1) */
		{
			cp.arrivee.r=pos.r+1;
			cp.arrivee.c=pos.c-2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.r>0 && pos.c<6 && ec[pos.r-1][pos.c+2].coul=='V')	/* Déplacement haut(2)->gauche(1) */
		{
			cp.arrivee.r=pos.r-1;
			cp.arrivee.c=pos.c+2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.r>0 && pos.c>1 && ec[pos.r-1][pos.c-2].coul=='V')	/* Déplacement bas(2)->gauche(1) */
		{
			cp.arrivee.r=pos.r-1;
			cp.arrivee.c=pos.c-2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.r<6 && pos.c<7 && ec[pos.r+2][pos.c+1].coul=='V')	/* Déplacement droite(2)->haut(1) */
		{
			cp.arrivee.r=pos.r+2;
			cp.arrivee.c=pos.c+1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.r<6 && pos.c>0 && ec[pos.r+2][pos.c-1].coul=='V')	/* Déplacement droite(2)->bas(1) */
		{
			cp.arrivee.r=pos.r+2;
			cp.arrivee.c=pos.c-1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.c>1 && pos.c<7 && ec[pos.r-2][pos.c+1].coul=='V')	/* Déplacement gauche(2)->haut(1) */
		{
			cp.arrivee.r=pos.r-2;
			cp.arrivee.c=pos.c+1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(pos.r>1 && pos.c>0 && ec[pos.r-2][pos.c-1].coul=='V')	/* Déplacement gauche(2)->bas(1) */
		{
			cp.arrivee.r=pos.r-2;
			cp.arrivee.c=pos.c-1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_h_d(ec, pos))			/* Prise haut(2)->droite(1) */
		{
			cp.arrivee.r=pos.r+1;
			cp.arrivee.c=pos.c+2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_d_h(ec, pos))			/* Prise droite(2)->haut(1) */
		{
			cp.arrivee.r=pos.r+2;
			cp.arrivee.c=pos.c+1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_d_b(ec, pos))			/* Prise droite(2)->bas(1) */
		{
			cp.arrivee.r=pos.r+2;
			cp.arrivee.c=pos.c-1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_b_d(ec, pos))			/* Prise bas(2)->droite(1) */
		{
			cp.arrivee.r=pos.r+1;
			cp.arrivee.c=pos.c-2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_b_g(ec, pos))			/* Prise bas(2)->gauche(1) */
		{
			cp.arrivee.r=pos.r-1;
			cp.arrivee.c=pos.c-2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_g_b(ec, pos))			/* Prise gauche(2)->bas(1) */
		{
			cp.arrivee.r=pos.r-2;
			cp.arrivee.c=pos.c-1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_g_h(ec, pos))			/* Prise gauche(2)->haut(1) */
		{
			cp.arrivee.r=pos.r-2;
			cp.arrivee.c=pos.c+1;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
		if(cavalier_pr_h_g(ec, pos))			/* Prise haut(2)->gauche(1) */
		{
			cp.arrivee.r=pos.r-1;
			cp.arrivee.c=pos.c+2;
			if(!clouage(ec, cp, pos_roi)) ajout(&(*l), cp);
		}
	}
	else if(ec[pos.r][pos.c].piece=='R')		/* ROI */
	{
		cp.arrivee.r = pos.r-1;
		if(cp.arrivee.r>=0 && roi_dep(ec, pos, cp.arrivee)>=1)		/* A gauche (1=déplacement ou 2=prise) */
			ajout(&(*l), cp);

		cp.arrivee.r=pos.r+1;
		if(cp.arrivee.r<=7 && roi_dep(ec, pos, cp.arrivee)>=1)		/* A droite */
			ajout(&(*l), cp);

		cp.arrivee.r = pos.r;
		cp.arrivee.c=pos.c+1;
		if(cp.arrivee.c<=7 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En haut */
			ajout(&(*l), cp);

		cp.arrivee.c=pos.c-1;
		if(cp.arrivee.c>=0 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En bas */
			ajout(&(*l), cp);

		cp.arrivee.r=pos.r+1;
		cp.arrivee.c=pos.c+1;
		if(cp.arrivee.r<=7 && cp.arrivee.c<=7 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En haut à droite */
			ajout(&(*l), cp);

		cp.arrivee.r=pos.r+1;
		cp.arrivee.c=pos.c-1;
		if(cp.arrivee.r<=7 && cp.arrivee.c>=0 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En bas à droite */
			ajout(&(*l), cp);

		cp.arrivee.r=pos.r-1;
		cp.arrivee.c=pos.c-1;
		if(cp.arrivee.r>=0 && cp.arrivee.c>=0 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En bas à gauche */
			ajout(&(*l), cp);

		cp.arrivee.r=pos.r-1;
		cp.arrivee.c=pos.c+1;
		if(cp.arrivee.r>=0 && cp.arrivee.c<=7 && roi_dep(ec, pos, cp.arrivee)>=1)		/* En haut à gauche */
			ajout(&(*l), cp);

		if(ec[pos.r][pos.c].coul=='B')			/* Roques blanc */
		{
			if(grand_roque_b(ec, lcoup)==3)		/* Grand roque */
			{
				cp.arrivee.r=pos.r-2;
				cp.arrivee.c=pos.c;	
				cp.spec = 3;		
				ajout(&(*l), cp);	
			}
			if(petit_roque_b(ec, lcoup)==30)	/* Petit roque */
			{
				printf("ROQUE BLANC possible");
				cp.arrivee.r=pos.r+2;
				cp.arrivee.c=pos.c;
				cp.spec = 30;			
				ajout(&(*l), cp);	
			}
		}
		else						/* Roques noir */
		{
			if(grand_roque_n(ec, lcoup)==4)		/* Grand roque */
			{
				cp.arrivee.r=pos.r-2;
				cp.arrivee.c=pos.c;
				cp.spec = 4;			
				ajout(&(*l), cp);	
			}
			if(petit_roque_n(ec, lcoup)==40)	/* Petit roque */
			{
				cp.arrivee.r=pos.r+2;
				cp.arrivee.c=pos.c;
				cp.spec = 40;			
				ajout(&(*l), cp);	
			}
		}
	}
}	

void generateur(Techiquier ec, Tcouleur coul, Tliste *l, Tliste lcoup)
/* Auteur : Guillaume BERT
Liste des coups possibles pour le camp de la couleur coul.
Cette procédure construit la liste *l qui contient tous les coups possibles pour le camp considéré. */
{
	Tcoord pos;
	suppression_tot(l);

	for(pos.r=0; pos.r<8; pos.r++)
		for(pos.c=0; pos.c<8; pos.c++)
			if(ec[pos.r][pos.c].coul == coul)
				coups_possibles_case(ec, pos, l, lcoup);
}

void affiche_coups_liste(Tliste l)
/* Auteur : Guillaume BERT
Affiche la liste des coups possibles : l */
{
	affiche(l);
}

