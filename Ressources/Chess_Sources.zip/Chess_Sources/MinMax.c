#include <stdio.h>
#include <stdlib.h>
#include "donnee.h"
#include "generateur_liste.h"
#include "evaluation.h"
#include "liste_echec.h"
#include "saisie.h"


int minmax_n(Tcouleur camp, Techiquier ec, int pr, Tliste lcoup)
/* Renvoie la meilleure (la + grande) valeur d'évaluation de l'échiquier après avoir décrémenté la profondeur jusqu'à 1.
Si la liste des coups est nulle (échec et mat), l'évaluation est de +- 99 */
{
	Tliste l=NULL, suppr;
	Tcase temp;
	int max=-999, min=999, m;	
	if(pr==1) return(evaluation(ec));
	else 	
	{
		generateur(ec, camp, &l, lcoup);
		suppr = l;
		if(camp=='N')			/* Maximise (meilleur coup pour les noirs) */
		{
			while(l!=NULL)
			{
				temp = ec[(l->arrivee).r][(l->arrivee).c];				
				execute_coup(ec, *l);

				m = minmax_n('B', ec, pr-1, lcoup);

				replace(ec, *l, temp);
				if(m > max) max=m;
				l = l->suiv;
			}
			suppression_tot(&suppr);
			return(max);
		}
		else				/* Minimise (meilleur coup pour les blancs) */
		{	
			while(l!=NULL)
			{
				temp = ec[(l->arrivee).r][(l->arrivee).c];				
				execute_coup(ec, *l);

				m = minmax_n('N', ec, pr-1, lcoup);

				replace(ec, *l, temp);
				if(m < min) min=m;
				l = l->suiv;
			}
			suppression_tot(&suppr);
			return(min);
		}
	}
}

int minmax_b(Tcouleur camp, Techiquier ec, int pr, Tliste lcoup)
/* Renvoie la meilleure (la + petite) valeur d'évaluation de l'échiquier après avoir décrémenté la profondeur jusqu'à 1.
Si la liste des coups est nulle (échec et mat), l'évaluation est de +- 99 */
{
	Tliste l=NULL, suppr;
	Tcase temp;
	int max=-999, min=999, m;	
	if(pr==1) return(evaluation(ec));
	else 	
	{
		generateur(ec, camp, &l, lcoup);
		suppr = l;
		if(camp=='B')			/* Minimise (meilleur coup pour les blancs) */
		{
			while(l!=NULL)
			{
				temp = ec[(l->arrivee).r][(l->arrivee).c];				
				execute_coup(ec, *l);

				m = minmax_b('N', ec, pr-1, lcoup);

				replace(ec, *l, temp);
				if(m < min) min=m;
				l = l->suiv;
			}
			suppression_tot(&suppr);
			return(min);
		}
		else				/* Maximise (meilleur coup pour les noirs) */
		{	
			while(l!=NULL)
			{
				temp = ec[(l->arrivee).r][(l->arrivee).c];				
				execute_coup(ec, *l);

				m = minmax_b('B', ec, pr-1, lcoup);

				replace(ec, *l, temp);
				if(m > max) max=m;
				l = l->suiv;
			}
			suppression_tot(&suppr);
			return(max);
		}
	}
}

void choix_coup(Tcouleur camp, Techiquier ec, int profmax, Tcoup *mcp, Tliste lcoup)
/* Explore l'arbre de jeu  jusqu'à un profondeur "Profmax" (4 pour 4 demi-coups).
Choisi le meilleur coup (+ grande évaluation) à jouer pour la couleur "camp" (sachant que la liste lcoup est la liste des coups joués).
Retourne ce coup à travers "mcp". */
{
	Tliste c=NULL, suppr;
	Tcase temp;
	int m, max = -1000;
/*int i=1;*/

	generateur(ec, camp, &c, lcoup);
	suppr = c;
	if(c==NULL) (*mcp).depart.r = -1;
	while(c!=NULL)
	{
		temp = ec[(c->arrivee).r][(c->arrivee).c];				
		execute_coup(ec, *c);

		if(camp == 'B') m = -minmax_b('N', ec, profmax, lcoup);		/* m est l'opposé de la valeur retournée par le minmax (car c'est le camp 'B') */
/*printf("ob%d - (%d, %d) -> (%d, %d) eval = %d\n", i, c->depart.r+1, c->depart.c+1, c->arrivee.r+1, c->arrivee.c+1, m);i++;}*/
		else m = minmax_n('B', ec, profmax, lcoup);
/*printf("on%d - (%d, %d) -> (%d, %d) eval = %d\n", i, c->depart.r+1, c->depart.c+1, c->arrivee.r+1, c->arrivee.c+1, m);i++;}*/

		replace(ec, *c, temp);
		if(m > max)			/* Cherche la + grande valeur retournée par le minmax parmis tous les coups */
		{
			max = m;
			*mcp = *c;
		}
		c = c->suiv;
	}
	suppression_tot(&suppr);
}


