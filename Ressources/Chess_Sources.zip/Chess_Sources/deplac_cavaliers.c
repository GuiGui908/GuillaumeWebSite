#include "donnee.h"
#include "manip.h"


/* Auteur du fichier : Fidèle ADICO */
int dep_cavalier(Techiquier ec, Tcoord pos)
/* Renvoie 1 dès que la fonction trouve une case où le cavalier peut aller. Renvoie 0 sinon (le cavalier ne peut pas de déplacer).
Elle n'est pas utilisée par la suite.... */
{
	if(pos.r<7)
	{
		if(pos.c<6 && ec[pos.r+1][pos.c+2].coul=='V') return(1);
		if(pos.c>1 && ec[pos.r+1][pos.c-2].coul=='V') return(1);
	}
	if(pos.r>0)
	{
		if(pos.c<6 && ec[pos.r-1][pos.c+2].coul=='V') return(1);
		if(pos.c>1 && ec[pos.r-1][pos.c-2].coul=='V') return(1);
	}
	if(pos.r<6)
	{
		if(pos.c<7 && ec[pos.r+2][pos.c+1].coul=='V') return(1);
		if(pos.c>0 && ec[pos.r+2][pos.c-1].coul=='V') return(1);
	}
	if(pos.r>1)
	{
		if(pos.c<7 && ec[pos.r-2][pos.c+1].coul=='V') return(1);
		if(pos.c>0 && ec[pos.r-2][pos.c-1].coul=='V') return(1);
	}
	return(0);
}

/* Les fonctions de prise retournent 1 si le cavalier peut manger la pièce dans la case spécifiée
(h_d = en haut à droite, b_g = en bas à droite... etc.) */
int cavalier_pr_h_d(Techiquier ec, Tcoord pos)
{
	if(pos.r<7 && pos.c<6 && ec[pos.r+1][pos.c+2].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}

int cavalier_pr_d_h(Techiquier ec, Tcoord pos)
{
	if(pos.r<6 && pos.c<7 && ec[pos.r+2][pos.c+1].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}
			
int cavalier_pr_d_b(Techiquier ec, Tcoord pos)
{
	if(pos.r<6 && pos.c>0 && ec[pos.r+2][pos.c-1].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}		

int cavalier_pr_b_d(Techiquier ec, Tcoord pos)
{
	if(pos.r<7 && pos.c>1 && ec[pos.r+1][pos.c-2].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}

int cavalier_pr_b_g(Techiquier ec, Tcoord pos)
{
	if(pos.r>0 && pos.c>1 && ec[pos.r-1][pos.c-2].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}

int cavalier_pr_g_b(Techiquier ec, Tcoord pos)
{
	if(pos.r>1 && pos.c>0 && ec[pos.r-2][pos.c-1].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}

int cavalier_pr_g_h(Techiquier ec, Tcoord pos)
{
	if(pos.r>1 && pos.c<7 && ec[pos.r-2][pos.c+1].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}


int cavalier_pr_h_g(Techiquier ec, Tcoord pos)
{
	if(pos.r>0 && pos.c<6 && ec[pos.r-1][pos.c+2].coul==adversaire(ec[pos.r][pos.c].coul))
		return(1);
	else	return(0);
}

