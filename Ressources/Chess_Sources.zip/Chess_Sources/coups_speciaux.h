#ifndef COUPS_SPECIAUX_H
#define COUPS_SPECIAUX_H

int pr_en_passant(Techiquier ec, Tliste lcoup, Tcoord pos);
/* Retourne 1 si le pion Blanc peut prendre en passant à gauche
Retourne 10 si le pion Blanc peut prendre en passant à droite
Retourne 2 si le pion Noir peut prendre en passant à gauche
Retourne 20 si le pion Noir peut prendre en passant à droite
Retourne 0 sinon */

int grand_roque_b(Techiquier ec, Tliste lcoup);
/* Retourne 3 si le grand roque est possible pour les blancs
Retourne 0 sinon */

int grand_roque_n(Techiquier ec, Tliste lcoup);
/* Retourne 4 si le grand roque est possible pour les noirs
Retourne 0 sinon */

int petit_roque_b(Techiquier ec, Tliste lcoup);
/* Retourne 30 si le petit roque est possible pour les blancs
Retourne 0 sinon */

int petit_roque_n(Techiquier ec, Tliste lcoup);
/* Retourne 40 si petit roque possible pour les noirs
Retourne 0 sinon */


#endif
