#include <stdio.h>
#include "donnee.h"
#include "liste_echec.h"
#include "coups_speciaux.h"


/* Auteur du fichier : Fidèle ADICO */

void saisir(int *r, int *c)
/* Saisi une coordonnée (r,c) avec un 'scanf' */
{
	char car;
	while(scanf("%c %d", &car, &(*c))!=2);
	*c = *c-1;
	if(*c<0 || *c>7) *c=-1;
	switch (car)
	{
		case 'A' : *r = 0; break;
		case 'B' : *r = 1; break;
		case 'C' : *r = 2; break;
		case 'D' : *r = 3; break;
		case 'E' : *r = 4; break;
		case 'F' : *r = 5; break;
		case 'G' : *r = 6; break;
		case 'H' : *r = 7; break;
		case 'Q' : *r = 8; break;

		case 'a' : *r = 0; break;
		case 'b' : *r = 1; break;
		case 'c' : *r = 2; break;
		case 'd' : *r = 3; break;
		case 'e' : *r = 4; break;
		case 'f' : *r = 5; break;
		case 'g' : *r = 6; break;
		case 'h' : *r = 7; break;
		case 'q' : *r = 8; break;
		default : *r = -1;
	}
	while((car=getchar())!='\n' && car != EOF)
	{
	;
	}
}

void saisie_clavier_coup(Tcoup *cp)
/* Demande à l'utilisteur de saisir un coup au clavier. Il le stocke dans *cp. */
{
	int r, c;

	printf("Choisir la case de départ de A->H 1->8 Ex: d2   Q1 quitte la partie.  ");
	saisir(&r, &c);
	while(r==-1 || c==-1)
	{
		printf("??? Resaisir la case de départ....  ");
		saisir(&r, &c);
	}
	(*cp).depart.r=r;
	(*cp).depart.c=c;
	if(r!=8)
	{
		printf("Choisir la case d'arrivée de A->H 1->8 Ex: d2   Q1 quitte la partie.  ");
		saisir(&r, &c);
		while(r==-1 || c==-1)
		{
			printf("??? Resaisir la case d'arrivée....  ");
			saisir(&r, &c);
		}
		(*cp).arrivee.r=r;
		(*cp).arrivee.c=c;
	}
}

int verification_coup(Tcoup *cp, Tliste l)
/* Renvoie 1 si le coup cp figure dans la liste l : cp est un coup valide. Renvoie 0 sinon. */
{
	while(l != NULL)
	{
		if(l->arrivee.r == (*cp).arrivee.r && l->arrivee.c == (*cp).arrivee.c && l->depart.r == (*cp).depart.r && l->depart.c == (*cp).depart.c)
		{
			(*cp).spec = l->spec;
			return(1);
		}
		l=l->suiv;
	}
	return(0);
}

void execute_coup(Techiquier ec, Tcoup cp)
/* Déplace la pièce dans sa nouvelle position. Execute aussi les coups spéciaux !!! */
{
	if(cp.spec == 0)				/* Coup normal */
	{	
		ec[(cp.arrivee).r][(cp.arrivee).c].coul=ec[(cp.depart).r][(cp.depart).c].coul;		
		ec[(cp.arrivee).r][(cp.arrivee).c].piece=ec[(cp.depart).r][(cp.depart).c].piece;		
		ec[(cp.depart).r][(cp.depart).c].coul='V';
	}
	else if(cp.spec == 1 || cp.spec == 2)		/* prise en passant à gauche (pion blanc ou noir) */
	{
		ec[(cp.depart).r-1][(cp.depart).c].coul='V';
		ec[(cp.arrivee).r][(cp.arrivee).c].coul=ec[(cp.depart).r][(cp.depart).c].coul;
		ec[(cp.arrivee).r][(cp.arrivee).c].piece=ec[(cp.depart).r][(cp.depart).c].piece;		
		ec[(cp.depart).r][(cp.depart).c].coul='V';//printf("Eppg");
	}
	else if(cp.spec == 10 || cp.spec == 20)		/* prise en passant à droite (pion blanc ou noir) */
	{
		ec[(cp.depart).r+1][(cp.depart).c].coul='V';		
		ec[(cp.arrivee).r][(cp.arrivee).c].coul=ec[(cp.depart).r][(cp.depart).c].coul;
		ec[(cp.arrivee).r][(cp.arrivee).c].piece=ec[(cp.depart).r][(cp.depart).c].piece;		
		ec[(cp.depart).r][(cp.depart).c].coul='V';//printf("Eppd");
	}
	else if(cp.spec == 3 || cp.spec == 4)		/* Grand roque (roi blanc ou noir) */
	{
		ec[(cp.arrivee).r][(cp.arrivee).c].coul = ec[(cp.depart).r][(cp.depart).c].coul;
		ec[(cp.arrivee).r][(cp.arrivee).c].piece = ec[(cp.depart).r][(cp.depart).c].piece;
		ec[(cp.depart).r][(cp.depart).c].coul='V';		
		ec[3][(cp.arrivee).c].coul=ec[0][(cp.arrivee).c].coul;
		ec[3][(cp.arrivee).c].piece=ec[0][(cp.arrivee).c].piece;
		ec[0][(cp.arrivee).c].coul='V';//printf("Egrq%d,%d;%d,%dsp%d",cp.depart.r, cp.depart.c,cp.arrivee.r,cp.arrivee.c, cp.spec);
	}
	else if(cp.spec == 30 || cp.spec == 40)		/* Petit roque (roi blanc ou noir) */
	{
		ec[(cp.arrivee).r][(cp.arrivee).c].coul=ec[(cp.depart).r][(cp.depart).c].coul;
		ec[(cp.arrivee).r][(cp.arrivee).c].piece=ec[(cp.depart).r][(cp.depart).c].piece;
		ec[(cp.depart).r][(cp.depart).c].coul='V';		
		ec[5][(cp.arrivee).c].coul=ec[7][(cp.arrivee).c].coul;
		ec[5][(cp.arrivee).c].piece=ec[7][(cp.arrivee).c].piece;
		ec[7][(cp.arrivee).c].coul='V';//printf("Eprq");
	}
/* Promotion :
Place automatiquement une Dame pour le PC.
Suppose que l'humain placera une dame (lorsqu'il exécute les coups pour le joueur humain pour le minmax.) */
	else if(cp.spec == 9)
	{
		ec[(cp.arrivee).r][(cp.arrivee).c].coul=ec[(cp.depart).r][(cp.depart).c].coul;		
		ec[(cp.arrivee).r][(cp.arrivee).c].piece='D';
		ec[(cp.depart).r][(cp.depart).c].coul='V';//printf("Epromo");
	}
}

void replace(Techiquier ec, Tcoup cp, Tcase arriv)
/* Replace la pièce dans sa position initiale. arriv est la case sur laquelle s'est déplacée la pièce (et qu'on a perdu en executant cp)
Replace aussi les coups spéciaux !!! */
{
	if(cp.spec == 0)
	{	
		ec[(cp.depart).r][(cp.depart).c] = ec[(cp.arrivee).r][(cp.arrivee).c];
		ec[(cp.arrivee).r][(cp.arrivee).c] = arriv;
	}
	else if(cp.spec == 1 || cp.spec == 2)		/* prise en passant à gauche (pion blanc ou noir) */
	{
		ec[(cp.depart).r][(cp.depart).c] = ec[(cp.arrivee).r][(cp.arrivee).c];
		ec[(cp.arrivee).r][(cp.arrivee).c].coul = 'V';
		ec[cp.depart.r-1][cp.arrivee.c].piece = 'P';
		if(cp.spec == 1) ec[cp.depart.r-1][cp.arrivee.c].coul = 'N';
		else ec[cp.depart.r-1][cp.arrivee.c].coul = 'B';
	}
	else if(cp.spec == 10 || cp.spec == 20)		/* prise en passant à droite (pion blanc ou noir) */
	{
		ec[(cp.depart).r][(cp.depart).c] = ec[(cp.arrivee).r][(cp.arrivee).c];
		ec[(cp.arrivee).r][(cp.arrivee).c].coul = 'V';
		ec[cp.depart.r+1][cp.arrivee.c].piece = 'P';
		if(cp.spec == 1) ec[cp.depart.r+1][cp.arrivee.c].coul = 'N';
		else ec[cp.depart.r+1][cp.arrivee.c].coul = 'B';
	}
	else if(cp.spec == 3 || cp.spec == 4)		/* Grand roque (roi blanc ou noir) */
	{
		ec[(cp.depart).r][(cp.depart).c] = ec[(cp.arrivee).r][(cp.arrivee).c];
		ec[(cp.arrivee).r][(cp.arrivee).c].coul = 'V';
		ec[0][(cp.arrivee).c] = ec[3][(cp.arrivee).c];
		ec[3][(cp.arrivee).c].coul = 'V';
	}
	else if(cp.spec == 30 || cp.spec == 40)		/* Petit roque (roi blanc ou noir) */
	{
		ec[(cp.depart).r][(cp.depart).c] = ec[(cp.arrivee).r][(cp.arrivee).c];
		ec[(cp.arrivee).r][(cp.arrivee).c].coul = 'V';
		ec[7][(cp.arrivee).c] = ec[5][(cp.arrivee).c];
		ec[5][(cp.arrivee).c].coul = 'V';
	}
	else if(cp.spec == 9)				/* Promotion */
	{
		ec[(cp.depart).r][(cp.depart).c].coul = ec[(cp.arrivee).r][(cp.arrivee).c].coul;
		ec[(cp.depart).r][(cp.depart).c].piece = 'P';
		ec[(cp.arrivee).r][(cp.arrivee).c] = arriv;
	}
}



