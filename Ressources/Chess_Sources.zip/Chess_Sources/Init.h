#ifndef INIT_H
#define INIT_H

void init_echiquier(Techiquier ec);
/* Initialise l'échiquier ec en remplissant les cases en configuration de début de partie */

void affectation_echiquier(Techiquier ec);
/* Initialise l'échiquier ec en remplissant les cases sur demande de l'utilisateur (du testeur). Il remplit l'échiquier case par case. */


#endif
