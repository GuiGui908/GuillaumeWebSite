#include <stdio.h>
#include "donnee.h"
#include "deplac_pion.h"
#include "deplac_tours_fous.h"
#include "deplac_cavaliers.h"
#include "deplac_dames.h"
#include "deplac_roi.h"

void affiche_coups_case(Techiquier ec, Tcoord pos)
/* Auteur : Guillaume BERT
Appelle les fonctions de déplacement pour la pièce éventuellement présente sur la case pos.
C'est une fonction de test pour les prises et les déplacements. */
{
	Tcoord pos1;
	printf("\n\nCase (%d,%d) :\n", pos.r, pos.c);
	if(ec[pos.r][pos.c].coul == 'V') printf("Elle est vide !\n");

	else if(ec[pos.r][pos.c].piece == 'P')		/* PION */
	{
		if(pion_dep(ec, pos)==1) printf("Le pion Blanc peut avancer d'une case...\n");
		if(pion_dep(ec, pos)==2) printf("Le pion Blanc peut avancer de 2 cases...\n");
		if(pion_dep(ec, pos)==11) printf("Le pion Noir peut avancer d'une case...\n");
		if(pion_dep(ec, pos)==12) printf("Le pion Noir peut avancer de 2 case...\n");
		if(pion_pr_g(ec, pos)) printf("Le pion peut manger à gauche \n");
		if(pion_pr_d(ec, pos)) printf("Le pion peut manger à droite \n");
	}
	else if(ec[pos.r][pos.c].piece == 'T')		/* TOUR */
	{
		if(tour_dep(ec, pos)) printf("La tour peut avancer...\n");
		if(tour_pr_g(ec, pos)) printf("La tour peut manger à gauche \n");
		if(tour_pr_d(ec, pos)) printf("La tour peut manger à droite \n");
		if(tour_pr_h(ec, pos)) printf("La tour peut manger en haut \n");
		if(tour_pr_b(ec, pos)) printf("La tour peut manger en bas\n");
	}
	else if(ec[pos.r][pos.c].piece == 'F')		/* FOU */
	{
		if(fou_dep(ec, pos)) printf("Le fou peut avancer...\n");
		if(fou_pr_g_h(ec, pos)) printf("Le fou peut manger g_h \n");
		if(fou_pr_g_b(ec, pos)) printf("Le fou peut manger g_b \n");
		if(fou_pr_d_h(ec, pos)) printf("Le fou peut manger d_h \n");
		if(fou_pr_d_b(ec, pos)) printf("Le fou peut manger d_b\n");
	}
	else if(ec[pos.r][pos.c].piece == 'C')		/* CAVALIER */
	{
		if(dep_cavalier(ec, pos)) printf("Le cavalier peut avancer...\n");
		if(cavalier_pr_h_d(ec, pos)) printf("Le cavalier peut manger h_b\n");
		if(cavalier_pr_d_h(ec, pos)) printf("Le cavalier peut manger d_h\n");
		if(cavalier_pr_d_b(ec, pos)) printf("Le cavalier peut manger d_b\n");
		if(cavalier_pr_b_d(ec, pos)) printf("Le cavalier peut manger b_d\n");
		if(cavalier_pr_b_g(ec, pos)) printf("Le cavalier peut manger b_g\n");
		if(cavalier_pr_g_b(ec, pos)) printf("Le cavalier peut manger g_b\n");
		if(cavalier_pr_g_h(ec, pos)) printf("Le cavalier peut manger g_h\n");
		if(cavalier_pr_h_g(ec, pos)) printf("Le cavalier peut manger h_g\n");
	}
	else if(ec[pos.r][pos.c].piece == 'D')		/* DAME */
	{
		if(dep_dame(ec, pos)) printf("La dame peut avancer...\n");
		if(dame_pr_g(ec, pos)) printf("La dame peut manger à gauche \n");
		if(dame_pr_d(ec, pos)) printf("La dame peut manger à droite \n");
		if(dame_pr_h(ec, pos)) printf("La dame peut manger en haut \n");
		if(dame_pr_b(ec, pos)) printf("La dame peut manger en bas\n");
		if(dame_pr_g_h(ec, pos)) printf("La dame peut manger g_h \n");
		if(dame_pr_g_b(ec, pos)) printf("La dame peut manger g_b \n");
		if(dame_pr_d_h(ec, pos)) printf("La dame peut manger d_h \n");
		if(dame_pr_d_b(ec, pos)) printf("La dame peut manger d_b\n");
	}
	else if(ec[pos.r][pos.c].piece == 'R')		/* ROI */
	{
		pos1.c = pos.c;
		pos1.r = pos.r;

		if(pos.c<7)
		{
			pos1.c = pos.c+1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en haut\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en haut\n");
		}
		if(pos.r<7)
		{
			pos1.r = pos.r+1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en haut à droite\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en haut à droite\n");
		}
		if(pos.c>0)
		{
			pos1.c = pos.c-1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer à droite\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger à droite\n");
		}
		if(pos.c>0)
		{
			pos1.c = pos.c-1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en bas à droite\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en bas à droite\n");
		}
		if(pos.r>0)
		{
			pos1.r = pos.r-1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en bas\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en bas\n");
		}
		if(pos.r>0)
		{
			pos1.r = pos.r-1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en bas à gauche\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en bas à gauche\n");
		}
		if(pos.c<7)
		{
			pos1.c = pos.c+1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer à gauche\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger à gauche\n");
		}
		if(pos.c<7)
		{
			pos1.c = pos.c+1;
			if(roi_dep(ec, pos, pos1)==1) printf("Le roi peut avancer en haut à gauche\n");
			else if(roi_dep(ec, pos, pos1)==2) printf("Le roi peut manger en haut à gauche\n");
		}
	}
	printf("\n\n");
}
