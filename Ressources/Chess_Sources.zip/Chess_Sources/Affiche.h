#ifndef AFFICHE_H
#define AFFICHE_H

void affichage(Techiquier af);

#endif
