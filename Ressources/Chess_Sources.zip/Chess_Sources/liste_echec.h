#ifndef LISTE_ECHEC_H
#define LISTE_ECHEC_H


void ajout(Tliste *l, Tcoup cp);
/* Ajoute à la fin de la liste *l le coup cp. */

void affiche(Tliste l);
/* Affiche tout le contenu de la liste l (les coups qui y sont sauvegardés). */

void suppression_tot(Tliste *l);
/* Supprime (désalloue) entièrement la liste *l de la mémoire avec l'instruction "free" */



#endif
