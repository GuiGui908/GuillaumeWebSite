#ifndef DEPLAC_TOURS_FOUS_H
#define DEPLAC_TOURS_FOUS_H

int tour_dep(Techiquier ec, Tcoord pos);
/* De la même manière que le cavalier, cette fonction retourne 0 ou 1 si la tour peut ou non se déplacer. */

int tour_pr_g(Techiquier ec, Tcoord pos);
/* En s'appuyant sur les fonctions de prise de la dame, on fait pareil pour la tour. */
int tour_pr_d(Techiquier ec, Tcoord pos);
int tour_pr_h(Techiquier ec, Tcoord pos);
int tour_pr_b(Techiquier ec, Tcoord pos);
int fou_dep(Techiquier ec, Tcoord pos);
int fou_pr_g_h(Techiquier ec, Tcoord pos);
int fou_pr_g_b(Techiquier ec, Tcoord pos);
int fou_pr_d_h(Techiquier ec, Tcoord pos);
int fou_pr_d_b(Techiquier ec, Tcoord pos);


#endif
