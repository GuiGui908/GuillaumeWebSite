#include "donnee.h"
#include <stdio.h>
#include <stdlib.h>


/* Auteur du fichier : BERT Guillaume */
void ajout(Tliste *l, Tcoup cp)
/* Ajoute à la fin de la liste *l le coup cp. */
{
	Tliste cpt, temp;

	temp = (Tliste) malloc(sizeof(Tcoup));
	*temp = cp;
	temp->suiv = NULL;

	if(*l==NULL) *l = temp;
	else
	{
		for(cpt = *l; cpt->suiv!=NULL; cpt = cpt->suiv);
		cpt->suiv = temp;
	}
}

void affiche(Tliste l)
/* Affiche tout le contenu de la liste l (les coups qui y sont sauvegardés). */
{
	int i = 1;
	printf("\n");
	if(l==NULL) printf("La liste de coups est vide !!\n\n");
	while(l!=NULL)
	{
		printf("%d - De (%d,%d) vers (%d,%d). Spec : %d\n", i, l->depart.r, l->depart.c, l->arrivee.r, l->arrivee.c, l->spec);
		l=l->suiv;
		i++;
	}
	printf("\n");
}

void suppression_tot(Tliste *l)
/* Supprime (désalloue) entièrement la liste *l de la mémoire avec l'instruction "free" */
{
	Tliste suppr = *l;
	while(*l!=NULL)
	{
		*l=(*l)->suiv;
		free(suppr);
		suppr=*l;
	}
}

