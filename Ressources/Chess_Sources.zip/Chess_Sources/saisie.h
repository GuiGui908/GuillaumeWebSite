#ifndef SAISIE_H
#define SAISIE_H


void saisie_clavier_coup(Tcoup *cp);
/* Demande à l'utilisteur de saisir un coup au clavier. Il le stocke dans *cp. */

int verification_coup(Tcoup *cp, Tliste l);
/* Renvoie 1 si le coup cp figure dans la liste l : cp est un coup valide. Renvoie 0 sinon. */

void execute_coup(Techiquier ec, Tcoup cp);
/* Déplace la pièce dans sa nouvelle position. Execute aussi les coups spéciaux !!! */

void replace(Techiquier ec, Tcoup cp, Tcase arriv);
/* Replace la pièce dans sa position initiale. arriv est la case sur laquelle s'est déplacée la pièce (et qu'on a perdu en executant cp)
Replace aussi les coups spéciaux !!! */



#endif
