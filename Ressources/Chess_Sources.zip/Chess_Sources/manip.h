#ifndef MANIP_H
#define MANIP_H

#include "donnee.h"

int coul_oppos(Techiquier ec, Tcoord p1, Tcoord p2);
/* Renvoie 1 si les pièces en position p1 et p2 sont de la même couleur. Renvoie 0 sinon. Cette fonction n'a pas été utilisée. */

void inverser_couleur(Tcouleur *coul);
/* Inverse la couleur de *coul si *coul n'est pas égal à 'V'. Cette fonction n'a pas été utilisée. */

Tcouleur adversaire(Tcouleur coul);
/* Renvoie la couleur opposée de coul et 'V' sinon. */


#endif
