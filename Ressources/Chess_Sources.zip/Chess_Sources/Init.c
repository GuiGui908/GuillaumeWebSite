#include "donnee.h"
#include <stdio.h>

void init_echiquier(Techiquier ec)
/* Auteur : BERT Guillaume
Initialise l'échiquier ec en remplissant les cases en configuration de début de partie */
{
	int i, j;
/* Pions Blancs et couleur des pièces blanches */
	for(i=0; i<8 ; i++)
	{
		ec[i][1].piece = 'P';
		ec[i][1].coul = 'B';
		ec[i][0].coul = 'B';
	}
/* Pions Noirs et couleur des pièces noires */
	for(i=0; i<8 ; i++)
	{
		ec[i][6].piece = 'P';
		ec[i][6].coul = 'N';
		ec[i][7].coul = 'N';
	}
/* Boucle pour les cases vides */
	for(i=0; i<8; i++)
		for(j=2; j<6; j++)
			ec[i][j].coul = 'V';

/* Pièces Blanches */
	ec[0][0].piece = 'T';
	ec[1][0].piece = 'C';
	ec[2][0].piece = 'F';
	ec[3][0].piece = 'D';
	ec[4][0].piece = 'R';
	ec[5][0].piece = 'F';
	ec[6][0].piece = 'C';
	ec[7][0].piece = 'T';

/* Pièces Noires */
	ec[0][7].piece = 'T';
	ec[1][7].piece = 'C';
	ec[2][7].piece = 'F';
	ec[3][7].piece = 'D';
	ec[4][7].piece = 'R';
	ec[5][7].piece = 'F';
	ec[6][7].piece = 'C';
	ec[7][7].piece = 'T';
}

void affectation_echiquier(Techiquier ec)
/* Auteur : ADICO Fidèle
Initialise l'échiquier ec en remplissant les cases sur demande de l'utilisateur (du testeur). Il remplit l'échiquier case par case. */
{
	int i, j, z, l;
	char a, c, q = 'a';
/* Toutes les cases sont mises à vide */
	for(i=0; i<8; i++)
		for(j=0; j<8; j++)
			ec[i][j].coul = 'V';
/* Placement des pièces par l'utilisateur */
	while(q != 'q')
	{
		printf("\nChoisir la colonne (A -> H) : ");
		a=scanf("%c", &c);
		switch (c)
		{
			case 'A' : z = 0; break;
			case 'B' : z = 1; break;
			case 'C' : z = 2; break;
			case 'D' : z = 3; break;
			case 'E' : z = 4; break;
			case 'F' : z = 5; break;
			case 'G' : z = 6; break;
			case 'H' : z = 7; break;
			default : z = 0;
			
		}
		while((c=getchar())!='\n' && c != EOF )
		{
                ;
		}

		printf("\nChoisir la ligne (1 -> 8) : ");	
		a=scanf("%d", &l);
		l = l-1;
		while((c=getchar())!='\n' && c != EOF )
		{
                ;
		}

		printf("\nChoisir la pièce (P, C, F, T, D, R) : ");
		c=scanf("%c", &a);
		while((c=getchar())!='\n' && c != EOF )
		{
                ;
		}
		ec[z][l].piece = a;

		printf("\nChoisir la couleur (B ou N ou V) : ");
		c=scanf("%c", &a);
		while((c=getchar())!='\n' && c != EOF )
		{
                ;
		}
		ec[z][l].coul = a;

		printf("Appuyer sur 'q' pour quitter ......");
		q = getchar();
	}
}


