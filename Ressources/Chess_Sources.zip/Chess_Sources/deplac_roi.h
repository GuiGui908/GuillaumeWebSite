#ifndef DEPLAC_ROI_H
#define DEPLAC_ROI_H

int roi_coup_legal(Techiquier ec, Tcoord pos);
/* Retourne 1 si le roi dans la position pos n'est attaqué d'aucun endroit par une pièce ennemi */

int roi_dep(Techiquier ec, Tcoord pos, Tcoord pos1);
/* Spécifications : On suppose que pos (position de départ) et pos1 (position d'arrivée) sont voisines.
Retourne 0 si le roi ne peut pas aller dans la case pos1
Retourne 1 si le roi peut se déplacer SIMPLEMENT  dans la case pos1 (pos1 est vide) sans être en échec
Retourne 2 si le roi peut se déplacer EN MANGEANT dans la case pos1 (pos1 est adverse) sans être en échec */


#endif
