#include "donnee.h"
#include "manip.h"

/* Auteur du fichier (tout sauf la dernière fonction) : Fidèle ADICO */
int roi_coup_legal_h_d(Techiquier ec, Tcoord pos)
/* Renvoie 1 si le coup est légal en regardant en haut à droite :
Si le roi est placé dans la case pos, alors il n'est pas attaqué
par aucune pièce venant d'en haut à droite (pion, roi, fou ou dame) */
{
	int i, j;
/* Si il y a une case en haut à droite de pos */
	if(pos.r+1<=7 && pos.c+1<=7)
	{
/* Si "Le roi est blanc" ET "la pièce dans la case juste en haut à droite est de couleur noire"
 ET "cette pièce est un pion OU un roi" */
		if(ec[pos.r][pos.c].coul=='B' && ec[pos.r+1][pos.c+1].coul=='N'
&& (ec[pos.r+1][pos.c+1].piece=='P' || ec[pos.r+1][pos.c+1].piece=='R')) return(0);

/* Si "Le roi est noir" ET "la pièce dans la case juste en haut à droite est de couleur blanche"
 ET "cette pièce est un roi" */
		if(ec[pos.r][pos.c].coul=='N' && ec[pos.r+1][pos.c+1].coul=='B'
&& ec[pos.r+1][pos.c+1].piece=='R') return(0);

/* Tant que "on reste dans l'échiquier" et "la case en haut à droite est vide", on incrémente. */
		for(i=pos.r+1, j=pos.c+1; i<=7 && j<=7 && ec[i][j].coul=='V'; i++, j++);

/* Si il est arrivé à la fin de l'échiquier sans trouver de pièces, c'est bon !! */
		if((i>7)||(j>7)) return(1);

/* Si "la couleur de la case qui l'a fait sortir est la couleur adverse"
 ET "la pièce est une dame ou un fou" */
		if(ec[i][j].coul==adversaire(ec[pos.r][pos.c].coul)
&& (ec[i][j].piece=='D' || ec[i][j].piece=='F')) return(0);
	}
/* Si il n'y a rien en haut à droite (bord de l'échiquier)  = 1er if
OU Si	la boucle for précédente s'est arrêtée sur une pièce Blanche
	OU un Cavalier Noir OU un Pion Noir OU un Roi Noir OU une Tour Noire */
	return(1);
}
		
int roi_coup_legal_b_d(Techiquier ec, Tcoord pos)
{
	int i, j;
	if(pos.r+1<=7 && pos.c-1>=0)
	{
		if(ec[pos.r][pos.c].coul=='N' && ec[pos.r+1][pos.c-1].coul=='B' && (ec[pos.r+1][pos.c-1].piece=='P' || ec[pos.r+1][pos.c-1].piece=='R')) return(0);
		if(ec[pos.r][pos.c].coul=='B' && ec[pos.r+1][pos.c-1].coul=='N' && ec[pos.r+1][pos.c-1].piece=='R') return(0);
		for(i=pos.r+1, j=pos.c-1; i<=7 && j>=0  && ec[i][j].coul=='V'; i++, j--);
		if((i>7)||(j<0)) return(1);
		if(ec[i][j].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[i][j].piece=='D')||(ec[i][j].piece=='F'))) return(0);
	}
	return(1);
}

int roi_coup_legal_b_g(Techiquier ec, Tcoord pos)
{
	int i, j;
	if(pos.r-1>=0 && pos.c-1>=0)
	{
		if(ec[pos.r][pos.c].coul=='N' && ec[pos.r-1][pos.c-1].coul=='B' && (ec[pos.r-1][pos.c-1].piece=='P' || ec[pos.r-1][pos.c-1].piece=='R')) return(0);
		if(ec[pos.r][pos.c].coul=='B' && ec[pos.r-1][pos.c-1].coul=='N' && ec[pos.r-1][pos.c-1].piece=='R') return(0);
		for(i=pos.r-1, j=pos.c-1; i>=0 && j>=0 && ec[i][j].coul=='V'; i--, j--);
		if((i<0)||(j<0)) return(1);
		if(ec[i][j].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[i][j].piece=='D')||(ec[i][j].piece=='F'))) return(0);
	}
	return(1);
}

int roi_coup_legal_h_g(Techiquier ec, Tcoord pos)
{
	int i, j;
	if(pos.r-1>=0 && pos.c+1<=7)
	{
		if(ec[pos.r][pos.c].coul=='B' && ec[pos.r-1][pos.c+1].coul=='N' && (ec[pos.r-1][pos.c+1].piece=='P' || ec[pos.r-1][pos.c+1].piece=='R')) return(0);
		if(ec[pos.r][pos.c].coul=='N' && ec[pos.r-1][pos.c+1].coul=='B' && ec[pos.r-1][pos.c+1].piece=='R') return(0);
		for(i=pos.r-1, j=pos.c+1; i>=0 && j<=7 && ec[i][j].coul=='V'; i--, j++);
		if((i<0)||(j>7)) return(1);
		if(ec[i][j].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[i][j].piece=='D')||(ec[i][j].piece=='F'))) return(0);
	}
	return(1);
}

int roi_coup_legal_h(Techiquier ec, Tcoord pos)
{
	int j;
	if(pos.c+1<=7)
	{
		if(ec[pos.r][pos.c+1].coul==adversaire(ec[pos.r][pos.c].coul) && ec[pos.r][pos.c+1].piece=='R') return(0);
		for(j=pos.c+1; j<=7 && ec[pos.r][j].coul=='V'; j++);
		if(j>7) return(1);
		if(ec[pos.r][j].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[pos.r][j].piece=='D')||(ec[pos.r][j].piece=='T'))) return(0);
	}
	return(1);
}

int roi_coup_legal_d(Techiquier ec, Tcoord pos)
{
	int i;
	if(pos.r+1<=7)
	{
		if(ec[pos.r+1][pos.c].coul==adversaire(ec[pos.r][pos.c].coul) && ec[pos.r+1][pos.c].piece=='R') return(0);
		for(i=pos.r+1; i<=7 && ec[i][pos.c].coul=='V'; i++);
		if(i>7) return(1);
		if(ec[i][pos.c].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[i][pos.c].piece=='D')||(ec[i][pos.c].piece=='T'))) return(0);
	}
	return(1);
}	

int roi_coup_legal_b(Techiquier ec, Tcoord pos)
{
	int j;
	if(pos.c-1>=0)
	{
		if(ec[pos.r][pos.c-1].coul==adversaire(ec[pos.r][pos.c].coul) && ec[pos.r][pos.c-1].piece=='R') return(0);
		for(j=pos.c-1; j>=0 && ec[pos.r][j].coul=='V'; j--);
		if(j<0) return(1);
		if(ec[pos.r][j].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[pos.r][j].piece=='D')||(ec[pos.r][j].piece=='T'))) return(0);
	}
	return(1);
}

int roi_coup_legal_g(Techiquier ec, Tcoord pos)
{
	int i;
	if(pos.r-1>=0)
	{
		if(ec[pos.r-1][pos.c].coul==adversaire(ec[pos.r][pos.c].coul) && ec[pos.r-1][pos.c].piece=='R') return(0);
		for(i=pos.r-1; i>=0 && ec[i][pos.c].coul=='V'; i--);
		if(i<0) return(1);
		if(ec[i][pos.c].coul==adversaire(ec[pos.r][pos.c].coul)&&((ec[i][pos.c].piece=='D')||(ec[i][pos.c].piece=='T'))) return(0);
	}
	return(1);
}

int roi_coup_legal_cav(Techiquier ec, Tcoord pos)
/* Renvoie 1 si le roi sur la case pos n'est pas attaqué par un cavalier ennemi */
{
	if((pos.r+1<=7) && (pos.c+2<=6) && (ec[pos.r+1][pos.c+2].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r+1][pos.c+2].piece=='C'))
		return(0);
	if((pos.r+2<=6) && (pos.c+1<=7) && (ec[pos.r+2][pos.c+1].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r+2][pos.c+1].piece=='C'))
		return(0);
	if((pos.r+2<=6) && (pos.c-1>=0) && (ec[pos.r+2][pos.c-1].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r+2][pos.c-1].piece=='C'))
		return(0);
	if((pos.r+1<=7) && (pos.c-2>=1) && (ec[pos.r+1][pos.c-2].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r+1][pos.c-2].piece=='C'))
		return(0);
	if((pos.r-1>=0) && (pos.c-2>=1) && (ec[pos.r-1][pos.c-2].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r-1][pos.c-2].piece=='C'))
		return(0);
	if((pos.r-2>=1) && (pos.c-1>=0) && (ec[pos.r-2][pos.c-1].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r-2][pos.c-1].piece=='C'))
		return(0);
	if((pos.r-2>=1) && (pos.c+1<=7) && (ec[pos.r-2][pos.c+1].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r-2][pos.c+1].piece=='C'))
		return(0);
	if((pos.r-1>=0) && (pos.c+2<=6) && (ec[pos.r-1][pos.c+2].coul==adversaire(ec[pos.r][pos.c].coul)) && (ec[pos.r-1][pos.c+2].piece=='C'))
		return(0);
	return(1);
}

int roi_coup_legal(Techiquier ec, Tcoord pos)
/* Retourne 1 si le roi dans la position pos n'est attaqué d'aucun endroit par une pièce ennemi */
{
	if(roi_coup_legal_h(ec, pos) && roi_coup_legal_d(ec, pos) && roi_coup_legal_b(ec, pos) && roi_coup_legal_g(ec, pos) && roi_coup_legal_h_d(ec, pos) && roi_coup_legal_b_d(ec, pos) && roi_coup_legal_b_g(ec, pos) && roi_coup_legal_h_g(ec, pos) && roi_coup_legal_cav(ec, pos))
		return(1);
	else	return(0);
}

int roi_dep(Techiquier ec, Tcoord pos, Tcoord pos1)
/* Auteur : Guillaume BERT
Spécifications : On suppose que pos (position de départ) et pos1 (position d'arrivée) sont voisines.
Retourne 0 si le roi ne peut pas aller dans la case pos1
Retourne 1 si le roi peut se déplacer SIMPLEMENT  dans la case pos1 (pos1 est vide) sans être en échec
Retourne 2 si le roi peut se déplacer EN MANGEANT dans la case pos1 (pos1 est adverse) sans être en échec */
{
	Tcase temp;	/* Case de sauvegarde de la pièce sur la position d'arrivée */
/* Si les cases de départ et d'arrivée ne sont pas de la même couleur */
	if(ec[pos1.r][pos1.c].coul!=ec[pos.r][pos.c].coul)
	{
	/* On déplace le roi dans pos1 puis on met la case de départ à vide */
		temp = ec[pos1.r][pos1.c];
		ec[pos1.r][pos1.c] = ec[pos.r][pos.c];
		ec[pos.r][pos.c].coul = 'V';
	/* Si le roi sur pos1 n'est pas en échec, alors on remet l'échiquier en place et on teste........... */
		if(roi_coup_legal(ec, pos1))
		{
			ec[pos.r][pos.c] = ec[pos1.r][pos1.c];
			ec[pos1.r][pos1.c] = temp;
		/* ..........si il s'est déplacé simplement........... */
			if(ec[pos1.r][pos1.c].coul == 'V') return(1);
		/* ..........ou si il a mangé !! */
			else return(2);
		}
	/* Sinon on remet "ec" en place et on retourne 0 : il est en échec :-( */
		ec[pos.r][pos.c] = ec[pos1.r][pos1.c];
		ec[pos1.r][pos1.c] = temp;
	}
	return(0);
}

