#ifndef DEPLAC_PION_H
#define DEPLAC_PION_H

int pion_dep(Techiquier ec, Tcoord pos);
/* Valeur retournée :
0 si aucun déplacement possible
Pour le déplacement d'un pion BLANC : Retourne 1 pour une case et 2 pour une ou deux cases vers l'avant
Pour le déplacement d'un pion NOIR :  Retourne 11 pour une case et 22 pour une ou deux cases vers l'avant */
int pion_pr_g(Techiquier ec, Tcoord pos);
/* Valeur retournée :
0 si aucun déplacement possible
1 si le pion BLANC peut manger à gauche
2 si le pion NOIR peut manger à gauche */
int pion_pr_d(Techiquier ec, Tcoord pos);
/* Valeur retournée :
0 si aucun déplacement possible
1 si le pion BLANC peut manger à droite
2 si le pion NOIR peut manger à droite */


#endif
